"""Actual image source AST, synthetic in-memory SQL; never import app."""
import ast,hashlib,json,os,pathlib,signal,sys,types,typing
signal.alarm(30)
assert sys.version_info[:3]==(3,12,13)
events=[]
def audit(event,args):
 if event in ('socket.__new__','socket.connect','socket.bind','subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec'):
  events.append({'denied':event});raise PermissionError('no network/process')
 if event=='sqlite3.connect' and args[0]!=':memory:':raise PermissionError('SQLite memory only')
 if event=='open':
  path=args[0] if args else None;mode=args[1] if len(args)>1 else None;flags=args[2] if len(args)>2 else 0
  if isinstance(path,(str,bytes)) and os.fsdecode(path).startswith('/app/'):raise PermissionError('no application reads')
  if isinstance(mode,str) and any(c in mode for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):raise PermissionError('no file writes')
 if event in ('os.remove','os.unlink','os.rmdir','os.mkdir','os.rename','os.chmod','os.chown','os.link','os.symlink'):raise PermissionError('no filesystem mutation')
sys.addaudithook(audit);sys.path.append('/opt/venv/lib/python3.12/site-packages')
import sqlalchemy,sqlite3,re
from sqlalchemy import Boolean,Column,Integer,String,JSON,Float,Index,func,or_,select,delete,Sequence,Identity,and_,inspect,create_engine,text,event
from sqlalchemy.orm import Session,as_declarative,declared_attr
from datetime import datetime
from pydantic import BaseModel,Field
from types import SimpleNamespace
from urllib import parse
REF=pathlib.Path('/ref');sources={p.name:p.read_text() for p in REF.glob('*.py') if p.name!='probe.py'}
def top(file,name):return next(n for n in ast.parse(sources[file]).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name)
def compile_into(nodes,ns,future=True):exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-source-ast>','exec',flags=__import__('__future__').annotations.compiler_flag if future else 0,dont_inherit=True),ns)
class Clock(datetime):
 @classmethod
 def now(cls,tz=None):return cls(2026,11,5,12,34,56)
dbns={**vars(typing),**globals(),'settings':SimpleNamespace(DB_TYPE='sqlite'),'datetime':Clock,'async_db_query':lambda f:f,'async_db_update':lambda f:f,'ScopedSession':lambda:(_ for _ in ()).throw(AssertionError('explicit memory Session required'))}
compile_into([top('db_base.py',name) for name in ['_get_args_db','_update_args_db','db_update','db_query','get_id_column','Base']],dbns)
compile_into([top('userdata_model.py','SiteUserData')],dbns);Base,Account=dbns['Base'],dbns['SiteUserData']
update=next(n for n in top('site_oper.py','SiteOper').body if isinstance(n,ast.FunctionDef) and n.name=='update_userdata');compile_into([update],dbns);update_userdata=dbns['update_userdata']
schema_ns={**vars(typing),**globals()};compile_into([top('schema_site.py','SiteUserData')],schema_ns,False);DTO=schema_ns['SiteUserData']
string_cls=top('string.py','StringUtils');string_cls.body=[n for n in string_cls.body if isinstance(n,ast.FunctionDef) and n.name in ['get_url_domain','get_url_netloc']];special=next(n for n in ast.parse(sources['string.py']).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_special_domains' for t in n.targets));string_ns={**vars(typing),**globals()};compile_into([special,string_cls],string_ns)
trace=[];capture_sql=True
class Notification:
 def __init__(self,**fields):self.fields=fields
class ChainBase:
 def run_module(self,*_,**__):trace.append({'op':'run_module'});return current
 def post_message(self,n):trace.append({'op':'post_message','fields':n.fields})
 messageoper=SimpleNamespace(exists_by_source=lambda _:False)
site={'id':7,'name':'Owned','domain':'https://owned.invalid/','url':'https://owned.invalid/'}
class Oper:
 def update_userdata(self,**kw):trace.append({'op':'update_userdata','payload_before':json.loads(json.dumps(kw['payload']))});return update_userdata(SimpleNamespace(_db=session),**kw)
chain_ns={**vars(typing),**globals(),'SiteOper':Oper,'SiteUserData':DTO,'ChainBase':ChainBase,'StringUtils':string_ns['StringUtils'],'NotificationType':SimpleNamespace(SiteMessage='站点消息'),'eventmanager':SimpleNamespace(send_event=lambda kind,data:trace.append({'op':'event','kind':kind,'data':data})),'EventType':SimpleNamespace(SiteRefreshed='site.refreshed')}
node=top('chain_site.py','SiteChain');node.body=[n for n in node.body if isinstance(n,ast.FunctionDef) and n.name in ['refresh_userdata','_post_site_messages']];compile_into([node],chain_ns);Chain=chain_ns['SiteChain'];rows=[];big=(1<<100)+12345
cases=[('large-upload-insert',{'upload':big},False),('large-userid-insert',{'userid':big},False),('large-unread-insert',{'message_unread':big},False),('large-upload-update',{'upload':big},True),('large-userid-error-skip',{'userid':big,'err_msg':'owned current error'},True),('large-unread-error-skip',{'message_unread':big,'err_msg':'owned current error'},True),('none-with-old-row',None,True),('default-current-insert',{},False)]
for label,fields,existing in cases:
 engine=create_engine('sqlite:///:memory:');Base.metadata.create_all(engine)
 with Session(engine) as session:
  if existing:Account(domain='owned.invalid',name='Stored',updated_day='2026-11-05',updated_time='01:00:00',upload=5.0,userid='old',err_msg='').create(session)
  current=DTO(**fields) if fields is not None else None;before=current.model_dump() if current is not None else None;trace=[]
  @event.listens_for(engine,'before_cursor_execute')
  def sql_observe(conn,cursor,statement,parameters,context,executemany):
   if capture_sql:trace.append({'op':'sql','statement':statement})
  try:
   returned=Chain().refresh_userdata(site);outcome={'data':returned.model_dump() if returned is not None else None,'same_object':returned is current}
  except Exception as error:outcome={'raises':type(error).__name__,'message':str(error),'orig':type(getattr(error,'orig',None)).__name__}
  source_trace=list(trace);capture_sql=False;stored=[x.to_dict() for x in Account.get_by_domain(session,'owned.invalid','2026-11-05')];capture_sql=True
  rows.append({'case':label,'fields':fields,'existing':existing,'outcome':outcome,'current_before':before,'current_after':current.model_dump() if current is not None else None,'source_trace':source_trace,'stored':stored})
 engine.dispose()
print(json.dumps({'kind':'actual SiteChain.refresh_userdata/_post_site_messages + SiteOper.update_userdata + actual commit/rollback decorators and Base/SQL model against owned memory SQLite with real Pydantic; no app import','python':sys.version,'sqlite':sqlite3.sqlite_version,'sqlalchemy':sqlalchemy.__version__,'pydantic':__import__('pydantic').__version__,'source_sha256':{n:hashlib.sha256(s.encode()).hexdigest() for n,s in sources.items()},'cases':rows,'limits':['Module provider and event/message receivers are owned recording boundaries; no native refresh or production credentials/config','Exact captured SQLite schema and synthetic rows, no real original database access','Source method bodies and DB query/update transaction wrappers execute unchanged; no storage coerce assumptions'],'audit_denied':events},ensure_ascii=False))
