"""Actual image source AST, synthetic in-memory SQL; never import app."""
import ast,hashlib,json,os,pathlib,signal,sys,types,typing
signal.alarm(30)
assert sys.version_info[:3]==(3,12,13)
events=[]
def audit(event,args):
 if event in ('socket.__new__','socket.connect','socket.bind','subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec'):
  events.append({'denied':event});raise PermissionError('no network/process')
 if event=='sqlite3.connect' and args[0]!=':memory:':raise PermissionError('SQLite memory only')
 if event=='open':
  path=args[0] if args else None;mode=args[1] if len(args)>1 else None;flags=args[2] if len(args)>2 else 0
  if isinstance(path,(str,bytes)) and os.fsdecode(path).startswith('/app/'):raise PermissionError('no application reads')
  if isinstance(mode,str) and any(c in mode for c in 'wax+') or isinstance(flags,int) and flags&(os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND):raise PermissionError('no file writes')
 if event in ('os.remove','os.unlink','os.rmdir','os.mkdir','os.rename','os.chmod','os.chown','os.link','os.symlink'):raise PermissionError('no filesystem mutation')
sys.addaudithook(audit);sys.path.append('/opt/venv/lib/python3.12/site-packages')
import sqlalchemy,sqlite3
from sqlalchemy import Boolean,Column,Integer,String,JSON,Float,Index,func,or_,select,delete,Sequence,Identity,and_,inspect,create_engine,text
from sqlalchemy.orm import Session,as_declarative,declared_attr
from datetime import datetime
from pydantic import BaseModel,Field
from types import SimpleNamespace
REF=pathlib.Path('/ref');source={p.name:p.read_text() for p in REF.glob('*.py') if p.name!='probe.py'}
namespace={**vars(typing),**globals(),'settings':SimpleNamespace(DB_TYPE='sqlite'),'db_query':lambda f:f,'db_update':lambda f:f,'async_db_query':lambda f:f,'async_db_update':lambda f:f}
def extract(file,name):return next(n for n in ast.parse(source[file]).body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name)
def execute(nodes):exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual-source-ast>','exec',flags=__import__('__future__').annotations.compiler_flag),namespace)
execute([extract('db_base.py','get_id_column'),extract('db_base.py','Base')]);execute([extract('site_model.py','Site')]);execute([extract('userdata_model.py','SiteUserData')])
Base,Site,Account=namespace['Base'],namespace['Site'],namespace['SiteUserData'];engine=create_engine('sqlite:///:memory:');Base.metadata.create_all(engine)
from sqlalchemy.schema import CreateTable,CreateIndex
metadata={'site_ddl':str(CreateTable(Site.__table__).compile(engine)),'site_indexes':[str(CreateIndex(i).compile(engine)) for i in Site.__table__.indexes],'account_ddl':str(CreateTable(Account.__table__).compile(engine)),'site_columns':[c.name for c in Site.__table__.columns],'account_columns':[c.name for c in Account.__table__.columns]}
rows=[(7,'seven',90,1),(2,'two',70,1),(11,'eleven',1,1),(3,'disabled',0,0),(9,'nine',20,1),(13,'null-active',-1,None)]
with engine.begin() as c:
 for ident,name,priority,active in rows:c.exec_driver_sql('INSERT INTO site (id,name,domain,url,pri,is_active) VALUES (?,?,?,?,?,?)',(ident,name,name+'.invalid','https://'+name+'.invalid/',priority,active))
observations=[]
def active(label):
 with Session(engine) as db:
  query=db.query(Site).filter(Site.is_active);sql=str(query.statement.compile(engine,compile_kwargs={'literal_binds':True}));result=Site.get_actives(db);observations.append({'case':label,'sql':sql,'query_plan':list(map(list,db.execute(text('EXPLAIN QUERY PLAN '+sql)).all())),'ids':[s.id for s in result],'priorities':[s.pri for s in result],'row_dict_order':list(result[0].to_dict()) if result else []})
active('insert-out-of-id-and-priority-order')
with engine.begin() as c:c.exec_driver_sql('UPDATE site SET pri=0 WHERE id=7');c.exec_driver_sql('INSERT INTO site (id,name,domain,url,pri,is_active) VALUES (1,?,?,?,?,1)',('late-one','one.invalid','https://one.invalid/',100))
active('late-low-primary-key-and-priority-edit')
with engine.begin() as c:c.exec_driver_sql('DELETE FROM site WHERE id=2');c.exec_driver_sql('UPDATE site SET is_active=1 WHERE id=3')
active('delete-and-enable-existing-id')
# Raw source model grouping: latest successful day, then all rows for that day.
with Session(engine) as db:
 for row in [dict(id=8,domain='a.invalid',name='A',updated_day='2026-11-03',updated_time='03:00:00',upload=80,err_msg=''),dict(id=2,domain='a.invalid',name='A',updated_day='2026-11-03',updated_time='05:00:00',upload=20,err_msg='owned error'),dict(id=7,domain='a.invalid',name='A',updated_day='2026-11-05',updated_time='10:00:00',upload=70,err_msg='owned newer error'),dict(id=4,domain='b.invalid',name='A',updated_day='2026-11-04',updated_time='04:00:00',upload=40,err_msg=None),dict(id=1,domain='a.invalid',name='A',updated_day='2026-11-02',updated_time='01:00:00',upload=10,userid='²')]:db.add(Account(**row))
 db.commit();account_latest=[x.to_dict() for x in Account.get_latest(db)];account_date=[x.to_dict() for x in Account.get_by_date(db,'2026-11-03')];account_unicode=[x.to_dict() for x in Account.get_by_date(db,'2026-11-02')]
# Real installed Pydantic schema, not the earlier valid-input defaults shell.
exec(compile(ast.Module(body=[extract('schema_site.py','SiteUserData')],type_ignores=[]),'<actual-schema-ast>','exec',dont_inherit=True),namespace);DTO=namespace['SiteUserData'];dto_cases=[]
for name,fields in [('default',{}),('explicit-empty-domain-day',{'domain':'','updated_day':''}),('null-large-current',{'userid':2**100,'upload':2**100,'download':None,'seeding_info':[[1,{'k':[None,3]}]],'message_unread_contents':[['head','date','body',{'key':[1,None]}]]}),('legal-digit-string-userid',{'userid':'²'})]:
 value=DTO(**fields);dto_cases.append({'case':name,'input':fields,'model_dump':value.model_dump(),'field_order':list(value.model_dump())})
print(json.dumps({'kind':'actual captured Base/Site/Account/schema AST with real installed SQLAlchemy and SQLite memory and Pydantic; no application imports','python':sys.version,'sqlite':sqlite3.sqlite_version,'sqlalchemy':sqlalchemy.__version__,'pydantic':__import__('pydantic').__version__,'source_sha256':{n:hashlib.sha256(t.encode()).hexdigest() for n,t in source.items()},'decorator_boundary':'db transaction/query decorators are inert because each source method receives the explicit owned memory Session; actual method body and actual Base table/name/to_dict remain','metadata':metadata,'active':observations,'latest_accounts':account_latest,'by_date_accounts':account_date,'unicode_account':account_unicode,'dto_cases':dto_cases,'audit_denied':events,'limitations':['Only exact captured SQLite schema/default planner with owned rows; no generic SQL ordering guarantee or production DB execution','No native site refresh, HTTP parser or real credentials/data','Model constructors/default SQLAlchemy behavior are actual; transaction wrapper ownership is synthetic']},ensure_ascii=False))
engine.dispose()
