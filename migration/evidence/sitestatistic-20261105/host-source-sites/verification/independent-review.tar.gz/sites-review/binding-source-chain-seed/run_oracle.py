"""Run only marked synthetic source inputs in a disposable isolated container."""
from pathlib import Path
import hashlib,json,shlex,subprocess,sys,time
root=Path(__file__).resolve().parent
marker=json.loads((root/'TASK.json').read_text())
assert marker['task']=='lm-plugin-sites-chain-seed-review-20261105'
suffix=marker['uuid'];remote='/home/admin/light-media-plugins-sites-chain-seed-review-'+suffix
name='lm-plugins-sites-chain-seed-review-'+suffix
image='sha256:33354456e8e19c65193b9ca471e45450a620c541759cc42e76cf00a03b025881'
sshbase=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8','admin@192.168.8.129']
runid=sys.argv[1] if len(sys.argv)>1 else 'r1'
assert runid.replace('-','').isalnum()
def ssh(args,**kwargs):
 return subprocess.run(sshbase+[shlex.join(args)],**kwargs)
def checked(args,**kwargs):
 p=ssh(args,**kwargs)
 if p.returncode:raise RuntimeError('remote command failed with status '+str(p.returncode))
 return p
created=False;observations={'image':image,'task':marker['task'],'uuid':suffix,'classification':'actual SQLAlchemy/SQLite memory and Pydantic source AST; no app import or production access','run':runid}
try:
 p=checked(['docker','image','inspect',image,'--format','{{.Id}} {{.Architecture}} {{.Os}}'],capture_output=True);observations['image_inspect']=p.stdout.decode().strip()
 checked(['mkdir','-m','755',remote]);created=True
 checked(['tee',remote+'/TASK.json'],input=(root/'TASK.json').read_bytes(),stdout=subprocess.DEVNULL)
 files=[]
 for path in sorted((root/'input').iterdir()):
  assert path.is_file()
  checked(['tee',remote+'/'+path.name],input=path.read_bytes(),stdout=subprocess.DEVNULL)
  checked(['chmod','444',remote+'/'+path.name]);files.append({'name':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'size':path.stat().st_size})
 args=['docker','run','--rm','--pull','never','--name',name,'--label','task='+marker['task'],'--label','task-owner='+suffix,'--network','none','--read-only','--no-healthcheck','--user','1000:1000','--cap-drop','ALL','--security-opt','no-new-privileges','--memory','256m','--cpus','1','--pids-limit','48','--mount','type=bind,src='+remote+',dst=/ref,readonly','--mount','type=tmpfs,destination=/config,tmpfs-size=4096,readonly','--tmpfs','/tmp:rw,nosuid,nodev,noexec,size=64m','--workdir','/tmp','--entrypoint','python3',image,'-I','-S','-B','/ref/probe.py']
 observations.update(command=args,input_files=files)
 t=time.monotonic();p=ssh(args,capture_output=True,timeout=45);observations.update(exit_code=p.returncode,seconds=time.monotonic()-t)
 (root/(runid+'-stdout.json')).write_bytes(p.stdout);(root/(runid+'-stderr.txt')).write_bytes(p.stderr)
 observations['stdout_sha256']=hashlib.sha256(p.stdout).hexdigest();observations['stderr_sha256']=hashlib.sha256(p.stderr).hexdigest()
 print(json.dumps({'run':runid,'exit':p.returncode,'seconds':observations['seconds'],'stdout_bytes':len(p.stdout),'stderr':p.stderr.decode()[:2000]}))
finally:
 # Inspect only this exact generated name and marker before exact cleanup.
 p=ssh(['docker','ps','-aq','--filter','name=^/'+name+'$','--filter','label=task-owner='+suffix],capture_output=True)
 cid=p.stdout.decode().strip()
 if cid:
  assert '\n' not in cid
  checked(['docker','rm','-f',cid],capture_output=True)
 observations['remaining_container_ids']=ssh(['docker','ps','-aq','--filter','label=task-owner='+suffix],capture_output=True).stdout.decode().strip()
 if created:
  actual=checked(['cat',remote+'/TASK.json'],capture_output=True).stdout
  assert json.loads(actual)==marker
  checked(['rm','-r','--',remote])
 observations['stage_removed']=ssh(['test','!','-e',remote],capture_output=True).returncode==0
 (root/(runid+'-execution.json')).write_text(json.dumps(observations,indent=2)+'\n')
