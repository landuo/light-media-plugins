package sites
import (
 "bytes"
 "encoding/json"
 "math/big"
 "os"
 "reflect"
 "testing"
)
func independentSourceSemantic(raw []byte) any {
 dec:=json.NewDecoder(bytes.NewReader(raw));dec.UseNumber();var out any;if err:=dec.Decode(&out);err!=nil{panic(err)}
 var norm func(any)any;norm=func(v any)any{switch x:=v.(type){case json.Number:r,ok:=new(big.Rat).SetString(string(x));if !ok{panic(x)};return struct{Exact string}{r.RatString()};case []any:for i:=range x{x[i]=norm(x[i])};case map[string]any:for k:=range x{x[k]=norm(x[k])}};return v};return norm(out)
}
func TestIndependentRealSourceCurrentDTOAndBinding(t *testing.T){
 raw,err:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/binding-source/r1-stdout.json");if err!=nil{t.Fatal(err)}
 var fixture struct {Cases []struct {Case string;Current json.RawMessage `json:"current_before"`; Existing bool; Outcome struct {Raises string `json:"raises"`}} `json:"cases"`}
 if json.Unmarshal(raw,&fixture)!=nil||len(fixture.Cases)!=8{t.Fatal("actual source8")}
 for _,sample:=range fixture.Cases{t.Run(sample.Case,func(t *testing.T){
  var dto *SourceUserData;if err:=json.Unmarshal(sample.Current,&dto);err!=nil{t.Fatal("source legal current rejected",err)}
  got,err:=json.Marshal(dto);if err!=nil{t.Fatal(err)};if !reflect.DeepEqual(independentSourceSemantic(got),independentSourceSemantic(sample.Current)){t.Fatalf("currentDTO changed: got %s want %s",got,sample.Current)}
  if dto==nil{return}
  if sample.Outcome.Raises!="" {if dto.ValidateSourceAccountBinding()==nil{t.Fatal("actual SQLite binding overflow accepted")}} else if !sample.Existing||dto.Error==nil||*dto.Error=="" {if err:=dto.ValidateSourceAccountBinding();err!=nil{t.Fatal("actual Float binding success rejected",err)}}
  if sample.Case=="large-unread-error-skip" {if !dto.SourceMessageUnreadTruthy()||dto.SourceMessageUnreadText()!="1267650600228229401496703217721"{t.Fatal("source arbitrary integer unread message lost")}}
 })}
}
func TestIndependentRealSourceNullEmptyAndNestedDTO(t *testing.T){
 raw,err:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/sqlite-source/r3-stdout.json");if err!=nil{t.Fatal(err)}
 var fixture struct {Cases []struct {Case string;Data json.RawMessage `json:"model_dump"`} `json:"dto_cases"`};if json.Unmarshal(raw,&fixture)!=nil||len(fixture.Cases)!=4{t.Fatal("actual Pydantic4")}
 for _,sample:=range fixture.Cases{t.Run(sample.Case,func(t *testing.T){var dto SourceUserData;if err:=json.Unmarshal(sample.Data,&dto);err!=nil{t.Fatal(err)};got,err:=json.Marshal(dto);if err!=nil||!reflect.DeepEqual(independentSourceSemantic(got),independentSourceSemantic(sample.Data)){t.Fatalf("source nullable/nested/integer DTO changed got %s want %s err %v",got,sample.Data,err)}})}
}
func TestIndependentRealSourceHugeFloatBindingGate(t *testing.T) {
 raw,err:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/binding-source-widefloat/r1-stdout.json");if err!=nil{t.Fatal(err)}
 var fixture struct{Cases []struct{Case string; Current json.RawMessage `json:"current_before"`; Existing bool; Outcome struct{Raises string; Data json.RawMessage}}}
 if json.Unmarshal(raw,&fixture)!=nil||len(fixture.Cases)!=2{t.Fatal("actual Float2")}
 for _,c:=range fixture.Cases{t.Run(c.Case,func(t *testing.T){var dto SourceUserData;if err:=json.Unmarshal(c.Current,&dto);err!=nil{t.Fatal("valid current rejected",err)};out,err:=json.Marshal(dto);if err!=nil||!reflect.DeepEqual(independentSourceSemantic(out),independentSourceSemantic(c.Current)){t.Fatal("400-digit current changed")};if dto.ValidateSourceAccountBinding()==nil{t.Fatal("actual Float binding OverflowError not detected")};if c.Existing && len(c.Outcome.Data)==0{t.Fatal("source err skip fixture missing original DTO")}})}
}
func TestIndependentRealSourceNullInsertClone(t *testing.T) {
 raw,err:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/binding-source-nulls/r1-stdout.json");if err!=nil{t.Fatal(err)}
 var fixture struct{Cases []struct{Case string;Current json.RawMessage `json:"current_before"`; Existing bool; Stored []map[string]json.RawMessage}}
 if json.Unmarshal(raw,&fixture)!=nil||len(fixture.Cases)!=2{t.Fatal("actual SQL null2")}
 fields:=[]string{"bonus","upload","download","ratio","seeding","leeching","seeding_size","leeching_size","message_unread","seeding_info","message_unread_contents"}
 for _,c:=range fixture.Cases{t.Run(c.Case,func(t *testing.T){var dto SourceUserData;if err:=json.Unmarshal(c.Current,&dto);err!=nil{t.Fatal(err)};before,_:=json.Marshal(dto);stored:=&dto
 if !c.Existing{stored,err=dto.SourceAccountInsertClone();if err!=nil{t.Fatal(err)}}
 out,err:=json.Marshal(stored);if err!=nil{t.Fatal(err)};var got map[string]json.RawMessage;if json.Unmarshal(out,&got)!=nil{t.Fatal("stored clone")}
 for _,key:=range fields{if !reflect.DeepEqual(independentSourceSemantic(got[key]),independentSourceSemantic(c.Stored[0][key])){t.Fatalf("%s got %s source %s",key,got[key],c.Stored[0][key])}}
 after,_:=json.Marshal(dto);if !bytes.Equal(before,after){t.Fatal("current DTO mutated by INSERT clone")}
 })}
}
