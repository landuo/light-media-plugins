package app

import (
 "bytes"
 "encoding/json"
 "math/big"
 "net/http"
 "net/http/httptest"
 "os"
 "reflect"
 "testing"

 "light-media/internal/plugins"
)

func independentSourceAppSemantic(raw []byte) any {
 d:=json.NewDecoder(bytes.NewReader(raw));d.UseNumber();var v any;if e:=d.Decode(&v);e!=nil{panic(e)}
 var convert func(any)any;convert=func(v any)any{switch x:=v.(type){case json.Number:r,ok:=new(big.Rat).SetString(string(x));if !ok{panic(x)};return struct{Exact string}{r.RatString()};case []any:for i:=range x{x[i]=convert(x[i])};case map[string]any:for k:=range x{x[k]=convert(x[k])}};return v};return convert(v)
}
func TestIndependentActualSDKSourceSQLBoundary(t *testing.T) {
 type sample struct{Case string; Existing bool; Current json.RawMessage `json:"current_before"`; Outcome struct{Raises string; Data json.RawMessage};Stored []map[string]json.RawMessage;Trace []struct{Op string} `json:"source_trace"`}
 for _,sourceFile:=range []string{"binding-source/r1-stdout.json","binding-source-widefloat/r1-stdout.json","binding-source-nulls/r1-stdout.json"}{
  raw,e:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/"+sourceFile);if e!=nil{t.Fatal(e)};var f struct{Cases []sample};if json.Unmarshal(raw,&f)!=nil||len(f.Cases)==0{t.Fatal("raw source fixture")}
  for _,c:=range f.Cases{if bytes.Equal(c.Current,[]byte("null")){continue};t.Run(c.Case,func(t *testing.T){
   a,cookie,module:=ownedModuleFixture(t,true);worker:=sourceSitesFixture(t,a,cookie)
   peer:=httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){if r.URL.Path!="/"&&r.URL.Path!="/favicon.ico"{t.Error("terminal source DTO unexpectedly reached native network",r.URL.Path)};w.WriteHeader(503)}));defer peer.Close()
   site:=installResourceBrowseSite(t,a,peer.URL)
   if c.Existing{sourceSitesSetModule(t,a,cookie,module,json.RawMessage(`{"userid":"old","upload":5,"err_msg":""}`));sourceSitesData(t,worker,"source_refresh",site.ID)}
   var beforeEvents int;if e:=a.Store.DB.QueryRow(`SELECT count(*) FROM domain_events WHERE json_extract(CAST(payload AS TEXT),'$.event_type')='site.refreshed'`).Scan(&beforeEvents);e!=nil{t.Fatal(e)}
   sourceSitesSetModule(t,a,cookie,originalBaseSDKLoaded(t,a,ownedModuleID),c.Current)
   var got plugins.SiteSourceRefreshResultV1;err:=hostDownloaderCall(t,worker,"source_refresh",plugins.SiteHostRefreshV1{ID:site.ID},&got)
   if c.Outcome.Raises!=""{if err==nil{t.Fatal("actual source SQL binding failure became success")}}else{if err!=nil{t.Fatal(err)};if !reflect.DeepEqual(independentSourceAppSemantic(got.Data),independentSourceAppSemantic(c.Outcome.Data)){t.Fatalf("current DTO changed\ngot %s\nsource %s",got.Data,c.Outcome.Data)}}
   var afterEvents int;if e:=a.Store.DB.QueryRow(`SELECT count(*) FROM domain_events WHERE json_extract(CAST(payload AS TEXT),'$.event_type')='site.refreshed'`).Scan(&afterEvents);e!=nil{t.Fatal(e)}
   wantEvents:=0;for _,x:=range c.Trace{if x.Op=="event"{wantEvents++}};if afterEvents-beforeEvents!=wantEvents{t.Fatalf("source effect order/count: events delta %d want %d",afterEvents-beforeEvents,wantEvents)}
   var stored plugins.SiteAccountHostResultV1;if e:=hostDownloaderCall(t,worker,"source_accounts",plugins.SiteAccountHostRequestV1{ID:site.ID},&stored);e!=nil{t.Fatal(e)}
   if len(stored.Items)!=len(c.Stored){t.Fatalf("source rows %d got %d",len(c.Stored),len(stored.Items))}
   if len(c.Stored)>0{var fields map[string]json.RawMessage;if e:=json.Unmarshal(stored.Items[0].Fields,&fields);e!=nil{t.Fatal(e)}
    for _,key:=range []string{"username","userid","user_level","join_at","bonus","upload","download","ratio","seeding","leeching","seeding_size","leeching_size","seeding_info","message_unread","message_unread_contents","err_msg"}{if !reflect.DeepEqual(independentSourceAppSemantic(fields[key]),independentSourceAppSemantic(c.Stored[0][key])){t.Fatalf("historical %s got %s source %s",key,fields[key],c.Stored[0][key])}}
   }
  })}
 }
}
