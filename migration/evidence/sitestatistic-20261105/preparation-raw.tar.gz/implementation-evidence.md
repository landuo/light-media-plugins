# SiteStatistic implementation evidence — coordinator handoff

This is a business implementation/evidence handoff, not the migration ledger or a claim of actual-host acceptance. Only `plugins/sitestatistic/**` and `cmd/site-statistic/**` were changed for the product. TorrentTransfer's 32-file freeze, shared SDK, go.mod, registry and ledger were not edited by this worker.

## Inputs and reused code

Installed plugin 1.9.7: source snapshot content commit `270ae0bcbf1d270b916ca9b14f8bffff9b1938d0`; full 1122-line plugin SHA-256 `763a88be85185a94082a2f131ed1c80d8306abe24b10ebe9ae95447cfe5da17d`. Full source was read before existing Go; the original source-first contract is `source-contract.json`, method lines and helper boundaries are in `preparation.md`. Its initial read-only status is historical, not the current implementation status.

`reuse-inputs.json` individually binds the original host pure algorithm/form, legacy delegates (rejected architecture), original host references and prior 24+14 fixture. `plugins/sitestatistic/ORIGIN.md` records exact reuse hashes, source-to-target functions and necessary platform adaptations. The host pure algorithm seed was corrected after source execution exposed eager date validation, scientific representation and compensated sum differences. Product uses no `builtin.site.statistics.*` executor, journal, Python runtime, AI, workflow or RSA machinery.

Actual live source references additionally bind Base.to_dict/model column order, Site schema/Response schema, common SiteChain, compiled SitesHelper, core event/API manager and LocaleHelper/catalogs. Compiled helper behavior comes from the separate SDK author's owned actual-image probe/r9 getter-copy correction; unavailable REA providers were not represented as successful decompilation. Official authentication-level checking is explicitly excluded by the user's scope.

## Executed original program evidence

1. `execution/python312-source-oracle.json`: exact installed image `sha256:33354456e8e19c65193b9ca471e45450a620c541759cc42e76cf00a03b025881`, Python3.12.13. Actual plugin/StringUtils AST, 24 historical statistics cases, 14 formats, six additional source cases. Old local3.14 outputs match actual3.12 for those inputs. These fixtures exercise source selection, page, dashboard, precision and notification body/fingerprint. Schema shells/owned resource recorders are expressly not a complete source application import.
2. `execution/python312-character-oracle.json`: same actual image, original model/Base methods in the isolated shell, exact Unicode15.0.0 digit/decimal/space profile, 17 integer/float inputs, 11 date inputs and five metadata exception cases. The independent reviewer separately ran actual SQLAlchemy/Pydantic AST against in-memory SQLite and confirmed user-id/name superscript-digit values are genuinely storable/reachable, and confirmed all 21 source model columns/order.
3. `execution/entry-source-observations.json`: original AST init/raw config/one-shot/API/event/concurrency entry traces using owned recorders. Historical local3.14 scope is explicit; this does not execute real source services.
4. `reference/notification-mode-source.json`: independent actual send_msg/format/approximation/fingerprint AST with an ordered config-member read stream. Two mixed-mode messages/receipts bind live reads during the arithmetic loop, not only reload during data I/O. Local3.14, synthetic owned rows, no real event/network.
5. `execution/locale-source-oracle.json`: captured complete stdlib LocaleHelper and exact captured catalogs, 21 request-language choices and 48 translations of the four API response forms (including newline domains and static Chinese capture values). Local3.14, synthetic request dictionaries, no actual middleware. The earlier source-only formatter capture supplies 33 Python str/repr cases and is correctly labeled local3.14/vendor serialization rather than Site execution.

The actual-image Python probes used only new task-owned input directories/marked containers, no production app import or network, `--rm --network none --read-only --tmpfs /tmp --cap-drop ALL --security-opt no-new-privileges --user1000:1000 --entrypoint python3`, minimal read-only input mounts and `-I -S -B`. Task container/remote-directory cleanup was checked and completed. No NAS runtime/test container remains from this worker.

## Production structure and same-algorithm checks

`config.go`/`plugin.go`: persistent object, raw state, literal form, falsey init, onlyonce member retention, input mutation before TZ validation, private date admission before config save. No-op source stop/reinit deliberately leaves old date jobs alive. Init config saving changes only onlyonce, preserves other raw JSON values/order and repeated-key first slots, with arbitrary-size integers. No public cron/command is invented.

`selection.go`/`data_pass.go`: one original source selection cursor, used by source differential helpers and the actual worker. Latest then active list then lazy date cache/name fallback; no eager history validation. One missing date per fresh admitted callback, original owner waits whole pass. No persisted continuation, replay, workflow or retained HostCaller. Cancellation seals queued tokens and cancels/joins active reads.

`row.go`/`characters.go`/`types.go`/`views.go`: original model field traversal, independent traffic baselines, numeric metadata failures, exact observed Python Unicode/date conversion, float/int distinction, source precision grid and 3.12 sum, complete Vuetify page/dashboard tree. Imported/source-history DTOs are never confused with current refresh DTOs.

`notification.go`: complete body/fingerprint/dedup state, sort-key collision behavior, original post-before-save critical section and retry-after-save-failure behavior. Mode is fetched at every original source arithmetic/format/totals/receipt read; initial gate and debug also remain distinct reads. Whole-job locking is not added.

`host.go`/`refresh.go`/`locale.go`: finite SourceAccounts/SourceIndexer/SourceRefresh/SourceRefreshAll. Common host SiteChain owns all refresh loop, per-site effects, stop checks and global event. Exact current attempt DTO/null drives API, not daily stored state. Catalog-only helper entries without canonical current identity cannot authorize network. API token is a host boolean match, never a worker secret. Response preserves original message and request-local message_i18n behavior with only static message/pattern catalog sections.

## Actual independent executable SDK tests

`cmd/site-statistic/main_test.go` builds and starts the actual CLI with `--manifest` and standard ServeConcurrent. The host resources are synthetic, so this is **not** App, real site HTTP, browser or production acceptance.

- Forty current sites with disjoint eight-day windows require 280 real typed SourceAccounts date requests. Total is 566 host RPCs, 286 returned phases, maximum three host calls per callback. SDK default64/max256 limits are unchanged. Events retain owner/child begin/end sequencing and per-callback budget observations. Parent get_page completes only after the entire pass.
- Each submitted callback gets a fresh caller; parent return revokes its scope. The instance identity is a clone-specific synthetic owned identity, not a config-supplied target.
- Enabled=false one-shot uses a real three-second clock, remains scheduled after ordinary no-op stop and invokes SourceRefreshAll once. No zero-delay overlay is used for this real SDK test.
- Under outer `go test -race`, the separately built worker also uses `go build -race`; this is recorded in observations rather than merely asserting the driver is race-instrumented.

`cmd/site-statistic/lifecycle_test.go` independently executes that real worker:

- Queued owner cancel: late admitted continuation returns zero host calls and zero queries.
- Active owner cancel: host query context is revoked, child returns the expected SDK execution_canceled, no further query is admitted; same worker remains usable.
- Active no-op stop plus disabled reinit: page owner stays pending until the final query is released, then returns its whole result once; same worker remains usable.
- Pending one-shot session retirement: SDK Stop joins the waiting callback before the three-second date, with zero refresh calls. This mandatory process/scope boundary remains distinct from source's ordinary no-op stop.

`plugins/sitestatistic/*_test.go` consumes the original fixtures and typed resource outcomes. Post/save errors, native current null/error DTOs, invalid canonical identity, wrong key short-circuit, form/defaults, raw/falsey config, reload during query, mutable mode reads and notification dedup are covered. A direct disabled send_msg test is explicitly not evidence that host broadcasts deliver to disabled instances.

## Known evidence limits and required coordinator acceptance

SDK `site_source.go` is a complete byte-exact frozen host file, SHA-256 `36f6c6ab2d0650f899f244460d709b4006a9df8c954cb50023145ad9c5a5b58d`; companion test SHA `45f8a3a83a41b74ddbba1e91e608d278c315f537a52c0bf37522fdeed6613b8a`. The SDK author reports host App normal/race112 and native/SDK race982 pass with vet0; these are the author's results, not worker-run actual main acceptance. Root owns SDK_ORIGIN/final host commit and the host publication gate. Source capabilities are additions beyond original host75e and must not be claimed present in that old commit.

Source native DB row ID maps to existing stable records.rowid; imported IDs stay imported. This differs from MoviePilot's separate autoincrement sequence. Only the presence/value in source subtraction changes internally; id is not displayed, sorted or treated as user traffic, and the current API DTO remains19fields. Read-only history name/date/SQL order and all stored current/null/default behavior are host SourceAccounts responsibilities, with separate native/App tests.

Existing canonical identity, credentials, cancellation, the default 128KiB generic resource request decoder, 16MiB storage/result values and logical IPC envelope limits remain mandatory. Very large histories/components/notifications can therefore receive a platform size error; no artificial history cap, pagination or truncated/false-success output is introduced. No actual large-size boundary failure has been relabeled as a source success.

Original APScheduler.print_jobs is an interpreter stdout diagnostic; the worker reserves stdout for IPC and does not invent an instance business log from that listing. Config/private TZ uses settings default Shanghai only when unset, while notification date/time uses process-local timezone. Worker contexts are retired and joined by platform session lifetime even though source stop_service itself is no-op.

Actual host/site HTTP, request middleware/auth status, disabled-broadcast gate versus disabled API, browser generic VApexChart rendering, clone namespace separation, cold restart/update/reset/uninstall and real site collection are still coordinator acceptance. No production site/configuration, notification recipient or credentials were used, and no success claim is made for these unexecuted gates.
