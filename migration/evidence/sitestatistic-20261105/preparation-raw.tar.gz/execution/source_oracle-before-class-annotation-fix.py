"""Execute only captured source AST with owned in-memory dependencies.

Never import the application or a production plugin. This is a test harness,
not a Python runtime for the new Go product.
"""
import ast
import bisect
import copy
import hashlib
import json
import math
import re
import sys
import threading
import typing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from urllib import parse
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
SOURCE = ROOT / "work/migration-20261105/source-snapshot/sitestatistic/__init__.py"
REF = ROOT / "work/migration-20261105/host-reference"
OLD = Path("/Users/accidia/projects/light-media/testdata/plugins/site-statistic-original-oracle.json")
SCHEMAS = ROOT / "work/migration-20261105/site-helper-reference"
STATE = None


def clean(value):
    if isinstance(value, SchemaModelBase):
        return clean(value.model_dump())
    if isinstance(value, Row):
        return clean(value.to_dict())
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [clean(v) for v in value]
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, set):
        return sorted(value)
    if callable(value):
        return getattr(value, "__name__", "callback")
    return copy.deepcopy(value)


def trace(op, **data):
    STATE.trace.append({"op": op, **clean(data)})


class Row:
    def __init__(self, fields):
        self.fields = copy.deepcopy(fields)

    def __getattr__(self, key):
        if key in self.fields:
            return self.fields[key]
        if key in {"updated_time", "username", "user_level", "upload", "download", "bonus", "ratio", "seeding", "seeding_size", "err_msg"}:
            return None
        raise AttributeError(key)

    def to_dict(self):
        return copy.deepcopy(self.fields)

    def model_dump(self):
        return self.to_dict()

    def dict(self):
        trace("dto.dict")
        return self.to_dict()


class FactoryDefault:
    def __init__(self, factory):
        self.factory = factory


class SchemaModelBase:
    """Valid-input defaults/after-validator shell, not a Pydantic validator.

    Source annotations/defaults and Response's after-validator run unchanged.
    Type coercion/validation and production locale translation are not modeled.
    """
    def __init__(self, **fields):
        for key in self.__annotations__:
            default = getattr(type(self), key, None)
            value = fields.get(key, default.factory() if isinstance(default, FactoryDefault) else copy.deepcopy(default))
            setattr(self, key, value)
        for method in type(self).__dict__.values():
            if callable(method) and getattr(method, "source_after", False):
                method(self)

    def model_dump(self):
        return {k: copy.deepcopy(getattr(self, k)) for k in self.__annotations__}

    def dict(self):
        trace("dto.dict")
        return self.model_dump()


def after_validator(**_):
    def decorate(method):
        method.source_after = True
        return method
    return decorate


class Clock(datetime):
    @classmethod
    def now(cls, tz=None):
        value = STATE.now
        return value.astimezone(tz) if tz else value.replace(tzinfo=None)


class Logger:
    def __getattr__(self, level):
        return lambda text: trace("log", level=level, text=str(text))


class Base:
    def get_data(self, key):
        trace("get_data", key=key)
        return copy.deepcopy(STATE.data.get(key))

    def save_data(self, key, value):
        trace("save_data", key=key, value=value)
        if STATE.fail_save:
            raise RuntimeError("owned save failure")
        STATE.data[key] = copy.deepcopy(value)

    def post_message(self, **fields):
        trace("post_message", fields=fields)
        if STATE.fail_post:
            raise RuntimeError("owned post failure")
        STATE.notices.append(copy.deepcopy(fields))
        return STATE.post_result

    def update_config(self, config):
        trace("update_config", value=config)


class Event:
    def __init__(self, event_data):
        self.event_data = event_data


class Events:
    def register(self, _):
        return lambda f: f

    def send_event(self, kind, data):
        trace("event", kind=kind, data=data)


class SiteOper:
    def get_userdata_latest(self):
        trace("latest")
        if STATE.concurrent_barrier is not None:
            STATE.concurrent_barrier.wait(timeout=5)
        return [Row(r) for r in STATE.latest]

    def list_active(self):
        trace("active")
        return [SimpleNamespace(domain=d) for d in STATE.active]

    def get_userdata_by_date(self, date):
        trace("date", date=date)
        if date == STATE.fail_date:
            raise RuntimeError("owned historical query failure")
        return [Row(r) for r in STATE.history if r["updated_day"] == date]

    def update_userdata(self, **kwargs):
        trace("update_userdata", **kwargs)


class SitesHelper:
    def get_indexer(self, domain):
        trace("get_indexer", domain=domain)
        return copy.deepcopy(STATE.indexers.get(domain))

    def get_indexers(self):
        trace("get_indexers")
        return copy.deepcopy(STATE.all_indexers)


class Response:
    def __init__(self, **fields):
        # No invented Pydantic defaults: record source constructor arguments.
        self.fields = fields


class Scheduler:
    def __init__(self, timezone):
        trace("scheduler", timezone=timezone)
        ZoneInfo(timezone)

    def add_job(self, callback, kind, **kwargs):
        trace("add_job", callback=callback, kind=kind, **kwargs)

    def print_jobs(self):
        trace("print_jobs")

    def start(self):
        trace("scheduler.start")


class ChainBase:
    def run_module(self, method, site):
        trace("run_module", method=method, site=site)
        if STATE.stop_after == len([t for t in STATE.trace if t["op"] == "run_module"]):
            ENV["global_vars"].is_system_stopped = True
        if STATE.refresh_raises:
            raise RuntimeError("owned module failure")
        value = STATE.refreshes.get(site.get("id"))
        return SourceSchemaUserData(**value) if value is not None else None

    def post_message(self, notification):
        trace("chain.post_message", fields=notification.fields)

    @property
    def messageoper(self):
        return SimpleNamespace(exists_by_source=lambda _: False)


class Notification:
    def __init__(self, **fields):
        self.fields = fields


def source_class(path, class_name, methods=None, renamed=None, base=None):
    tree = ast.parse(path.read_text())
    node = copy.deepcopy(next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name))
    if methods is not None:
        node.body = [n for n in node.body if isinstance(n, ast.FunctionDef) and n.name in methods]
    if renamed:
        node.name = renamed
    if base:
        node.bases = [ast.Name(id=base, ctx=ast.Load())]
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), str(path), "exec"), ENV)
    return ENV[node.name]


ENV = {**vars(typing), "__name__": "owned_source_ast", "datetime": Clock, "timedelta": timedelta,
       "math": math, "hashlib": hashlib, "re": re, "bisect": bisect, "parse": parse,
       "_PluginBase": Base, "SiteUserData": Row, "Event": Event, "SiteOper": SiteOper,
       "SitesHelper": SitesHelper, "logger": Logger(), "lock": threading.Lock(),
       "eventmanager": Events(), "EventType": SimpleNamespace(SiteRefreshed="site.refreshed"),
       "NotificationType": SimpleNamespace(SiteMessage="站点消息"), "Notification": Notification,
       "settings": SimpleNamespace(TZ="Asia/Shanghai", API_TOKEN="owned-synthetic-api-key"),
       "global_vars": SimpleNamespace(is_system_stopped=False), "ChainBase": ChainBase,
       "BackgroundScheduler": Scheduler, "pytz": SimpleNamespace(timezone=ZoneInfo),
       "schemas": SimpleNamespace(Response=Response)}
string_tree = ast.parse((REF / "app/utils/string.py").read_text())
ENV["_special_domains"] = ast.literal_eval(next(n.value for n in string_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "_special_domains" for t in n.targets)))
StringUtils = source_class(REF / "app/utils/string.py", "StringUtils", {"str_filesize", "get_url_domain", "get_url_netloc"})
ENV.update(BaseModel=SchemaModelBase, Field=lambda *, default_factory: FactoryDefault(default_factory),
           model_validator=after_validator,
           LocaleHelper=SimpleNamespace(get_current_locale=lambda: "owned-identity-locale", translate_text=lambda text, **_: text))
SourceSchemaUserData = source_class(SCHEMAS / "site.py", "SiteUserData", renamed="SourceSchemaUserData")
SourceSchemaResponse = source_class(SCHEMAS / "response.py", "Response", renamed="SourceSchemaResponse")
ENV["schemas"].Response = SourceSchemaResponse
SiteChain = source_class(REF / "app/chain/site.py", "SiteChain", {"refresh_userdata", "refresh_userdatas", "_post_site_messages"}, base="ChainBase")
Plugin = source_class(SOURCE, "SiteStatistic")


def reset(latest=(), history=(), active=()):
    global STATE
    STATE = SimpleNamespace(latest=copy.deepcopy(latest), history=copy.deepcopy(history), active=list(active), trace=[],
                            now=datetime(2026, 10, 16, 12, 34, 56, tzinfo=timezone(timedelta(hours=8))),
                            data={}, notices=[], fail_save=False, fail_post=False, post_result=None, fail_date=None,
                            indexers={}, all_indexers=[], refreshes={}, refresh_raises=False, stop_after=None,
                            concurrent_barrier=None)
    ENV["settings"].TZ = "Asia/Shanghai"
    ENV["global_vars"].is_system_stopped = False
    return Plugin()


def attempt(callback):
    try:
        value = callback()
        return {"value": clean(value.fields if isinstance(value, Response) else value)}
    except Exception as e:
        return {"raised": type(e).__name__, "message": str(e)}


def capture_case(c):
    p = reset(c["latest"], c["history"], c["active_domains"])
    p._notify_type = c["notify_type"]
    day, current, previous = p._SiteStatistic__get_data()
    result = {k: copy.deepcopy(c[k]) for k in ("name", "latest", "history", "active_domains", "notify_type")}
    result.update(day=day, current=clean(current), previous=clean(previous), page=p.get_page(), dashboards={})
    for mode in ("today", "total", "all"):
        p._dashboard_type = mode
        cols, attrs, elements = p.get_dashboard("ignored", user_agent="owned")
        result["dashboards"][mode] = {"cols": cols, "attrs": attrs, "elements": elements}
    p.send_msg(Event({"site_id": "*"}))
    result.update(notifications=copy.deepcopy(STATE.notices),
                  last_notify=copy.deepcopy(STATE.data.get("last_notify")))
    result["trace"] = copy.deepcopy(STATE.trace)
    return result


def row(name="Owned", domain="owned.invalid", day="2026-10-16", **fields):
    return {"name": name, "domain": domain, "updated_day": day, "username": "owned", "user_level": "User",
            "upload": 200.0, "download": 100.0, "ratio": 2.0, "bonus": 1.0,
            "seeding": 2.0, "seeding_size": 1024.0, "err_msg": "", **fields}


def main():
    old = json.loads(OLD.read_text())
    historical = []
    differences = []
    for c in old["cases"]:
        captured = capture_case(c)
        historical.append(captured)
        bad = [k for k, expected in c.items() if captured.get(k) != expected]
        if bad:
            differences.append({"case": c["name"], "fields": bad})
    reset()
    formats = [{"value": c["value"], "text": Plugin._SiteStatistic__format_filesize(c["value"])} for c in old["formats"]]
    format_diff = [i for i, (a, b) in enumerate(zip(formats, old["formats"])) if a != b]
    pure_inputs = [
        {"name": "inactive-invalid-current-date", "latest": [row(domain="inactive.invalid", day="not-a-date")], "history": [], "active_domains": ["owned.invalid"], "notify_type": "inc"},
        {"name": "unqueried-invalid-history", "latest": [row()], "history": [row(day="not-a-date")], "active_domains": ["owned.invalid"], "notify_type": "inc"},
        {"name": "large-chart-float-repr", "latest": [row(upload=1e28, seeding=1e20)], "history": [row(day="2026-10-15", upload=1.0)], "active_domains": ["owned.invalid"], "notify_type": "inc"},
        {"name": "large-chart-sum", "latest": [row(name="Large", upload=1e16*(1<<30)), row(name="One", upload=float((1<<30)+1)), row(name="Two", upload=float((1<<30)+1))], "history": [row(name=n, day="2026-10-15", upload=1.0) for n in ("Large", "One", "Two")], "active_domains": ["owned.invalid"], "notify_type": "inc"},
        {"name": "date-cache-reused-across-names", "latest": [row(name="A"), row(name="B")], "history": [], "active_domains": ["owned.invalid"], "notify_type": "inc"},
        {"name": "duplicate-history-name-last-value", "latest": [row()], "history": [row(day="2026-10-15", upload=10.0), row(domain="removed.invalid", day="2026-10-15", upload=30.0)], "active_domains": ["owned.invalid"], "notify_type": "inc"},
    ]
    additional = [capture_case(c) for c in pure_inputs]
    entries = []
    for name, kind, event in [("missing-event", "inc", None), ("single-site-event", "inc", Event({"site_id": 7})), ("disabled-notify", "", Event({"site_id": "*"})), ("missing-site-id", "inc", Event({}))]:
        p = reset([row()], [row(day="2026-10-15", upload=100.0)], ["owned.invalid"])
        p._notify_type = kind
        entries.append({"name": name, "result": attempt(lambda: p.send_msg(event)), "trace": copy.deepcopy(STATE.trace)})
    for scenario in ("duplicate", "changed", "new-day", "new-type", "save-fails", "post-fails", "false-post-return", "malformed-last-notify"):
        p = reset([row()], [row(day="2026-10-15", upload=100.0)], ["owned.invalid"])
        p._notify_type = "inc"
        p.send_msg(Event({"site_id": "*"}))
        STATE.trace = []
        STATE.notices = []
        if scenario == "changed": STATE.latest[0]["upload"] = 300.0
        if scenario == "new-day": STATE.now += timedelta(days=1)
        if scenario == "new-type": p._notify_type = "all"
        if scenario in ("save-fails", "post-fails", "false-post-return"): STATE.data.clear()
        STATE.fail_save = scenario == "save-fails"
        STATE.fail_post = scenario == "post-fails"
        STATE.post_result = False if scenario == "false-post-return" else None
        if scenario == "malformed-last-notify": STATE.data["last_notify"] = "malformed"
        entries.append({"name": "notification-"+scenario, "result": attempt(lambda: p.send_msg(Event({"site_id": "*"}))), "trace": copy.deepcopy(STATE.trace), "data": copy.deepcopy(STATE.data)})
    for name, payload, key, found, raises in [("wrong-token", None, "wrong", True, False), ("missing-indexer", None, "owned-synthetic-api-key", False, False), ("none-current-dto", None, "owned-synthetic-api-key", True, False), ("none-current-dto-existing-day", None, "owned-synthetic-api-key", True, False), ("empty-current-dto", {}, "owned-synthetic-api-key", True, False), ("returned-error-dto", {"username": None, "userid": 2**100, "upload": None, "ratio": 0.0, "err_msg": "owned ordinary failure", "updated_day": None, "message_unread": 0}, "owned-synthetic-api-key", True, False), ("source-host-raises", None, "owned-synthetic-api-key", True, True)]:
        p = reset()
        if name == "none-current-dto-existing-day": STATE.latest = [row()]
        if found: STATE.indexers["raw-domain"] = {"id": 7, "name": "Owned", "domain": "https://owned.invalid/"}
        STATE.refreshes[7] = payload
        STATE.refresh_raises = raises
        entries.append({"name": "api-"+name, "result": attempt(lambda: p.refresh_by_domain("raw-domain", key)), "trace": copy.deepcopy(STATE.trace)})
    for scenario in ("none", "error-dto", "stop-mid-loop", "none-active", "duplicate-names"):
        reset()
        STATE.all_indexers = [{"id": n, "name": "Owned", "domain": "https://owned.invalid/", "is_active": scenario != "none-active"} for n in (1, 2)]
        if scenario in ("error-dto", "stop-mid-loop"):
            STATE.refreshes[1] = {"ratio": 0.0, "message_unread": 0, "err_msg": "owned error"}
        if scenario == "duplicate-names":
            STATE.refreshes.update({1: {"username": "First"}, 2: {"username": "Second"}})
        if scenario == "stop-mid-loop": STATE.stop_after = 1
        entries.append({"name": "all-refresh-"+scenario, "result": attempt(lambda: SiteChain().refresh_userdatas()), "trace": copy.deepcopy(STATE.trace)})
    p = reset()
    results = [attempt(lambda: p.init_plugin({"enabled": False, "onlyonce": True, "dashboard_type": "odd", "notify_type": "odd"})), attempt(lambda: p.stop_service()), attempt(lambda: p.init_plugin(None)), attempt(lambda: p.init_plugin({}))]
    entries.append({"name": "one-shot-members-stop-and-falsey-reinit", "results": results, "state": {"enabled": p._enabled, "onlyonce": p._onlyonce, "dashboard": p._dashboard_type, "notify": p._notify_type}, "trace": copy.deepcopy(STATE.trace)})
    p = reset()
    ENV["settings"].TZ = ""
    config = {"onlyonce": True}
    entries.append({"name": "one-shot-invalid-zone-after-input-flag-mutation", "result": attempt(lambda: p.init_plugin(config)), "mutated_input": copy.deepcopy(config), "member_onlyonce": p._onlyonce, "trace": copy.deepcopy(STATE.trace)})
    p = reset([row()], [], ["owned.invalid"])
    STATE.fail_date = "2026-10-14"
    entries.append({"name": "history-error-after-first-query", "result": attempt(lambda: p.get_page()), "trace": copy.deepcopy(STATE.trace)})
    p = reset([row()], [row(day="2026-10-15", upload=100.0)], ["owned.invalid"])
    p._notify_type = "inc"
    STATE.concurrent_barrier = threading.Barrier(2)
    results = []
    def concurrent_notify():
        results.append(attempt(lambda: p.send_msg(Event({"site_id": "*"}))))
    threads = [threading.Thread(target=concurrent_notify) for _ in range(2)]
    for thread in threads: thread.start()
    for thread in threads: thread.join(timeout=6)
    assert all(not thread.is_alive() for thread in threads)
    entries.append({"name": "concurrent-identical-notification-lock", "results": results, "notifications_count": len(STATE.notices), "data": copy.deepcopy(STATE.data), "trace": copy.deepcopy(STATE.trace)})
    nonfinite = [{"input": str(v), "result": attempt(lambda v=v: Plugin._SiteStatistic__format_filesize(v))} for v in (float("inf"), float("-inf"), float("nan"), "1e3", [], {})]
    binding = {"kind": "actual captured source AST with synthetic owned dependencies; no application/package import or network", "python": sys.version, "runtime_limit": "Installed source runtime is Python3.12.13; this run uses local interpreter, including its built-in sum/round. No claim of actual installed runtime execution.", "schema_limit": "Actual live SiteUserData/Response class AST defaults and Response validator execute in a valid-input BaseModel shell. No Pydantic type validation/coercion or actual LocaleHelper translation is claimed; owned locale returns text unchanged.", "files_sha256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [SOURCE, REF/"app/chain/site.py", REF/"app/utils/string.py", SCHEMAS/"site.py", SCHEMAS/"response.py", OLD, Path(__file__)]}}
    for filename, result in [("historical-replay.json", {**binding, "cases": historical, "formats": formats}), ("historical-comparison.json", {"cases": len(historical), "formats": len(formats), "case_differences": differences, "format_differences": format_diff}), ("additional-source-oracle.json", {**binding, "cases": additional}), ("entry-source-observations.json", {**binding, "cases": entries, "format_type_edges": nonfinite})]:
        (OUT/filename).write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)+"\n")
    print(json.dumps({"historical_cases": len(historical), "historical_formats": len(formats), "case_differences": differences, "format_differences": format_diff, "additional_pure_cases": len(additional), "entry_cases": len(entries)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
