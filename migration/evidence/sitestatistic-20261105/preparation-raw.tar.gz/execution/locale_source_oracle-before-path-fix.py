"""Pure captured LocaleHelper only; stdlib, synthetic requests, no app import."""
import hashlib,json,platform,sys
from pathlib import Path
from types import SimpleNamespace
root=Path(__file__).resolve().parents[3]
source=root/'locale-source-reference/locale.py'
ns={'__file__':str(source),'__name__':'isolated_captured_locale'}
exec(compile(source.read_text(),str(source),'exec'),ns)
helper=ns['LocaleHelper']; helper._LOCALES_DIR=source.parent/'app/locales'
requests=[
 ('default',{},{}),('query',{'locale':'en_US'},{'x-locale':'zh-TW'}),
 ('bad-query',{'locale':'fr'},{'x-locale':'en'}),('empty-query',{'locale':''},{'x-locale':'en'}),
 ('blank-query',{'locale':' '},{'x-locale':'en'}),('first-header',{}, {'x-moviepilot-locale':'zh_Hant','x-locale':'en'}),
 ('bad-first-header',{}, {'x-moviepilot-locale':'fr','x-locale':'en'}),
 ('second-header',{}, {'x-locale':'\u001cen\u001f'}),
 ('quality',{}, {'accept-language':'fr;q=1,zh-TW;q=.3,en-US;q=.8'}),
 ('quality-tie',{}, {'accept-language':'en;q=0.2,zh-TW;q=0.2'}),
 ('unsupported',{}, {'accept-language':'fr;q=1,de;q=.9'}),
 ('bad-quality',{}, {'accept-language':'en;q=oops,zh-TW;q=.1'}),
 ('zero-quality',{}, {'accept-language':'en;q=0'}),
 ('negative-quality',{}, {'accept-language':'en;q=-1,zh-TW;q=-2'}),
 ('multiple-quality',{}, {'accept-language':'en;q=1;q=oops,zh-TW;q=.1'}),
 ('uppercase-quality',{}, {'accept-language':'en;Q=0,zh-TW;q=.1'}),
 ('nan-first',{}, {'accept-language':'fr;q=nan,en;q=.1,zh-TW;q=.5'}),
 ('nan-middle',{}, {'accept-language':'en;q=.1,fr;q=nan,zh-TW;q=.5'}),
 ('infinite-quality',{}, {'accept-language':'en;q=inf,zh-TW;q=1'}),
 ('unicode-quality',{}, {'accept-language':'en;q=٠.٩,zh-TW;q=0.5'}),
 ('underscore-quality',{}, {'accept-language':'en;q=0.1_0,zh-TW;q=0.2'}),
]
outputs=[]
for name,query,headers in requests:
 outputs.append({'name':name,'query':query,'headers':headers,'locale':helper.get_locale_from_request(SimpleNamespace(query_params=query,headers=headers))})
translations=[]
for locale in helper.SUPPORTED_LOCALES:
 for domain in ['fixture.invalid','任务已完成','a\nb','站点 foo 不存在']:
  for text in ['API密钥错误',f'站点 {domain} 不存在',f'站点 {domain} 刷新成功',f'站点 {domain} 刷新数据失败，未获取到数据']:
   translations.append({'locale':locale,'text':text,'translated':helper.translate_text(text,locale)})
files=[source,*sorted(helper._LOCALES_DIR.glob('*.json'))]
out={'classification':'captured complete pure stdlib LocaleHelper with synthetic requests; no app import, network or production state','python':platform.python_version(),'source_hashes':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'requests':outputs,'translations':translations,'limits':['Local Python3.14.4; source helper only uses stdlib; no current-request middleware or actual HTTP host is executed.']}
json.dump(out,sys.stdout,ensure_ascii=False,indent=2);print()
