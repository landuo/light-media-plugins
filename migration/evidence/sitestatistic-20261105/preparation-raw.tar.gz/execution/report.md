# SiteStatistic executable source baseline

This is test-only execution of the captured installed plugin, selected actual StringUtils/SiteChain methods, and the newly captured schema class AST. No original application/package, compiled SitesHelper, production configuration, scheduler, endpoint or network was imported or executed. All work is confined to this preparation directory and Go's normal build cache; no SiteStatistic product/SDK/host file was changed.

The source is the fixed 1.9.7 SHA `763a88be85185a94082a2f131ed1c80d8306abe24b10ebe9ae95447cfe5da17d`. The local interpreter is **Python 3.14.4**, while the installed source runtime is **3.12.13**. This baseline does not claim actual installed-runtime execution. In particular, the large-sum observation requires a 3.12 runtime check before declaring the final summation adaptation. Ordinary source control flow and exact Python-vs-Go fixed/scientific representation differences remain directly visible in the source and outputs.

## Executed commands and results

| Command | Result |
|---|---|
| `python3 work/migration-20261105/sitestatistic-preparation/execution/source_oracle.py` | Exit 0. Historical 24 cases + 14 formats rerun; zero differences from the historical oracle. Six additional pure cases and 28 entry/concurrency observations captured. |
| `go test -overlay /Users/accidia/projects/light-media-plugins/work/migration-20261105/sitestatistic-preparation/execution/overlay.json -count=1 -run TestPreparationSourceReplay -json ./internal/plugins/statistic` from `/Users/accidia/projects/light-media` | Exit **1**, deliberately preserved as a real reuse red result. Forty passing subtests: all historical 24+14 plus two additional cases. Four added cases fail, producing nine field assertions. The test compiled successfully. No business implementation was patched to make them pass. |

The Go comparison uses JSON numbers as exact rational values, so an integer/float lexical spelling difference is ignored while a different numeric value is retained. Text, ordering, nulls, lists, component shapes, notification body and fingerprint are compared. Expected results are generated only by the original AST, never by Go.

`historical-replay.json` contains the newly executed full page/dashboard/notice results and call traces; `historical-comparison.json` records zero differences. This is separate from the old fixture's historical execution claim. The first harness capture accidentally omitted notification `mtype` when serializing, producing 15 notice-only comparison failures. The old failed comparison is retained as `historical-comparison-before-harness-mtype-fix.json`; the harness now preserves the entire original notification dictionary. Neither source nor expected historical fixture was changed.

## Actual reuse differences found

| Added case | Original observation | Existing Go observation | Implication |
|---|---|---|---|
| inactive-invalid-current-date | Source filters inactive domain first, returns empty selection/page; no history query | `Select` eagerly validates every latest date and errors | Do not reuse eager Select validation before the original active filter. Whether a host canonical boundary independently rejects malformed account storage is a separate integration fact. |
| unqueried-invalid-history | Source requests only day-1…day-7; unrelated invalid-date row is never read | `Select` validates the supplied whole-history slice and errors | Build the source lazy per-date adapter/cache; passing a broadened full-history array into old Select changes error location. This is a standalone function-reuse difference, not a claim that the current host's bounded snapshot necessarily supplies that bad row. |
| large-chart-float-repr | Valid large float seeding total renders `1e+20`; chart total renders `9.313225746154785e+18 GB` | Old `pyFloat`/comma path always renders fixed decimal digits | The formatter is a useful seed, not fully source-equivalent for the allowed Float range. Keep Python scientific notation and comma-format behavior when porting. |
| large-chart-sum | Source runtime here yields title `1.0000000000000002e+16 GB` | Go yields `10000000000000000.0 GB` | Contains both representation and accumulation differences. Representation is clear; exact 3.12 built-in sum behavior remains an explicit runtime verification item. Do not silently port the naive accumulator as source-equivalent. |

The two additional passing cases bind per-invocation date caching across multiple names and last-by-name duplicate history selection, including a removed-domain history row. `pure-go-differences.json` records the exact failing component paths; `go-replay.jsonl` retains all actual test events.

## Newly executed entry contracts

`entry-source-observations.json` contains 28 independent scenarios with original call/log/data order:

1. Missing event, non-wildcard/missing site ID and falsey notification mode return before querying. Identical same-day body deduplicates; changed body, new day and new type send again. Post failure stops before save; save failure occurs **after** post; false return from post still saves. Malformed stored last_notify raises at its original access. Two concurrent identical events both calculate, but the actual module Lock admits one post/save and one duplicate skip.
2. Wrong API token returns before indexer lookup. Missing indexer returns before refresh. A None current DTO fails even when a synthetic existing latest daily row is present. An empty/default DTO and an error-bearing DTO are truthy and return success. The captured original SiteChain methods persist a model_dump copy, emit the single-site event, then return the source DTO; its null domain/day/time and arbitrary-precision userid survive into the source response dictionary. No saved daily-row substitution occurs.
3. All-None and no-active-site refreshes emit no global event. An error-bearing DTO still causes a single-site event and one final wildcard event. Duplicate site names overwrite the returned result dictionary while preserving both native call/event effects. A system-stop flag raised during the first refresh permits that call to finish but prevents the second call and final wildcard event.
4. A one-shot schedules while disabled, saves onlyonce=false but retains its true member, and source stop is no-op. Reinit(None) then raises; reinit({}) schedules another job. With an invalid private timezone, the supplied config's onlyonce flag has already been mutated before scheduler construction fails, but no update_config is called. This ordering differs from TT and must not be copied from TT's initializer.
5. A failed day-2 query is observed after day-1, preserving the actual failure point. Formatting inputs additionally cover infinity, negative infinity, NaN, scientific numeric strings and invalid container types as source observations; they are not relabeled valid JSON/typed host inputs.

## Schema and helper limits

Actual live `site.py` and `response.py` were added to the source binding. Source DTO types are nullable int traffic/counts/size, float bonus/ratio, nullable strings/dates, list structures and union string/int userid; the database snapshot model independently stores numeric history as Float. The actual Response declares success, message, message_i18n and data(default_factory=dict), then fills missing message_i18n through LocaleHelper.

The schema AST executes with a small **valid-input defaults/after-validator shell**, not Pydantic. It does not claim Pydantic type coercion, validation, warning behavior or actual LocaleHelper translation; the owned locale returns the original Chinese text. Response constructor/default/validator branch and DTO defaults/nulls are source-bound, while exact invalid-input Pydantic behavior remains unexecuted.

The initial schema shell incorrectly read annotations from an instance under Python3.14's deferred-annotation behavior. Its failed API observations are preserved in `entry-observations-before-harness-class-annotations-fix.json`; the shell now reads the class annotations and all API branches below were rerun. The final artifact contains proper source Response fields, not those harness exceptions.

SiteOper storage queries are synthetic owned dependencies that expose the original plugin's lazy query sequence. Actual SQLAlchemy `get_latest`/`get_by_date` execution is not claimed; their SQL grouping/join semantics remain pinned static source findings. SitesHelper lookup/enumeration is also synthetic. The actual installed compiled `.so` is available for the root's separate read-only investigation, but no REA provider/runtime path has established full `get_indexer/get_indexers` semantics. No lookup normalization, alias or ordering behavior is guessed by this harness.

## Frozen inputs and next use

`execution-manifest.json` binds the harness, overlay test, original/Go implementation inputs, new schema files, all fixtures and observed logs. The original TT 32 target files are checked against their latest freeze and remain unchanged. Existing pure Go code is checked against the earlier `reuse-inputs.json` snapshot; the overlay leaves the host tree untouched.

Use this source baseline directly when root unlocks the SiteStatistic slice. The remaining compiled helper boundary and the already reported **current refresh DTO/None versus persisted account-row** SDK gap must be closed separately. These observations are not a replacement for the new standalone worker, actual host/site-peer/UI execution, or installed Python3.12/Pydantic acceptance.
