package statistic

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math/big"
	"os"
	"reflect"
	"sort"
	"testing"
)

const preparationOutput = "/Users/accidia/projects/light-media-plugins/work/migration-20261105/sitestatistic-preparation/execution/"

type sourceNumber struct{ Rational string }

func semanticJSON(raw []byte) (any, error) {
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var value any
	if err := decoder.Decode(&value); err != nil {
		return nil, err
	}
	var normalize func(any) any
	normalize = func(v any) any {
		switch x := v.(type) {
		case json.Number:
			r, ok := new(big.Rat).SetString(string(x))
			if !ok {
				return x
			}
			return sourceNumber{r.RatString()}
		case []any:
			for i := range x {
				x[i] = normalize(x[i])
			}
			return x
		case map[string]any:
			for k := range x {
				x[k] = normalize(x[k])
			}
			return x
		}
		return v
	}
	return normalize(value), nil
}

func firstSourceDifference(actual, expected any, path string) string {
	if reflect.DeepEqual(actual, expected) {
		return ""
	}
	if a, ok := actual.(map[string]any); ok {
		if b, ok := expected.(map[string]any); ok {
			keys := make([]string, 0, len(b))
			for k := range b {
				keys = append(keys, k)
			}
			sort.Strings(keys)
			for _, k := range keys {
				if d := firstSourceDifference(a[k], b[k], path+"."+k); d != "" {
					return d
				}
			}
			if len(a) != len(b) {
				return path + ": object key count changed"
			}
		}
	}
	if a, ok := actual.([]any); ok {
		if b, ok := expected.([]any); ok {
			if len(a) != len(b) {
				return fmt.Sprintf("%s: lengths got %d want %d", path, len(a), len(b))
			}
			for i := range a {
				if d := firstSourceDifference(a[i], b[i], fmt.Sprintf("%s[%d]", path, i)); d != "" {
					return d
				}
			}
		}
	}
	return fmt.Sprintf("%s: got %v want %v", path, actual, expected)
}

func TestPreparationSourceReplay(t *testing.T) {
	differences := []map[string]string{}
	defer func() {
		raw, _ := json.MarshalIndent(differences, "", "  ")
		_ = os.WriteFile(preparationOutput+"pure-go-differences.json", append(raw, '\n'), 0600)
	}()
	for _, filename := range []string{"historical-replay.json", "additional-source-oracle.json"} {
		raw, err := os.ReadFile(preparationOutput + filename)
		if err != nil {
			t.Fatal(err)
		}
		var source struct {
			Cases []struct {
				Name       string                         `json:"name"`
				Latest     []Data                         `json:"latest"`
				History    []Data                         `json:"history"`
				Active     []string                       `json:"active_domains"`
				Notify     string                         `json:"notify_type"`
				Day        string                         `json:"day"`
				Current    json.RawMessage                `json:"current"`
				Previous   json.RawMessage                `json:"previous"`
				Page       json.RawMessage                `json:"page"`
				Dashboards map[string]json.RawMessage     `json:"dashboards"`
				Notices    []struct{ Title, Text string } `json:"notifications"`
				Last       *struct{ Fingerprint string }  `json:"last_notify"`
			} `json:"cases"`
			Formats []struct {
				Value *float64 `json:"value"`
				Text  string   `json:"text"`
			} `json:"formats"`
		}
		if err := json.Unmarshal(raw, &source); err != nil {
			t.Fatal(err)
		}
		for _, c := range source.Cases {
			t.Run(filename+"/"+c.Name, func(t *testing.T) {
				record := func(field, diff string) {
					differences = append(differences, map[string]string{"fixture": filename, "case": c.Name, "field": field, "difference": diff})
					t.Error(field + ": " + diff)
				}
				selected, err := Select(Snapshot{Latest: c.Latest, History: c.History, ActiveDomains: c.Active})
				if err != nil {
					record("selection", err.Error())
					return
				}
				compare := func(field string, actual any, expected json.RawMessage) {
					raw, err := json.Marshal(actual)
					if err != nil {
						record(field, err.Error())
						return
					}
					a, e := semanticJSON(raw)
					if e != nil {
						t.Fatal(e)
					}
					b, e := semanticJSON(expected)
					if e != nil {
						t.Fatal(e)
					}
					if diff := firstSourceDifference(a, b, field); diff != "" {
						record(field, diff)
					}
				}
				if selected.Day != c.Day {
					record("day", fmt.Sprintf("got %q want %q", selected.Day, c.Day))
				}
				compare("current", selected.Current, c.Current)
				compare("previous", selected.Previous, c.Previous)
				compare("page", Page(selected), c.Page)
				for mode, want := range c.Dashboards {
					compare("dashboard."+mode, map[string]any{"cols": map[string]int{"cols": 12}, "attrs": map[string]any{}, "elements": []Node{n("VRow", nil, Elements(selected, mode)...)}}, want)
				}
				got := BuildNotification(selected, c.Notify, "2026-10-16")
				if len(c.Notices) == 0 {
					if got != nil {
						record("notification", "unexpected notification")
					}
				} else if got == nil || got.Title != c.Notices[0].Title || got.Text != c.Notices[0].Text || c.Last == nil || got.Fingerprint != c.Last.Fingerprint {
					record("notification", fmt.Sprintf("got %#v want %#v", got, c.Notices))
				}
			})
		}
		for i, c := range source.Formats {
			t.Run(fmt.Sprintf("%s/format-%d", filename, i), func(t *testing.T) {
				if got := FormatSize(c.Value); got != c.Text {
					differences = append(differences, map[string]string{"fixture": filename, "case": fmt.Sprintf("format-%d", i), "field": "format", "difference": fmt.Sprintf("got %q want %q", got, c.Text)})
					t.Error(got, c.Text)
				}
			})
		}
	}
}
