"""Execute only captured source AST with owned in-memory dependencies.

Never import the application or a production plugin. This is a test harness,
not a Python runtime for the new Go product.
"""
import ast
import bisect
import copy
import hashlib
import json
import math
import re
import sys
import threading
import typing
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from urllib import parse
from zoneinfo import ZoneInfo
ROOT = Path('/oracle')
OUT = Path('/tmp/ss-oracle-output')
SOURCE = ROOT / 'source/plugin.py'
REF = ROOT / 'source'
OLD = ROOT / 'inputs.json'
SCHEMAS = ROOT / 'work/migration-20261105/site-helper-reference'
STATE = None

def clean(value):
    if isinstance(value, SchemaModelBase):
        return clean(value.model_dump())
    if isinstance(value, Row):
        return clean(value.to_dict())
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [clean(v) for v in value]
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, set):
        return sorted(value)
    if callable(value):
        return getattr(value, '__name__', 'callback')
    return copy.deepcopy(value)

def trace(op, **data):
    STATE.trace.append({'op': op, **clean(data)})

class Row:

    def __init__(self, fields):
        self.fields = copy.deepcopy(fields)

    def __getattr__(self, key):
        if key in self.fields:
            return self.fields[key]
        if key in {'updated_time', 'username', 'user_level', 'upload', 'download', 'bonus', 'ratio', 'seeding', 'seeding_size', 'err_msg'}:
            return None
        raise AttributeError(key)

    def to_dict(self):
        return copy.deepcopy(self.fields)

    def model_dump(self):
        return self.to_dict()

    def dict(self):
        trace('dto.dict')
        return self.to_dict()

class FactoryDefault:

    def __init__(self, factory):
        self.factory = factory

class SchemaModelBase:
    """Valid-input defaults/after-validator shell, not a Pydantic validator.

    Source annotations/defaults and Response's after-validator run unchanged.
    Type coercion/validation and production locale translation are not modeled.
    """

    def __init__(self, **fields):
        for key in type(self).__annotations__:
            default = getattr(type(self), key, None)
            value = fields.get(key, default.factory() if isinstance(default, FactoryDefault) else copy.deepcopy(default))
            setattr(self, key, value)
        for method in type(self).__dict__.values():
            if callable(method) and getattr(method, 'source_after', False):
                method(self)

    def model_dump(self):
        return {k: copy.deepcopy(getattr(self, k)) for k in type(self).__annotations__}

    def dict(self):
        trace('dto.dict')
        return self.model_dump()

def after_validator(**_):

    def decorate(method):
        method.source_after = True
        return method
    return decorate

class Clock(datetime):

    @classmethod
    def now(cls, tz=None):
        value = STATE.now
        return value.astimezone(tz) if tz else value.replace(tzinfo=None)

class Logger:

    def __getattr__(self, level):
        return lambda text: trace('log', level=level, text=str(text))

class Base:

    def get_data(self, key):
        trace('get_data', key=key)
        return copy.deepcopy(STATE.data.get(key))

    def save_data(self, key, value):
        trace('save_data', key=key, value=value)
        if STATE.fail_save:
            raise RuntimeError('owned save failure')
        STATE.data[key] = copy.deepcopy(value)

    def post_message(self, **fields):
        trace('post_message', fields=fields)
        if STATE.fail_post:
            raise RuntimeError('owned post failure')
        STATE.notices.append(copy.deepcopy(fields))
        return STATE.post_result

    def update_config(self, config):
        trace('update_config', value=config)

class Event:

    def __init__(self, event_data):
        self.event_data = event_data

class Events:

    def register(self, _):
        return lambda f: f

    def send_event(self, kind, data):
        trace('event', kind=kind, data=data)

class SiteOper:

    def get_userdata_latest(self):
        trace('latest')
        if STATE.concurrent_barrier is not None:
            STATE.concurrent_barrier.wait(timeout=5)
        return [Row(r) for r in STATE.latest]

    def list_active(self):
        trace('active')
        return [SimpleNamespace(domain=d) for d in STATE.active]

    def get_userdata_by_date(self, date):
        trace('date', date=date)
        if date == STATE.fail_date:
            raise RuntimeError('owned historical query failure')
        return [Row(r) for r in STATE.history if r['updated_day'] == date]

    def update_userdata(self, **kwargs):
        trace('update_userdata', **kwargs)

class SitesHelper:

    def get_indexer(self, domain):
        trace('get_indexer', domain=domain)
        return copy.deepcopy(STATE.indexers.get(domain))

    def get_indexers(self):
        trace('get_indexers')
        return copy.deepcopy(STATE.all_indexers)

class Response:

    def __init__(self, **fields):
        self.fields = fields

class Scheduler:

    def __init__(self, timezone):
        trace('scheduler', timezone=timezone)
        ZoneInfo(timezone)

    def add_job(self, callback, kind, **kwargs):
        trace('add_job', callback=callback, kind=kind, **kwargs)

    def print_jobs(self):
        trace('print_jobs')

    def start(self):
        trace('scheduler.start')

class ChainBase:

    def run_module(self, method, site):
        trace('run_module', method=method, site=site)
        if STATE.stop_after == len([t for t in STATE.trace if t['op'] == 'run_module']):
            ENV['global_vars'].is_system_stopped = True
        if STATE.refresh_raises:
            raise RuntimeError('owned module failure')
        value = STATE.refreshes.get(site.get('id'))
        return SourceSchemaUserData(**value) if value is not None else None

    def post_message(self, notification):
        trace('chain.post_message', fields=notification.fields)

    @property
    def messageoper(self):
        return SimpleNamespace(exists_by_source=lambda _: False)

class Notification:

    def __init__(self, **fields):
        self.fields = fields

def source_class(path, class_name, methods=None, renamed=None, base=None):
    tree = ast.parse(path.read_text())
    node = copy.deepcopy(next((n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name)))
    if methods is not None:
        node.body = [n for n in node.body if isinstance(n, ast.FunctionDef) and n.name in methods]
    if renamed:
        node.name = renamed
    if base:
        node.bases = [ast.Name(id=base, ctx=ast.Load())]
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[])), str(path), 'exec'), ENV)
    return ENV[node.name]
ENV = {**vars(typing), '__name__': 'owned_source_ast', 'datetime': Clock, 'timedelta': timedelta, 'math': math, 'hashlib': hashlib, 're': re, 'bisect': bisect, 'parse': parse, '_PluginBase': Base, 'SiteUserData': Row, 'Event': Event, 'SiteOper': SiteOper, 'SitesHelper': SitesHelper, 'logger': Logger(), 'lock': threading.Lock(), 'eventmanager': Events(), 'EventType': SimpleNamespace(SiteRefreshed='site.refreshed'), 'NotificationType': SimpleNamespace(SiteMessage='站点消息'), 'Notification': Notification, 'settings': SimpleNamespace(TZ='Asia/Shanghai', API_TOKEN='owned-synthetic-api-key'), 'global_vars': SimpleNamespace(is_system_stopped=False), 'ChainBase': ChainBase, 'BackgroundScheduler': Scheduler, 'pytz': SimpleNamespace(timezone=ZoneInfo), 'schemas': SimpleNamespace(Response=Response)}
string_tree = ast.parse((REF / 'app/utils/string.py').read_text())
ENV['_special_domains'] = ast.literal_eval(next((n.value for n in string_tree.body if isinstance(n, ast.Assign) and any((isinstance(t, ast.Name) and t.id == '_special_domains' for t in n.targets)))))
StringUtils = source_class(REF / 'app/utils/string.py', 'StringUtils', {'str_filesize', 'get_url_domain', 'get_url_netloc'})
ENV.update(BaseModel=SchemaModelBase, Field=lambda *, default_factory: FactoryDefault(default_factory), model_validator=after_validator, LocaleHelper=SimpleNamespace(get_current_locale=lambda: 'owned-identity-locale', translate_text=lambda text, **_: text))
Plugin = source_class(SOURCE, 'SiteStatistic')

def reset(latest=(), history=(), active=()):
    global STATE
    STATE = SimpleNamespace(latest=copy.deepcopy(latest), history=copy.deepcopy(history), active=list(active), trace=[], now=datetime(2026, 10, 16, 12, 34, 56, tzinfo=timezone(timedelta(hours=8))), data={}, notices=[], fail_save=False, fail_post=False, post_result=None, fail_date=None, indexers={}, all_indexers=[], refreshes={}, refresh_raises=False, stop_after=None, concurrent_barrier=None)
    ENV['settings'].TZ = 'Asia/Shanghai'
    ENV['global_vars'].is_system_stopped = False
    return Plugin()

def attempt(callback):
    try:
        value = callback()
        return {'value': clean(value.fields if isinstance(value, Response) else value)}
    except Exception as e:
        return {'raised': type(e).__name__, 'message': str(e)}

def capture_case(c):
    p = reset(c['latest'], c['history'], c['active_domains'])
    p._notify_type = c['notify_type']
    day, current, previous = p._SiteStatistic__get_data()
    result = {k: copy.deepcopy(c[k]) for k in ('name', 'latest', 'history', 'active_domains', 'notify_type')}
    result.update(day=day, current=clean(current), previous=clean(previous), page=p.get_page(), dashboards={})
    for mode in ('today', 'total', 'all'):
        p._dashboard_type = mode
        cols, attrs, elements = p.get_dashboard('ignored', user_agent='owned')
        result['dashboards'][mode] = {'cols': cols, 'attrs': attrs, 'elements': elements}
    p.send_msg(Event({'site_id': '*'}))
    result.update(notifications=copy.deepcopy(STATE.notices), last_notify=copy.deepcopy(STATE.data.get('last_notify')))
    result['trace'] = copy.deepcopy(STATE.trace)
    return result

def row(name='Owned', domain='owned.invalid', day='2026-10-16', **fields):
    return {'name': name, 'domain': domain, 'updated_day': day, 'username': 'owned', 'user_level': 'User', 'upload': 200.0, 'download': 100.0, 'ratio': 2.0, 'bonus': 1.0, 'seeding': 2.0, 'seeding_size': 1024.0, 'err_msg': '', **fields}

def main312():
    inputs = json.loads(OLD.read_text())
    reset()
    result = {"python": sys.version, "kind": "actual image Python3.12 pure installed class AST, synthetic owned dependencies; no application import/network", "historical": [capture_case(c) for c in inputs["historical"]], "additional": [capture_case(c) for c in inputs["additional"]], "formats": [{"value":v,"text":Plugin._SiteStatistic__format_filesize(v)} for v in inputs["formats"]]}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
main312()
