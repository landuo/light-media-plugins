#!/usr/bin/env python3
"""Installed is_inactive/query/service_info/checker AST; cached-client states."""
from __future__ import annotations
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
TT=ROOT/'source-snapshot/torrenttransfer/__init__.py'
QB=ROOT/'host-reference/app/modules/qbittorrent/qbittorrent.py'
TR=ROOT/'host-reference/app/modules/transmission/transmission.py'
trace=[]
class Log:
    def __getattr__(self,level):return lambda text,*a,**k:trace.append({'op':'log','level':level,'text':str(text)})
def klass(path,name,names,scope):
    methods=[copy.deepcopy(n) for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.FunctionDef) and n.name in names]
    node=ast.ClassDef(name=name,bases=[],keywords=[],body=methods,decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
    return scope[name]
env=dict(logger=Log())
Qb=klass(QB,'Qbittorrent',{'is_inactive','get_torrents'},env)
Tr=klass(TR,'Transmission',{'is_inactive','get_torrents'},env)
Plugin=klass(TT,'TorrentTransfer',{'service_info','check_recheck','__get_hash','__can_seeding'},env)
rows=[]
for kind,Class,attribute in [('qbittorrent',Qb,'qbc'),('transmission',Tr,'trc')]:
 for state in ['cached-client-query-fails','cached-client-query-empty','initial-client-none','missing-host-and-client-none']:
    trace.clear();wrapper=Class();wrapper._host='owned.invalid';wrapper._port=1
    def query(**kwargs):
        trace.append({'op':'native.query','kwargs':kwargs})
        if state=='cached-client-query-fails':raise ConnectionError('owned stale client network failure')
        return []
    client=NS(torrents_info=query,get_torrents=query)
    if state in ['initial-client-none','missing-host-and-client-none']:client=None
    if state=='missing-host-and-client-none':wrapper._host=None;wrapper._port=None
    setattr(wrapper,attribute,client)
    service=NS(name='Dest',type=kind,instance=wrapper)
    env['DownloaderHelper']=lambda:NS(get_service=lambda name:service)
    plugin=Plugin();plugin._todownloader='Dest';plugin._recheck_torrents={'Dest':['a'*40]};plugin._is_recheck_running=False
    inactive=wrapper.is_inactive()
    plugin.check_recheck()
    rows.append({'kind':kind,'state':state,'source_is_inactive':inactive,'pending_after':plugin._recheck_torrents,'running_after':plugin._is_recheck_running,'trace':list(trace)})
result={'kind':'actual installed cached native is_inactive + get_torrents wrapper + TT service_info/check_recheck AST, synthetic no-network client states','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [TT,QB,TR]},'limitation':'Synthetic successful old constructor/object retention; no original constructor/login/reconnect scheduler is run. No live connections or config.','cases':rows}
HERE.joinpath('cached-connection-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':[{'kind':r['kind'],'state':r['state'],'inactive':r['source_is_inactive'],'pending':r['pending_after']} for r in rows]},indent=2))
