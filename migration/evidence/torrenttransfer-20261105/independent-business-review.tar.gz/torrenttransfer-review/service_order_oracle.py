#!/usr/bin/env python3
"""Actual installed helper method AST with synthetic config/module objects."""
from __future__ import annotations
import ast
import copy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

here=Path(__file__).resolve().parent
source=here.parent/'host-reference/app/helper/service.py'
tree=ast.parse(source.read_text())
klass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ServiceBaseHelper')
methods=[]
for n in klass.body:
    if isinstance(n,ast.FunctionDef) and n.name in {'get_configs','iterate_module_instances','get_service'}:
        n=copy.deepcopy(n);n.decorator_list=[];methods.append(n)
rows=[NS(name='B',type='qbittorrent',enabled=True,label='B-first'),
      NS(name='A',type='qbittorrent',enabled=True,label='A-first'),
      NS(name='B',type='transmission',enabled=True,label='B-last'),
      NS(name='C',type='transmission',enabled=False,label='C-disabled')]
scope={'ServiceConfigHelper':NS(get_configs=lambda *_:rows),'ServiceInfo':NS}
exec(compile(ast.fix_missing_locations(ast.Module(body=[ast.ClassDef(name='Captured',bases=[],keywords=[],body=methods,decorator_list=[])],type_ignores=[])),str(source),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
obj=scope['Captured']();obj.config_key='fixture';obj.conf_type=NS;obj.module_type='fixture'
def module(label,items):return NS(label=label,get_instances=lambda:items)
obj.modulemanager=NS(get_running_type_modules=lambda _:[module('qb-module',{'B':NS(label='qb-B'),'A':NS(label='qb-A')}),module('tr-module',{'B':NS(label='tr-B')})])
configs=obj.get_configs();service=obj.get_service('B')
result={'kind':'actual installed ServiceBaseHelper method AST with synthetic configs/module instances; no real module manager or live settings',
        'source':str(source.relative_to(here.parent)),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'input_config_labels':[r.label for r in rows],
        'get_configs_order':list(configs),'get_configs_values':{k:v.label for k,v in configs.items()},
        'get_service_B':{'instance':service.instance.label,'module':service.module.label,'type':service.type,'config':service.config.label},
        'verified_rules':['First insertion position for each eligible name','Last eligible configuration value per name','First runtime instance in module/instance iteration carrying last configuration value']}
here.joinpath('service-order-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
