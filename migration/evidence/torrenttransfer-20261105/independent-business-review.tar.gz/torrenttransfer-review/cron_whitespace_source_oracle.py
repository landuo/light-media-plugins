#!/usr/bin/env python3
"""Actual APS class lexer, reusing only source-class bootstrap (no test cases)."""
from __future__ import annotations
import ast,copy,datetime,hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
bootstrap=HERE/'cron_local_source_oracle.py';tree=ast.parse(bootstrap.read_text());prefix=[];setup=[];final=[]
for node in tree.body:
 if isinstance(node,ast.Try):
  for stmt in node.body:
   if isinstance(stmt,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='rows' for t in stmt.targets):break
   setup.append(stmt)
  final=node.finalbody;break
 prefix.append(node)
scope={'__file__':str(bootstrap)}
exec(compile(ast.Module(body=copy.deepcopy(prefix+setup),type_ignores=[]),str(bootstrap),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
try:
 rows=[]
 for separator in [' ','\x1c','\x1d','\x1e','\x1f','\u00a0']:
  expression='0'+separator+'0 * * *'
  trigger=scope['cron'].CronTrigger.from_crontab(expression,timezone=datetime.timezone.utc)
  rows.append({'separator_codepoint':f'U+{ord(separator):04X}','expression':expression,'split_fields':expression.split(),'accepted':True,'fields':{f.name:str(f) for f in trigger.fields}})
 paths=[p for p in scope['INPUTS'] if 'apscheduler' in str(p)]
 result={'kind':'actual installed APScheduler3.11.3 CronTrigger.from_crontab/class/fields/expressions AST with explicit UTC and synthetic environment dependencies','source_sha256':{str(p.relative_to(scope['REF'])):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'cases':rows,'limitations':['Python3.14 interpreter executes captured installed3.12 source, standard str.split whitespace stable on these six codepoints','No source application/package import, live config or scheduling execution','Class bootstrap is shared with the independent DST oracle; its test case loop is not executed']}
 HERE.joinpath('cron-whitespace-source-oracle.json').write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n');print(json.dumps(result,ensure_ascii=True,indent=2))
finally:exec(compile(ast.Module(body=copy.deepcopy(final),type_ignores=[]),str(bootstrap),'exec'),scope)
