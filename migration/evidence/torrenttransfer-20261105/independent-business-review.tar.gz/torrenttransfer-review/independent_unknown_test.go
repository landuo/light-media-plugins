package torrenttransfer

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/landuo/light-media-plugins/internal/sdk"
)

// Source wrappers convert ordinary native exceptions to QB tupleFalse, TR None
// and control False. The host's pure unknown receipt records uncertainty but
// does not turn those ordinary source returns into uncaught business errors.
func TestIndependentPureUnknownPreservesSourceBranches(t *testing.T) {
	for _,kind:=range []string{"qbittorrent","transmission"}{t.Run(kind+"-add",func(t *testing.T){
		s:=newSDKFixture(t,"qbittorrent",kind);cfg,e:=RestoreConfig(s.config());if e!=nil{t.Fatal(e)}
		adds,finds:=0,0
		host:=func(ctx context.Context,m string,raw json.RawMessage)(json.RawMessage,error){
			if m==plugins.DownloaderSourceAddCapability{adds++;return json.Marshal(plugins.DownloaderSourceMutationResultV1{DownloaderMutationV1:plugins.DownloaderMutationV1{SchemaVersion:1,DownloaderID:"target",Outcome:"unknown"},NativeError:true})}
			if m==plugins.DownloaderSourceFindByTagCapability{finds++}
			return s.host(ctx,m,raw)
		}
		core,e:=NewCore(cfg,sdkHost{caller:host});if e!=nil{t.Fatal(e)}
		counts,e:=core.Transfer(context.Background());if e!=nil{t.Fatalf("ordinary source native return became uncaught error: %v",e)}
		if adds!=1{t.Fatal("selected unknown add retried",adds)}
		if kind=="qbittorrent"{if finds!=1||counts.Success!=1||len(s.history)!=1{t.Fatal("QB false tuple did not follow source lookup/history",finds,counts,s.history)}}else if finds!=0||counts.Fail!=1||len(s.history)!=0{t.Fatal("TR None did not count source failure",finds,counts,s.history)}
	})}
	t.Run("ordinary-control-False",func(t *testing.T){
		s:=newSDKFixture(t,"qbittorrent","qbittorrent");input:=s.config();input["autostart"]=true
		cfg,e:=RestoreConfig(input);if e!=nil{t.Fatal(e)}
		actions:=[]string{}
		host:=func(ctx context.Context,m string,raw json.RawMessage)(json.RawMessage,error){
			if m==plugins.DownloaderSourceControlCapability{var in plugins.DownloaderControlRequestV1;if e:=json.Unmarshal(raw,&in);e!=nil{return nil,e};actions=append(actions,in.Action);return json.Marshal(plugins.DownloaderSourceMutationResultV1{DownloaderMutationV1:plugins.DownloaderMutationV1{SchemaVersion:1,DownloaderID:in.DownloaderID,Outcome:"unknown"},NativeError:true})}
			return s.host(ctx,m,raw)
		}
		core,e:=NewCore(cfg,sdkHost{caller:host});if e!=nil{t.Fatal(e)}
		counts,e:=core.Transfer(context.Background());if e!=nil||counts.Success!=1||len(s.history)!=1{t.Fatal("source ignored controls became whole-pass failure",counts,e,s.history)}
		if len(actions)!=3||actions[0]!="recheck"||actions[1]!="remove_task"||actions[2]!="start"||len(core.state.Recheck["Target"])!=0||core.state.recheckRunning{t.Fatal("source false-control ordering/queue changed",actions,core.state)}
	})
}
