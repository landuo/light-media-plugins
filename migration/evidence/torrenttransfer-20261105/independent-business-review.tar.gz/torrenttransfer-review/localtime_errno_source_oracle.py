#!/usr/bin/env python3
"""Installed genericpath.exists + tzlocal anonymous-file AST, fault injection."""
from __future__ import annotations
import ast
import copy
import datetime
import errno
import hashlib
import io
import json
import os
import warnings
import zoneinfo
from pathlib import Path
from types import SimpleNamespace as NS

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
generic=ROOT/'python-runtime-reference/stdlib/genericpath.py'
unix=ROOT/'python-timezone-reference/tzlocal/unix.py'
raw=(HERE/'fixtures/new-york.tzif').read_bytes()
def function(path,name,scope):
    node=copy.deepcopy(next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name))
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
rows=[]
for label,firstStat,firstRead,secondStat,secondRead in [
    ('first-valid',None,None,None,None),
    ('first-stat-EACCES-second-valid',errno.EACCES,None,None,None),
    ('first-stat-EIO-second-valid',errno.EIO,None,None,None),
    ('first-stat-ENOENT-second-valid',errno.ENOENT,None,None,None),
    ('first-read-EACCES-no-fallback',None,errno.EACCES,None,None),
    ('first-read-EIO-no-fallback',None,errno.EIO,None,None),
    ('first-malformed-no-fallback',None,'BAD',None,None),
    ('first-stat-EACCES-second-stat-EACCES-UTC',errno.EACCES,None,errno.EACCES,None),
    ('both-absent-UTC',errno.ENOENT,None,errno.ENOENT,None),
]:
    trace=[]
    def stat(path):
        trace.append({'op':'stat','path':path})
        code=firstStat if path=='/owned/etc/localtime' else secondStat
        if code is not None:raise OSError(code,os.strerror(code),path)
        return NS()
    existsScope={'os':NS(stat=stat)};function(generic,'exists',existsScope)
    def openFile(path,mode):
        trace.append({'op':'open','path':path,'mode':mode})
        code=firstRead if path=='/owned/etc/localtime' else secondRead
        if isinstance(code,int):raise OSError(code,os.strerror(code),path)
        return io.BytesIO(b'not TZif' if code=='BAD' else raw)
    scope=dict(os=NS(path=NS(join=os.path.join,exists=existsScope['exists'])),zoneinfo=zoneinfo,timezone=datetime.timezone,utils=NS(_tz_from_env=lambda:None),_get_localzone_name=lambda _:None,log=NS(debug=lambda *_:None),open=openFile,warnings=warnings)
    function(unix,'_get_localzone',scope)
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter('always')
        try:
            zone=scope['_get_localzone']('/owned')
            result={'zone':getattr(zone,'key',str(zone)),'offset_2026_01_01':int(datetime.datetime(2026,1,1,tzinfo=zone).utcoffset().total_seconds())}
        except Exception as e:result={'raises':type(e).__name__,'errno':getattr(e,'errno',None)}
    rows.append({'case':label,'result':result,'warnings':[str(w.message) for w in seen],'trace':trace})
result={'kind':'installed Python3.12 genericpath.exists and tzlocal5.4.4 anonymous _get_localzone function AST with separate stat/open fault injection','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [generic,unix]},'fixture_sha256':hashlib.sha256(raw).hexdigest(),'limitations':['Synthetic stat/open boundary faults; canonical system permissions/files were not modified','Local Python3.14 interpreter and standard ZoneInfo parses owned local-system New_York bytes, not live tzdata','Name discovery and nonempty ENV branch deliberately stubbed out to isolate anonymous canonical-file branch'],'cases':rows}
HERE.joinpath('localtime-errno-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
