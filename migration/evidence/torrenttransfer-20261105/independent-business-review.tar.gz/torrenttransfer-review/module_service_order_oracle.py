#!/usr/bin/env python3
"""Actual installed loader/init/helper AST connected to owned config/module doubles.

No application imports or native downloader constructors run. Package discovery
visits only two newly-created empty package directories; imports/reloads return
already extracted actual module classes. Ordering rules remain original code.
"""
from __future__ import annotations
import abc
import ast
import copy
import hashlib
import importlib
import json
import os
import pkgutil
import sys
import tempfile
import threading
import traceback
import typing
from collections import namedtuple
from functools import singledispatch
from pathlib import Path
from types import SimpleNamespace as NS

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
HOST=ROOT/'host-reference/app'
paths={'base':HOST/'modules/__init__.py','qb':HOST/'modules/qbittorrent/__init__.py','tr':HOST/'modules/transmission/__init__.py','manager':HOST/'core/module.py','loader':HOST/'helper/module.py','service':HOST/'helper/service.py','downloader':HOST/'helper/downloader.py'}
pkgsource=ROOT/'python-runtime-reference/stdlib/pkgutil.py'
pkgscope=dict(os=os,sys=sys,ModuleInfo=namedtuple('ModuleInfo','module_finder name ispkg'),simplegeneric=singledispatch)
pkgnodes=[copy.deepcopy(n) for n in ast.parse(pkgsource.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in {'iter_modules','iter_importer_modules','_iter_file_finder_modules','get_importer'}]
exec(compile(ast.Module(body=pkgnodes,type_ignores=[]),str(pkgsource),'exec',flags=__import__('__future__').annotations.compiler_flag),pkgscope)
pkgscope['iter_importer_modules'].register(importlib.machinery.FileFinder,pkgscope['_iter_file_finder_modules'])
captured_pkgutil=NS(iter_modules=pkgscope['iter_modules'])
class Quiet:
    def __getattr__(self,_):return lambda *a,**k:None
class DownloaderConf(NS):pass
class Qbittorrent:
    def __init__(self,name,**config):self.name=name;self.config=config
class Transmission:
    def __init__(self,name,**config):self.name=name;self.config=config
class ConfigReloadMixin:pass
TService=typing.TypeVar('TService');TConf=typing.TypeVar('TConf')
class ValidationError(Exception):pass
current_rows=[]
env=dict(globals(),pkgutil=captured_pkgutil,Generic=typing.Generic,ABCMeta=abc.ABCMeta,abstractmethod=abc.abstractmethod,Singleton=type,logger=Quiet(),SystemConfigKey=NS(Downloaders=NS(value='Downloaders')),ModuleType=NS(Downloader='Downloader'),DownloaderType=NS(Qbittorrent='qbittorrent',Transmission='transmission'),ServiceInfo=NS,SystemConfigOper=lambda:NS(get=lambda _:current_rows),settings=NS())
def extract_class(path,name,methods,scope):
    source=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.ClassDef) and n.name==name)
    node=copy.deepcopy(source)
    node.body=[n for n in node.body if isinstance(n,ast.FunctionDef) and n.name in methods]
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
    return scope[name]
def extract_function(path,name,scope):
    node=copy.deepcopy(next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name))
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)

extract_class(paths['service'],'ServiceConfigHelper',{'get_configs','get_downloader_configs'},env)
extract_class(paths['base'],'_ModuleBase',{'__init__'},env)
extract_class(paths['base'],'ServiceBase',{'__init__','init_service','get_instances'},env)
extract_class(paths['base'],'_DownloaderBase',{'__init__','init_service','get_configs','reset_default_config_name'},env)
extract_class(paths['qb'],'QbittorrentModule',{'init_module','init_setting','get_name','get_type','get_subtype','get_priority'},env)
extract_class(paths['tr'],'TransmissionModule',{'init_module','init_setting','get_name','get_type','get_subtype','get_priority'},env)
extract_function(paths['loader'],'_default_filter',env)
with tempfile.TemporaryDirectory(prefix='source-module-order-',dir=HERE) as tmp:
    owned=Path(tmp)
    # Deliberately create reverse directory order; pkgutil/FileFinder determines
    # enumeration, just as installed ModuleHelper.load requests.
    for name in ['transmission','qbittorrent']:
        (owned/name).mkdir();(owned/name/'__init__.py').write_text('')
    modules={'app.modules':NS(__path__=[str(owned)]),'app.modules.qbittorrent':NS(QbittorrentModule=env['QbittorrentModule']),'app.modules.transmission':NS(TransmissionModule=env['TransmissionModule'])}
    env['importlib']=NS(import_module=lambda name:modules[name],reload=lambda module:module)
    extract_class(paths['loader'],'ModuleHelper',{'load'},env)
    extract_class(paths['manager'],'ModuleManager',{'__init__','load_modules','check_setting','get_running_type_modules'},env)
    actual_manager_class=env['ModuleManager']
    extract_class(paths['service'],'ServiceBaseHelper',{'__init__','get_configs','iterate_module_instances','get_service'},env)
    extract_class(paths['downloader'],'DownloaderHelper',{'__init__','is_downloader'},env)
    rows=[]
    for case,inputs in [
        ('distinct-names-config-order',[('B','transmission',True,'tr-B'),('A','qbittorrent',True,'qb-A'),('Z','transmission',True,'tr-Z')]),
        ('same-kind-last-value-first-slot',[('B','qbittorrent',True,'qb-B-first'),('A','qbittorrent',True,'qb-A'),('B','qbittorrent',True,'qb-B-last')]),
        ('cross-kind-TR-metadata-QB-runtime',[('Mixed','qbittorrent',True,'qb-first'),('Other','transmission',True,'tr-other'),('Mixed','transmission',True,'tr-last')]),
        ('cross-kind-QB-metadata-QB-runtime',[('Mixed','transmission',True,'tr-first'),('Mixed','qbittorrent',True,'qb-last')]),
        ('disabled-does-not-overwrite',[('B','qbittorrent',True,'qb-enabled'),('B','transmission',False,'tr-disabled'),('A','transmission',True,'tr-A')]),
        ('all-disabled',[('B','qbittorrent',False,'qb-disabled'),('A','transmission',False,'tr-disabled')]),
    ]:
        current_rows=[dict(name=name,type=kind,enabled=enabled,label=label,config={'marker':label}) for name,kind,enabled,label in inputs]
        manager=actual_manager_class()
        env['ModuleManager']=lambda:manager # Existing singleton dependency only.
        helper=env['DownloaderHelper']()
        configs=helper.get_configs()
        instances=[{'module':type(module).__name__,'name':name,'runtime_class':type(instance).__name__,'marker':instance.config['marker']} for module in manager.get_running_type_modules('Downloader') for name,instance in module.get_instances().items()]
        lookups={}
        for name in configs:
            service=helper.get_service(name)
            lookups[name]={'metadata_kind':service.type,'metadata_label':service.config.label,'runtime_class':type(service.instance).__name__,'runtime_marker':service.instance.config['marker'],'is_qb':helper.is_downloader('qbittorrent',service=service),'is_tr':helper.is_downloader('transmission',service=service)}
        rows.append({'case':case,'config_inputs':current_rows,'pkgutil_packages':[m.name for m in captured_pkgutil.iter_modules([str(owned)])],'loaded_modules':list(manager._running_modules),'form_order':list(configs),'selected_config_labels':{name:conf.label for name,conf in configs.items()},'runtime_instances':instances,'get_service':lookups})
result={'kind':'actual installed ModuleHelper.load + Python3.12 pkgutil file discovery + ModuleManager.load_modules + module init/ServiceBase/_DownloaderBase + configuration/DownloaderHelper method AST','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [*paths.values(),pkgsource]},'limitations':['No production package import/native constructor: constructors are synthetic no-IO objects','Config rows are legal synthetic dictionaries with a SimpleNamespace schema double; no Pydantic validation completeness claim','Import/reload of owned empty package names returns extracted source classes; actual loader selection and manager/module/service ordering remain unmodified','Installed Python3.12 pkgutil iter_modules/get_importer/_iter_file_finder_modules AST executes on local3.14 stdlib lower-level FileFinder/inspect against only owned empty .py package directories','Actual Singleton decorator is replaced by injection of already-loaded manager; singleton lifecycle behavior is outside this ordering oracle'],'cases':rows}
HERE.joinpath('module-service-order-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':[{'case':row['case'],'order':row['form_order'],'modules':row['loaded_modules'],'lookup':row['get_service']} for row in rows]},indent=2))
