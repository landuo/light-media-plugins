#!/usr/bin/env python3
"""Single-file Go overlays only; never alter business or authoritative files."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
TARGET=ROOT/"plugins/torrenttransfer"
label=sys.argv[1] if len(sys.argv)>1 else 'final'
review_test=json.loads((HERE/'review-overlay.json').read_text())['Replace']
specs=[
 ("include-all-inverted","core.go","if !contains(labels, label) {","if contains(labels, label) {","^TestInstalledWholeClassOracle$"),
 ("empty-query-treated-as-none","core.go","} else if torrents == nil {","} else if len(torrents) == 0 {","^TestInstalledWholeClassOracle$"),
 ("skip-source-delete","core.go",'if c.config().flag("deletesource") {',"if false {","^TestInstalledWholeClassOracle$"),
 ("owner-returns-before-pass","pass.go","select {\n\tcase <-pass.done:","select {\n\tdefault:\n\tcase <-pass.done:","^TestIndependentTransferOwnerWaitsForLastTorrent$"),
 ("reuse-current-phase-host","pass.go","if e = p.submitTransfer(call, host, pass); e != nil {",'''p.mu.Lock()
	pass.token++
	nextToken := pass.token
	p.mu.Unlock()
	nextRaw, _ := json.Marshal(map[string]any{"pass":pass.id,"token":nextToken})
	if e = p.continueTransfer(call, nextRaw, host); e != nil {''',"^TestSDKHundredTorrentAndFilteredCursorBudgets$/^120-transfers$"),
 ("collapse-metadata-runtime-kind","host.go","Type: canonicalKind(metadata.Kind), RuntimeKind: kind","Type: kind, RuntimeKind: kind","^TestIndependentActualModuleServiceOrdering$"),
 ("ignore-mixed-kind-attribute-error","core.go",'if s.actualKind() == "qbittorrent" {',"if false {","^TestIndependentMixedKindAddBeforeAttributeFailure$"),
 ("private-empty-defaults-shanghai","timezone.go","if !exists {",'if !exists || name == "" {',"^TestIndependent(InstalledTimezoneBranches|InvalidPrivateTimezonePreservesOnlyOnce)$"),
 ("plain-unknown-aborts-source","host.go",'if out.FailureCode != "" {\n\t\treturn errors.New(out.FailureCode)\n\t}', 'if out.FailureCode != "" {\n\t\treturn errors.New(out.FailureCode)\n\t}\n\tif out.Outcome == "unknown" { return errors.New("counterfactual unknown stop") }',"^TestIndependentPureUnknownPreservesSourceBranches$"),
 ("ignore-reverse-runtime-signature","host.go",'if s.Type == "qbittorrent" && s.actualKind() == "transmission" {',"if false {","^TestIndependentReverseMetadataSignatureBeforeAdd$"),
]
results=[]
for name,file,old,new,test in specs:
    source=(TARGET/file).read_text()
    assert source.count(old)==1,(name,source.count(old))
    mutated=source.replace(old,new,1)
    path=HERE/(label+"-mutant-"+name+".go")
    path.write_text(mutated)
    overlay=HERE/(label+"-mutant-"+name+".json")
    overlay.write_text(json.dumps({"Replace":{**review_test,str(TARGET/file):str(path)}},indent=2)+"\n")
    command=["go","test","-count=1","-json","-overlay="+str(overlay),"./plugins/torrenttransfer","-run",test]
    run=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=55)
    HERE.joinpath(label+"-mutant-"+name+".jsonl").write_text(run.stdout)
    HERE.joinpath(label+"-mutant-"+name+".stderr").write_text(run.stderr)
    observations=[]
    for line in run.stdout.splitlines():
        try:observations.append(json.loads(line))
        except json.JSONDecodeError:pass
    failures=[row.get("Test") for row in observations if row.get("Action")=="fail" and row.get("Test")]
    build_failed=any(row.get("Action")=="build-fail" for row in observations)
    result={"mutation":name,"file":file,"command":command,"exit_code":run.returncode,
            "original_sha256":hashlib.sha256(source.encode()).hexdigest(),"mutant_sha256":hashlib.sha256(mutated.encode()).hexdigest(),
            "failed_tests":failures,"build_failed":build_failed,"killed":run.returncode!=0 and bool(failures) and not build_failed}
    results.append(result)
    print(json.dumps(result),flush=True)
HERE.joinpath(label+"-mutation-results.json").write_text(json.dumps({"kind":"single-file counterfactual Go overlays; no product mutations; earlier evidence preserved separately","results":results},indent=2)+"\n")
assert all(row["killed"] for row in results)
