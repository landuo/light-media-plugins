#!/usr/bin/env python3
"""Installed tzlocal/util method AST; owned roots, synthetic ENV, no host import."""
from __future__ import annotations
import ast
import copy
import datetime
import hashlib
import json
import os
import re
import shutil
import tempfile
import types
import warnings
import zoneinfo
from pathlib import Path
from types import SimpleNamespace as NS
from typing import Union, get_args, get_origin

HERE=Path(__file__).resolve().parent
TASK=HERE.parent
REF=TASK/"python-timezone-reference"
paths=[REF/"tzlocal/unix.py",REF/"tzlocal/utils.py",REF/"apscheduler/util.py",TASK/"host-reference/app/core/config.py"]
class Log:
    def __init__(self):self.warnings=[]
    def debug(self,*a):pass
    def warning(self,text,*a):self.warnings.append(text)
    def error(self,*a):pass

def functions(path,names,scope):
    nodes=[]
    for n in ast.walk(ast.parse(path.read_text())):
        if isinstance(n,ast.FunctionDef) and n.name in names:
            n=copy.deepcopy(n);n.decorator_list=[];nodes.append(n)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)

old_tz=os.environ.get('TZ');had_tz='TZ' in os.environ
results=[]
try:
 for case,env,configs,local in [
    ('unset','UNSET',{'etc/timezone':'Etc/UTC'},None),
    ('empty','',{'etc/timezone':'Etc/UTC'},None),
    ('explicit-UTC','UTC',{'etc/timezone':'Asia/Shanghai'},None),
    ('explicit-Shanghai','Asia/Shanghai',{},None),
    ('colon-UTC',':UTC',{},None),
    ('whitespace-env',' Asia/Shanghai ',{'etc/timezone':'Etc/UTC'},None),
    ('invalid-env','No/Such_Zone',{'etc/timezone':'Etc/UTC'},None),
    ('discard-stale-etc-timezone','UNSET',{'etc/timezone':'Asia/Shanghai'},'Etc/UTC'),
    ('nondeprecated-config-conflict','UNSET',{'var/db/zoneinfo':'Asia/Shanghai','etc/sysconfig/clock':'ZONE="Europe/London"\n'},None),
    ('equivalent-zone-aliases','UNSET',{'var/db/zoneinfo':'UTC','etc/sysconfig/clock':'ZONE="Etc/UTC"\n'},None),
    ('invalid-config-zone','UNSET',{'etc/timezone':'No/Such_Zone'},None),
    ('unnamed-localtime-binary','UNSET',{},'BINARY'),
    ('no-zone-or-localtime-files','UNSET',{},None),
    ('explicit-unnamed-binary','FILE',{},None),
    ('unicode-whitespace-clock','UNSET',{'etc/sysconfig/clock':'\u00a0ZONE="Asia/Shanghai"\n'},None),
    ('invalid-utf8-clock','UNSET',{'etc/sysconfig/clock':'HEX:ff0a5a4f4e453d22417369612f5368616e67686169220a'},None),
    ('malformed-clock-line','UNSET',{'etc/sysconfig/clock':'ZONE="\nTIMEZONE="Asia/Shanghai"\n'},None),
    ('bad-localtime-binary','UNSET',{},'BAD'),
    ('empty-env-localtime-binary','',{},'BINARY'),
 ]:
    with tempfile.TemporaryDirectory(prefix='tz-source-',dir=HERE) as tmp:
        root=Path(tmp);base=root/'usr/share/zoneinfo';base.mkdir(parents=True)
        for name in ('Etc/UTC','Asia/Shanghai','Europe/London'):
            target=base/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path('/usr/share/zoneinfo')/name,target)
        (base/'UTC').symlink_to('Etc/UTC')
        for name,text in configs.items():
            target=root/name;target.parent.mkdir(parents=True,exist_ok=True)
            if text.startswith('HEX:'):target.write_bytes(bytes.fromhex(text[4:]))
            else:target.write_text(text)
        if local:
            target=root/'etc/localtime';target.parent.mkdir(parents=True,exist_ok=True)
            if local=='BINARY':shutil.copyfile(base/'Asia/Shanghai',target)
            elif local=='BAD':target.write_bytes(b'not a TZif file')
            else:target.symlink_to(base/local)
        if env=='UNSET':os.environ.pop('TZ',None)
        elif env=='FILE':
            target=root/'custom-zone';shutil.copyfile(base/'Asia/Shanghai',target);os.environ['TZ']=str(target)
        else:os.environ['TZ']=env
        log=Log()
        scope=dict(globals(),log=log,timezone=datetime.timezone,tzinfo=datetime.tzinfo,ZoneInfo=zoneinfo.ZoneInfo,
                   windows_tz=NS(tz_win={name:name for name in ('UTC','Etc/UTC','Asia/Shanghai','Europe/London')}),logger=log)
        functions(paths[1],{'_tz_name_from_env','_tz_from_env'},scope)
        scope['utils']=NS(_tz_name_from_env=scope['_tz_name_from_env'],_tz_from_env=scope['_tz_from_env'])
        functions(paths[0],{'_get_localzone_name','_get_unique_tzs','_get_localzone'},scope)
        functions(paths[2],{'astimezone'},scope)
        functions(paths[3],{'generic_type_converter'},scope)
        row={'case':case,'TZ':'<owned absolute file>' if env=='FILE' else None if env=='UNSET' else env,'files':configs,'localtime':local}
        with warnings.catch_warnings(record=True) as seen:
            warnings.simplefilter('always')
            try:
                tz=scope['_get_localzone'](str(root))
                row['public']={'zone':getattr(tz,'key',str(tz)),'offset_2026_01_01':int(datetime.datetime(2026,1,1,tzinfo=datetime.timezone.utc).astimezone(tz).utcoffset().total_seconds())}
            except Exception as e:row['public']={'raises':type(e).__name__}
            row['warnings']=[str(w.message).replace(str(root),'<owned root>') for w in seen]
        private='Asia/Shanghai' if env=='UNSET' else os.environ['TZ']
        private,_=scope['generic_type_converter'](private,private,str,'Asia/Shanghai','TZ')
        try:
            tz=scope['astimezone'](private)
            row['private']={'zone':getattr(tz,'key',str(tz))}
        except Exception as e:row['private']={'raises':type(e).__name__}
        row['log_warnings']=[m.replace(str(root),'<owned root>') for m in log.warnings]
        results.append(row)
finally:
 if had_tz:os.environ['TZ']=old_tz
 else:os.environ.pop('TZ',None)
output={'kind':'actual installed tzlocal5.4.4 + APScheduler3.11.3 astimezone + Settings converter functions; owned roots/synthetic ENV',
        'source_sha256':{str(p.relative_to(TASK)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
        'limitations':['Local interpreter Python3.14; actual functions are captured installed source','ZoneInfo database is local system for named zones and owned copied binaries','windows_tz membership stub contains only fixture names; no arbitrary mapping completeness claim','No original plugin/host import, live settings or production file writes'],
        'cases':results}
HERE.joinpath('timezone-source-oracle.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'cases':results},ensure_ascii=False,indent=2))
