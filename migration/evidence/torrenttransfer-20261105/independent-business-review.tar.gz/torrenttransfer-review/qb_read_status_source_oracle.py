#!/usr/bin/env python3
"""Installed QB get_torrents/vendor read error/auth policy to owned HTTP peer."""
from __future__ import annotations
import ast,hashlib,http.server,json,socket,threading,typing
from pathlib import Path
from types import SimpleNamespace as NS
import requests
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
setup_path=HERE/'metadata_runtime_add_oracle.py';nodes=[]
for n in ast.parse(setup_path.read_text()).body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='peer_status' for t in n.targets):break
    nodes.append(n)
scope={'__file__':str(setup_path)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(setup_path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
env=scope['env'];events=scope['events'];method=scope['method'];make_class=scope['make_class'];QB=scope['QB'];VENDOR=scope['VENDOR']
class SourceList(list):
    def __init__(self,values,client=None):super().__init__(values)
env.update(cast=typing.cast,ResponseT=typing.TypeVar('ResponseT'),Dictionary=dict,List=SourceList,TorrentInfoList=SourceList,APINames=NS(Torrents='torrents',Application='app',Authorization='auth'))
methods=[method(VENDOR/'request.py',name) for name in ('_list2string','_post_cast','_auth_request','_request_manager','_request','_format_payload','_cast','_handle_error_responses')]
methods.extend([method(VENDOR/'auth.py','auth_log_in'),method(VENDOR/'torrents.py','torrents_info')])
Vendor=make_class('Vendor',methods,env);Wrapper=make_class('Qbittorrent',[method(QB,'get_torrents')],env)
statuses=[];info_calls=0
class Peer(http.server.BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def do_POST(self):
        global info_calls
        self.rfile.read(int(self.headers['Content-Length']))
        if self.path.endswith('/auth/login'):status=200;body=b'Ok.';events.append({'event':'peer.login'})
        else:
            info_calls+=1;status=statuses[min(info_calls-1,len(statuses)-1)];events.append({'event':'peer.info','attempt':info_calls,'status':status})
            if status=='DROP':
                self.close_connection=True
                try:self.connection.shutdown(socket.SHUT_RDWR)
                except OSError:pass
                self.connection.close();return
            body=json.dumps([{'hash':'a'*40,'tags':'owned'}]).encode() if status<400 else b'owned failure'
        self.send_response(status);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Peer);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();rows=[]
try:
 for name,sequence in [('ordinary200',[200]),('success201',[201]),('unauthorized401-then200',[401,200]),('forbidden403-then200',[403,200]),('HTTP500-then200',[500,200]),('drop-then200',['DROP',200])]:
    events.clear();statuses=sequence;info_calls=0
    session=requests.Session();session.trust_env=False
    v=Vendor();v._session=session;v.username='OWNED_USER';v._password='OWNED_PASSWORD';v._api_key='';v._REQUESTS_ARGS={};v._SIMPLE_RESPONSES=False;v._RAISE_UNSUPPORTEDVERSIONERROR=False
    v._url=NS(build=lambda namespace,method,*_:'http://127.0.0.1:'+str(server.server_port)+'/api/v2/'+namespace+'/'+method)
    v._initialize_context=lambda:events.append({'event':'vendor.context.reset'})
    v._is_endpoint_supported_for_version=lambda **_:True;v._verbose_logging=lambda *_:None
    wrapper=Wrapper();wrapper.qbc=v
    tasks,error=wrapper.get_torrents(ids=['a'*40]);session.close()
    rows.append({'case':name,'reply_sequence':sequence,'task_count':len(tasks),'error_flag':error,'info_POSTs':info_calls,'trace':list(events)})
finally:server.shutdown();server.server_close();thread.join()
paths=[QB,VENDOR/'request.py',VENDOR/'auth.py',VENDOR/'torrents.py']
result={'kind':'actual installed QB wrapper get_torrents and vendor info/request/auth method AST with local Requests and owned HTTP peer','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'limitations':['TorrentInfoList is an inert list model double preserving valid dict entries; auth context/session reset is recorded rather than reconstructing the whole Client','No real daemon/original application imports/config/credentials; only synthetic data and owned loopback HTTP','No selected mutation in this test. Read/auth retry evidence does not authorize replaying selected writes','Local interpreter3.14 versus installed3.12.13; installed Requests serialization critical files previously byte-matched'],'cases':rows}
HERE.joinpath('qb-read-status-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':[{k:v for k,v in r.items() if k!='trace'} for r in rows]},indent=2))
