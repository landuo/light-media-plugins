#!/usr/bin/env python3
"""Source module reconnect and helper lookup concurrency with owned events."""
from __future__ import annotations
import ast,copy,hashlib,json,threading
from pathlib import Path
from types import SimpleNamespace as NS
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
QB=ROOT/'host-reference/app/modules/qbittorrent/qbittorrent.py';MOD=ROOT/'host-reference/app/modules/qbittorrent/__init__.py';HELP=ROOT/'host-reference/app/helper/service.py';TT=ROOT/'source-snapshot/torrenttransfer/__init__.py'
trace=[]
class Log:
    def __getattr__(self,_):return lambda *a,**k:None
env={'logger':Log(),'ServiceInfo':NS}
def build(path,name,names):
 methods=[copy.deepcopy(n) for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.FunctionDef) and n.name in names]
 node=ast.ClassDef(name=name,bases=[],keywords=[],body=methods,decorator_list=[])
 exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),env)
 return env[name]
Qb=build(QB,'Qbittorrent',{'is_inactive','reconnect'})
Module=build(MOD,'QbittorrentModule',{'scheduler_job'})
Helper=build(HELP,'ServiceBaseHelper',{'get_configs','iterate_module_instances','get_service'})
Plugin=build(TT,'TorrentTransfer',{'service_info'})
a,b=Qb(),Qb()
for obj in [a,b]:obj._host='owned.invalid';obj._port=1
a.qbc=NS();b.qbc=None
entered,release,finished=threading.Event(),threading.Event(),threading.Event()
def login():
 trace.append('background.B.ctor.enter');entered.set()
 if not release.wait(3):raise TimeoutError('owned test gate not released')
 trace.append('background.B.ctor.exit');return NS()
b._Qbittorrent__login_qbittorrent=login
module=Module();module.get_instances=lambda:{'A':a,'B':b}
configs=[NS(name='A',type='qbittorrent',enabled=True),NS(name='B',type='qbittorrent',enabled=True)]
env['ServiceConfigHelper']=NS(get_configs=lambda *_:configs)
helper=Helper();helper.config_key='fixture';helper.conf_type=NS;helper.module_type='Downloader';helper.modulemanager=NS(get_running_type_modules=lambda _:[module])
env['DownloaderHelper']=lambda:helper
def background():
 try:module.scheduler_job()
 finally:finished.set()
thread=threading.Thread(target=background);thread.start()
try:
 if not entered.wait(1):raise AssertionError('source common reconnect never entered B')
 service=Plugin.service_info('A')
 trace.append('foreground.A.service.return')
 state={'returned_A':service is not None and service.instance is a,'B_still_blocked':not finished.is_set(),'A_inactive':a.is_inactive()}
 assert state=={'returned_A':True,'B_still_blocked':True,'A_inactive':False},state
finally:release.set();thread.join()
result={'kind':'exact installed module.scheduler_job + wrapper is_inactive/reconnect + helper resolver + TT service_info AST with synthetic blocked constructor callback','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [QB,MOD,HELP,TT]},'while_B_reconnect_blocked':state,'trace':trace,'limitations':['B ctor is an explicit Event dependency; no real network/constructor/login/package import/live config','No target implementation or expected result derived from Go. Demonstrates source lacks a shared getter/probe lock, not wall-clock performance under production load']}
HERE.joinpath('cached-presence-concurrency-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
