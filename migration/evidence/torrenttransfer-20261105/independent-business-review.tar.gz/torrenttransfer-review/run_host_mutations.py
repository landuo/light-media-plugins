#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,os,sys
R=Path(__file__).resolve().parent;H=Path('/Users/accidia/projects/light-media')
specs=[
 ('drop-adapter-retry','internal/plugins/iyuuautoseed/native/source_qb_read.go','for adapter := 0; adapter < 2; adapter++ {','for adapter := 0; adapter < 1; adapter++ {','./internal/plugins/iyuuautoseed/native','^TestSourceReadAuthMatchesRealSessionRetryMatrix$',{}),
 ('accept-signed-retry-after','internal/plugins/iyuuautoseed/native/source_qb_read.go','err == nil && raw != "" && strings.Trim(raw, "0123456789") == ""','err == nil','./internal/plugins/iyuuautoseed/native','^TestSourceRetryAfterPlusMatchesActualInvalidHeader$',{}),
 ('cached-read-waits-for-reconnect','internal/app/plugin_original_source_connections.go','if ready {\n\t\treturn nil\n\t}','if ready {\n\t\trelease, err := a.sourceConnectionProbeGate(ctx)\n\t\tif err != nil { return err }; release(); return nil\n\t}','./internal/app','^TestSourceConnectionActualSDKActiveAReadableDuringBReconnect$',{}),
 ('host-cron-go-whitespace','internal/plugins/schedule/cron.go','parts := legacyanime.Fields(expression)','parts := strings.Fields(expression); _ = legacyanime.Fields','./internal/plugins/schedule','^TestIndependentActualCronWhitespace$',json.loads((R/'host-lexer-review-overlay.json').read_text())['Replace'])]
rows=[]
if len(sys.argv)>1:
 rows=[x for x in json.loads((R/'host-source-final-mutation-results.json').read_text())['results'] if x['mutation']!=sys.argv[1]]
for name,file,old,new,pkg,test,extra in specs:
 if len(sys.argv)>1 and name!=sys.argv[1]:continue
 p=H/file;before=p.read_bytes();s=before.decode();assert s.count(old)==1,(name,s.count(old))
 q=R/(name+'-host-mutant.go');q.write_text(s.replace(old,new,1))
 overlay=R/(name+'-host-overlay.json');overlay.write_text(json.dumps({'Replace':{**extra,str(p):str(q)}},indent=2)+'\n')
 env=os.environ.copy();env['TMPDIR']=str(R/'final-host-owned-tmp');env['PLUGIN_SOURCE_DOWNLOADER_FIXTURE_BINARY']=str(R/'final-source-fixture')
 cmd=['go','test','-count=1','-json','-overlay='+str(overlay),'-run',test,pkg]
 result=subprocess.run(cmd,cwd=H,env=env,capture_output=True,text=True,timeout=80)
 (R/(name+'-host-mutant.jsonl')).write_text(result.stdout);(R/(name+'-host-mutant.stderr')).write_text(result.stderr)
 parsed=[]
 for line in result.stdout.splitlines():
  try:parsed.append(json.loads(line))
  except:pass
 failures=[x.get('Test') for x in parsed if x.get('Action')=='fail' and x.get('Test')]
 buildfail=any(x.get('Action')=='build-fail' for x in parsed) or 'build failed' in result.stdout+result.stderr
 row={'mutation':name,'file':file,'original_sha256':hashlib.sha256(before).hexdigest(),'mutant_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'exit':result.returncode,'failures':failures,'build_failed':buildfail,'killed':result.returncode!=0 and bool(failures) and not buildfail,'product_unchanged':p.read_bytes()==before}
 rows.append(row);print(json.dumps(row),flush=True)
(R/'host-source-final-mutation-results.json').write_text(json.dumps({'kind':'independent single-file Go overlay counterfactuals; no host product edits','results':rows},indent=2)+'\n')
assert all(x['killed'] and x['product_unchanged'] for x in rows)
