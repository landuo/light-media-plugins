package torrenttransfer

import (
	"bytes"
	cryptorand "crypto/rand"
	"context"
	"errors"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"syscall"
	"testing"
	"time"

	"github.com/landuo/light-media-plugins/internal/sdk"
)

// Source oracle: captured Python3.12.13 pathlib.py:45,852-868; EACCES raises.
// This touches only t.TempDir and restores its own test parent's mode on exit.
func TestIndependentExistsSource312PermissionError(t *testing.T) {
	if runtime.GOOS == "windows" || os.Geteuid() == 0 { t.Skip("unprivileged POSIX test required") }
	root := t.TempDir()
	restricted := filepath.Join(root,"restricted")
	if e := os.Mkdir(restricted,0700); e != nil { t.Fatal(e) }
	file := filepath.Join(restricted,"owned")
	if e := os.WriteFile(file,[]byte("owned"),0600); e != nil { t.Fatal(e) }
	if e := os.Chmod(restricted,0); e != nil { t.Fatal(e) }
	defer os.Chmod(restricted,0700)
	if _,e := os.Stat(file); !errors.Is(e,syscall.EACCES) { t.Skipf("fixture does not produce EACCES: %v",e) }
	ok,e := (sdkHost{}).Exists(context.Background(),file)
	if ok || !errors.Is(e,syscall.EACCES) { t.Fatalf("Python3.12 raises EACCES, Go got exists=%v error=%v",ok,e) }
}

// Installed Scheduler.start has a synchronous ordinary-function branch and
// clears running only in its finalizer. Keep the owner call open until the
// last selected task's history and summary have completed, across fresh calls.
func TestIndependentTransferOwnerWaitsForLastTorrent(t *testing.T) {
	f:=startBudgetFixture(t,2)
	f.call("init",f.config())
	entered,release:=make(chan struct{}),make(chan struct{})
	last:=fmt.Sprintf("%040x",2)
	var host plugins.HostHandler
	host=func(ctx context.Context,id plugins.Identity,m string,raw json.RawMessage)(json.RawMessage,error){
		if m==plugins.BackgroundSubmitCapability {
			var in struct{Method string;Payload json.RawMessage}
			if e:=json.Unmarshal(raw,&in);e!=nil{return nil,e}
			pending,e:=f.client.StartCallWithAdmission(ctx,f.ctx,in.Method,in.Payload,host,plugins.CallOptions{CallerDeadlineOnly:true})
			if e!=nil{return nil,e}
			go func(){result,e:=pending.Wait();f.mu.Lock();f.phases=append(f.phases,phaseObservation{method:in.Method,result:result,err:e});f.mu.Unlock()}()
			return json.RawMessage(`{"accepted":true}`),nil
		}
		if m==plugins.BaseSaveData {
			var in struct{Key string}
			if e:=json.Unmarshal(raw,&in);e!=nil{return nil,e}
			if in.Key=="Source-"+last {
				close(entered)
				select{case<-release:case<-ctx.Done():return nil,ctx.Err()}
			}
		}
		return f.host(ctx,id,m,raw)
	}
	done:=make(chan error,1)
	go func(){_,e:=f.client.CallWithOptions(f.ctx,"transfer",json.RawMessage(`null`),host,plugins.CallOptions{CallerDeadlineOnly:true});done<-e}()
	select{case<-entered:case<-time.After(3*time.Second):t.Fatal("last torrent history did not block")}
	f.mu.Lock();saved:=len(f.history);f.mu.Unlock()
	if saved!=1 {t.Fatalf("wanted one completed torrent before final block, got %d",saved)}
	select{case e:=<-done:t.Fatalf("owner returned before final torrent completed: %v",e);case<-time.After(100*time.Millisecond):}
	close(release)
	select{case e:=<-done:if e!=nil{t.Fatal(e)};case<-time.After(3*time.Second):t.Fatal("owner did not finish")}
	f.mu.Lock();saved=len(f.history);notices:=len(f.notices);f.mu.Unlock()
	if saved!=2||notices!=1 {t.Fatalf("incomplete final effects: history=%d notices=%d",saved,notices)}
}

func TestIndependentPrivateStopAndReinitJoinWholePass(t *testing.T) {
	for _,method:=range []string{"stop_service","init"}{t.Run(method,func(t *testing.T){
		f:=startBudgetFixture(t,1)
		f.blockMethod=plugins.BaseSaveData
		cfg:=f.config();cfg["enabled"]=true;cfg["onlyonce"]=true
		f.call("init",cfg)
		for deadline:=time.Now().Add(3*time.Second);; {
			var tick bool
			out:=f.call("test_tick",nil)
			_ = json.Unmarshal(out.Result,&tick)
			if tick{break};if time.Now().After(deadline){t.Fatal("private timer never admitted")};time.Sleep(time.Millisecond)
		}
		select{case<-f.entered:case<-time.After(3*time.Second):t.Fatal("private transfer did not reach final effect")}
		input:=json.RawMessage(`null`)
		if method=="init"{cfg["enabled"]=false;cfg["onlyonce"]=false;cfg["notify"]=false;raw,e:=json.Marshal(cfg);if e!=nil{t.Fatal(e)};input=raw}
		done:=make(chan error,1)
		go func(){_,e:=f.client.CallWithOptions(f.ctx,method,input,f.host,plugins.CallOptions{CallerDeadlineOnly:true});done<-e}()
		select{case e:=<-done:t.Fatalf("%s returned with private pass active: %v",method,e);case<-time.After(100*time.Millisecond):}
		close(f.release)
		select{case e:=<-done:if e!=nil{t.Fatal(e)};case<-time.After(3*time.Second):t.Fatal("stop/reinit did not join")}
		f.mu.Lock();saved:=len(f.history);notices:=len(f.notices);f.mu.Unlock()
		if saved!=1 {t.Fatal("private pass abandoned history",saved)}
		if method=="init"&&notices!=0 {t.Fatal("old pass did not read newly published notify=false",notices)}
	})}
}

func TestIndependentExistsSource312MissingAndValueError(t *testing.T) {
	for _,path := range []string{filepath.Join(t.TempDir(),"absent"),"/owned\x00path"} {
		ok,e := (sdkHost{}).Exists(context.Background(),path)
		if ok || e != nil { t.Fatalf("source exists false for missing/embedded-NUL, got %v %v",ok,e) }
	}
}

func TestIndependentDistinctSurrogateObjectKeys(t *testing.T) {
	for _,c:=range []struct{raw,want string}{
		{`{"\ud800":1,"\ud801":2}`,`{'\ud800': 1, '\ud801': 2}`},
		{`{"\ud800":1,"�":2}`,`{'\ud800': 1, '�': 2}`},
		{`{"a":0,"\ud800":1,"\ud801":2,"\ud800":3}`,`{'a': 0, '\ud800': 3, '\ud801': 2}`},
	}{got,e:=sourceSkipWire(json.RawMessage(c.raw),nil);if e!=nil||got==nil||*got!=c.want{actual:="<nil>";if got!=nil{actual=*got};t.Fatalf("source json.loads+repr %s => %s; got=%q error=%v",c.raw,c.want,actual,e)}}
}

func TestIndependentRandomTagUsesInstalledAlphabet(t *testing.T) {
	// Exact installed helper index oracle, no assertion about random sequences.
	const source="ABCDEFGHIGKLMNOPQRSTUVWXYZabcdefghigklmnopqrstuvwxyz0123456789"
	input:=make([]byte,62)
	for i:=range input{input[i]=byte(i)}
	old:=cryptorand.Reader
	cryptorand.Reader=bytes.NewReader(input)
	defer func(){cryptorand.Reader=old}()
	got,e:=(sdkHost{}).RandomTag(context.Background(),62)
	if e!=nil||got!=source{t.Fatalf("installed index alphabet %q, got %q (%v)",source,got,e)}
}

func TestIndependentVendorWireReachesSourceSDKWithoutCoercion(t *testing.T) {
	raw,e:=os.ReadFile("../../work/migration-20261105/torrenttransfer-review/vendor-skip-wire.json")
	if e!=nil{t.Fatal(e)}
	var oracle struct{Cases []struct{InputJSON string `json:"input_json"`;Wire []string `json:"wire_values"`}}
	if e=json.Unmarshal(raw,&oracle);e!=nil{t.Fatal(e)}
	for _,c:=range oracle.Cases{t.Run(c.InputJSON,func(t *testing.T){
		calls:=0
		h:=sdkHost{caller:func(_ context.Context,m string,raw json.RawMessage)(json.RawMessage,error){
			calls++
			if m!=plugins.DownloaderSourceAddCapability{t.Fatalf("wrong source capability %s",m)}
			var request plugins.DownloaderSourceAddRequestV1
			if e:=json.Unmarshal(raw,&request);e!=nil{t.Fatal(e)}
			if request.SkipChecking!=nil{t.Fatal("raw value passed through bool coercion")}
			if len(c.Wire)==0 {if request.SkipCheckingWire!=nil{t.Fatal("null not omitted")}} else if request.SkipCheckingWire==nil||*request.SkipCheckingWire!=c.Wire[0]{t.Fatalf("source wire %q got %v",c.Wire,request.SkipCheckingWire)}
			return json.Marshal(plugins.DownloaderSourceMutationResultV1{DownloaderMutationV1:plugins.DownloaderMutationV1{SchemaVersion:1,DownloaderID:"target",Accepted:false,Outcome:"rejected"},NativeError:true})
		}}
		out,e:=h.AddPaused(context.Background(),Service{Type:"qbittorrent",Ref:"target"},AddSpec{Content:[]byte("owned"),SavePath:"/owned",SkipCheckingRaw:json.RawMessage(c.InputJSON)})
		if e!=nil||calls!=1||!out.SourceTruthy||out.Accepted{t.Fatalf("ordinary False tuple source branch changed: %+v %v calls=%d",out,e,calls)}
	})}
}
