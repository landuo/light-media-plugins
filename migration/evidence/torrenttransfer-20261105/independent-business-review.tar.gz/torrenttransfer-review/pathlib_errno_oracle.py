#!/usr/bin/env python3
"""Exact installed 3.12 exists AST, synthetic stat exceptions, no filesystem IO."""
from __future__ import annotations
import ast
import errno
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/"python-runtime-reference/stdlib/pathlib.py"
tree=ast.parse(SOURCE.read_text())
scope={"_IGNORED_ERRNOS":(errno.ENOENT,errno.ENOTDIR,errno.EBADF,errno.ELOOP),
       "_IGNORED_WINERRORS":(21,123,1921)}
ignore=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=="_ignore_error")
exists=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="exists")
exec(compile(ast.Module(body=[ignore,exists],type_ignores=[]),str(SOURCE),"exec"),scope)
rows=[]
vectors=[("success",None)]+[(name,OSError(getattr(errno,name),"synthetic stat fault")) for name in
            ("ENOENT","ENOTDIR","EBADF","ELOOP","EACCES","EPERM","EIO","EINVAL","ENAMETOOLONG")]+[("ValueError-NUL",ValueError("embedded null byte"))]
for name,fault in vectors:
    def stat(**kw):
        if fault:raise fault
        return NS(st_mode=0)
    outcome={"case":name}
    try:outcome["exists"]=scope["exists"](NS(stat=stat))
    except Exception as exc:outcome.update(raises=type(exc).__name__,errno=getattr(exc,"errno",None))
    rows.append(outcome)
result={"source_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),"installed_python":"3.12.13",
        "kind":"installed exists/_ignore_error method AST with synthetic stat exception; no real permission mutation",
        "cases":rows}
HERE.joinpath("pathlib-errno-oracle.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
