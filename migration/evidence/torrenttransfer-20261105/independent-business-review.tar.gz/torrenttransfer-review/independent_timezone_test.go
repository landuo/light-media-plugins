package torrenttransfer

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestIndependentInstalledCronWhitespace(t *testing.T) {
	raw,e:=os.ReadFile("../../work/migration-20261105/torrenttransfer-review/cron-whitespace-source-oracle.json");if e!=nil{t.Fatal(e)}
	var oracle struct{Cases []struct{Code string `json:"separator_codepoint"`;Expression string;Accepted bool}}
	if e=json.Unmarshal(raw,&oracle);e!=nil{t.Fatal(e)}
	t.Setenv("TZ","UTC")
	for _,c:=range oracle.Cases{t.Run(c.Code,func(t *testing.T){
		if !c.Accepted{t.Fatal("source positive fixture malformed")}
		if _,e:=ParseCrontab(c.Expression,"UTC");e!=nil{t.Fatalf("source str.split accepts separator %s: %v",c.Code,e)}
		cfg:=NewConfig();cfg.values=map[string]any{"enabled":true,"cron":c.Expression,"fromdownloader":"Source","todownloader":"Target","fromtorrentpath":"/owned/backup"}
		p:=New();p.setConfig(cfg);out,e:=p.Handle(context.Background(),"get_service",nil,nil);if e!=nil{t.Fatal(e)}
		var jobs []struct{Trigger struct{Cron string}}
		if e=json.Unmarshal(out,&jobs);e!=nil||len(jobs)!=1||jobs[0].Trigger.Cron!=c.Expression{t.Fatalf("source raw cron declaration changed: %s %v",out,e)}
	})}
}

// Expected branches come from timezone-source-oracle.json, extracted from the
// installed tzlocal/APS/Settings function AST before this Go test was written.
func TestIndependentInstalledTimezoneBranches(t *testing.T) {
	type row struct { name string; env *string; files map[string][]byte; local string; public string; publicError bool; private string; privateError bool }
	ptr := func(s string) *string { return &s }
	for _, c := range []row{
		{name:"unset", files:map[string][]byte{"etc/timezone":[]byte("Etc/UTC")}, public:"Etc/UTC",private:"Asia/Shanghai"},
		{name:"empty",env:ptr(""),files:map[string][]byte{"etc/timezone":[]byte("Etc/UTC")},public:"Etc/UTC",privateError:true},
		{name:"explicitUTC",env:ptr("UTC"),files:map[string][]byte{"etc/timezone":[]byte("Asia/Shanghai")},public:"UTC",private:"UTC"},
		{name:"explicitShanghai",env:ptr("Asia/Shanghai"),public:"Asia/Shanghai",private:"Asia/Shanghai"},
		{name:"colonUTC",env:ptr(":UTC"),public:"UTC",privateError:true},
		{name:"whitespaceENV",env:ptr(" Asia/Shanghai "),files:map[string][]byte{"etc/timezone":[]byte("Etc/UTC")},publicError:true,private:"Asia/Shanghai"},
		{name:"invalidENV",env:ptr("No/Such_Zone"),files:map[string][]byte{"etc/timezone":[]byte("Etc/UTC")},publicError:true,privateError:true},
		{name:"staleEtcTimezone",files:map[string][]byte{"etc/timezone":[]byte("Asia/Shanghai")},local:"Etc/UTC",public:"Etc/UTC",private:"Asia/Shanghai"},
		{name:"conflict",files:map[string][]byte{"var/db/zoneinfo":[]byte("Asia/Shanghai"),"etc/sysconfig/clock":[]byte("ZONE=\"Europe/London\"\n")},publicError:true,private:"Asia/Shanghai"},
		{name:"alias",files:map[string][]byte{"var/db/zoneinfo":[]byte("UTC"),"etc/sysconfig/clock":[]byte("ZONE=\"Etc/UTC\"\n")},public:"UTC",private:"Asia/Shanghai"},
		{name:"invalidConfig",files:map[string][]byte{"etc/timezone":[]byte("No/Such_Zone")},publicError:true,private:"Asia/Shanghai"},
		{name:"anonymousBinaryMarker",local:"BINARY",public:"local",private:"Asia/Shanghai"},
		{name:"noConfigUTC",public:"UTC",private:"Asia/Shanghai"},
		{name:"explicitBinaryMarker",env:ptr("FILE"),public:"local",privateError:true},
		{name:"unicodeClockWhitespace",files:map[string][]byte{"etc/sysconfig/clock":[]byte("\u00a0ZONE=\"Asia/Shanghai\"\n")},public:"Asia/Shanghai",private:"Asia/Shanghai"},
		{name:"invalidUTF8ClockIgnored",files:map[string][]byte{"etc/sysconfig/clock":append([]byte{0xff,'\n'},[]byte("ZONE=\"Asia/Shanghai\"\n")...)},public:"UTC",private:"Asia/Shanghai"},
		{name:"malformedClockLine",files:map[string][]byte{"etc/sysconfig/clock":[]byte("ZONE=\"\nTIMEZONE=\"Asia/Shanghai\"\n")},public:"Asia/Shanghai",private:"Asia/Shanghai"},
		{name:"badLocaltimeBinary",local:"BAD",publicError:true,private:"Asia/Shanghai"},
		{name:"emptyEnvBinaryMarker",env:ptr(""),local:"BINARY",public:"local",privateError:true},
	} { t.Run(c.name,func(t *testing.T){
		root:=t.TempDir()
		write:=func(name string,b []byte){p:=filepath.Join(root,name);if e:=os.MkdirAll(filepath.Dir(p),0700);e!=nil{t.Fatal(e)};if e:=os.WriteFile(p,b,0600);e!=nil{t.Fatal(e)}}
		for _,name:=range []string{"Etc/UTC","Asia/Shanghai","Europe/London"}{b,e:=os.ReadFile(filepath.Join("/usr/share/zoneinfo",name));if e!=nil{t.Fatal(e)};write(filepath.Join("usr/share/zoneinfo",name),b)}
		if e:=os.Symlink("Etc/UTC",filepath.Join(root,"usr/share/zoneinfo/UTC"));e!=nil{t.Fatal(e)}
		for name,b:=range c.files{write(name,b)}
		if c.local!=""{if c.local=="BINARY"{b,e:=os.ReadFile(filepath.Join(root,"usr/share/zoneinfo/Asia/Shanghai"));if e!=nil{t.Fatal(e)};write("etc/localtime",b)}else if c.local=="BAD"{write("etc/localtime",[]byte("not a TZif file"))}else{if e:=os.MkdirAll(filepath.Join(root,"etc"),0700);e!=nil{t.Fatal(e)};if e:=os.Symlink(filepath.Join(root,"usr/share/zoneinfo",c.local),filepath.Join(root,"etc/localtime"));e!=nil{t.Fatal(e)}}}
		t.Setenv("TZ","");if c.env==nil{os.Unsetenv("TZ")}else if *c.env=="FILE"{b,e:=os.ReadFile(filepath.Join(root,"usr/share/zoneinfo/Asia/Shanghai"));if e!=nil{t.Fatal(e)};write("custom-zone",b);os.Setenv("TZ",filepath.Join(root,"custom-zone"))}else{os.Setenv("TZ",*c.env)}
		zone,e:=sourcePublicTimezone(root);if (e!=nil)!=c.publicError||!c.publicError&&zone!=c.public{t.Errorf("public zone=%q err=%v, want zone=%q error=%v",zone,e,c.public,c.publicError)}
		zone,e=privateTimezone();if (e!=nil)!=c.privateError||!c.privateError&&zone!=c.private{t.Errorf("private zone=%q err=%v, want zone=%q error=%v",zone,e,c.private,c.privateError)}
	}) }
}

func TestIndependentInvalidPrivateTimezonePreservesOnlyOnce(t *testing.T) {
	for _,env:=range []string{"",":UTC","No/Such_Zone"}{t.Run(env,func(t *testing.T){
		t.Setenv("TZ",env)
		cfg:=NewConfig()
		input:=map[string]any{"onlyonce":true,"fromdownloader":"Source","todownloader":"Dest"}
		h:=newOracleHost(input,map[string]any{})
		result,e:=cfg.Init(context.Background(),input,h)
		if e==nil||result.Scheduler||!cfg.flag("onlyonce")||len(result.ConfigWrites)!=0{t.Fatalf("private scheduler must raise before consuming source onlyonce: result=%+v once=%v err=%v",result,cfg.flag("onlyonce"),e)}
	})}
}
