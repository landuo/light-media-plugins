#!/usr/bin/env python3
"""Bind all TT/command/SDK inputs; evidence only, no product file writes."""
import datetime
import hashlib
import json
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def inputs():
    paths=[ROOT/'go.mod',ROOT/'go.sum']
    for name in ['plugins/torrenttransfer','cmd/torrent-transfer','internal/sdk']:
        paths.extend(p for p in (ROOT/name).rglob('*') if p.is_file())
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}
def review_inputs():
    names=['review-overlay.json','independent_review_test.go','independent_timezone_test.go','independent_service_order_test.go','independent_unknown_test.go','module-service-order-oracle.json','unknown-native-source-oracle.json','cached-connection-source-oracle.json','protocol_budget_review_test.go','review-driver-binding.json']
    return {name:hashlib.sha256((HERE/name).read_bytes()).hexdigest() for name in names}
mode=sys.argv[1]
target=HERE/sys.argv[2]
if mode=='snapshot':
    value={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':inputs(),'independent_overlay_inputs':review_inputs()}
    target.write_text(json.dumps(value,indent=2)+'\n')
    print(json.dumps({'target_files':len(value['target']),'overlay_inputs':len(value['independent_overlay_inputs']),'snapshot':str(target)}))
elif mode=='verify':
    before=json.loads(target.read_text());after=inputs();review=review_inputs()
    changed=[name for name in sorted(set(before['target'])|set(after)) if before['target'].get(name)!=after.get(name)]
    changed_review=[name for name in sorted(set(before['independent_overlay_inputs'])|set(review)) if before['independent_overlay_inputs'].get(name)!=review.get(name)]
    result={'target_changed':changed,'overlay_changed':changed_review,'all_unchanged':not changed and not changed_review}
    print(json.dumps(result,indent=2))
    if len(sys.argv)>3:(HERE/sys.argv[3]).write_text(json.dumps(result,indent=2)+'\n')
    assert result['all_unchanged'],result
else:raise SystemExit('snapshot|verify required')
