#!/usr/bin/env python3
"""Redirect test observation output only; keep the author's frozen files intact."""
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
source=ROOT/'plugins/torrenttransfer/protocol_budget_test.go'
original=source.read_text()
before='../../work/migration-20261105/torrenttransfer/sdk-observations'
after='../../work/migration-20261105/torrenttransfer-review/sdk-observations-final'
assert original.count(before)==1
copied=original.replace(before,after,1)
target=HERE/'protocol_budget_review_test.go';target.write_text(copied)
overlay=HERE/'review-overlay.json';value=json.loads(overlay.read_text());value['Replace'][str(source)]=str(target);overlay.write_text(json.dumps(value,indent=2)+'\n')
result={'source':str(source),'source_sha256':hashlib.sha256(original.encode()).hexdigest(),'review_driver':str(target),'review_driver_sha256':hashlib.sha256(copied.encode()).hexdigest(),'only_change':{'from':before,'to':after},'business_assertions_timer_and_budget_changes':False}
HERE.joinpath('review-driver-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
