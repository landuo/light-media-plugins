package torrenttransfer

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"strings"
	"testing"

	"github.com/landuo/light-media-plugins/internal/sdk"
)

func TestIndependentActualModuleServiceOrdering(t *testing.T) {
	raw,e:=os.ReadFile("../../work/migration-20261105/torrenttransfer-review/module-service-order-oracle.json");if e!=nil{t.Fatal(e)}
	var oracle struct{ Cases []struct{
		Name string `json:"case"`
		Inputs []struct{Name,Type,Label string;Enabled bool} `json:"config_inputs"`
		FormOrder []string `json:"form_order"`
		Services map[string]struct{MetadataKind string `json:"metadata_kind"`;RuntimeClass string `json:"runtime_class"`;RuntimeMarker string `json:"runtime_marker"`} `json:"get_service"`
	}}
	if e=json.Unmarshal(raw,&oracle);e!=nil{t.Fatal(e)}
	for _,c:=range oracle.Cases{t.Run(c.Name,func(t *testing.T){
		refs:=[]plugins.BrushDownloaderReferenceV1{}
		kinds:=map[string]string{}
		for _,r:=range c.Inputs{refs=append(refs,plugins.BrushDownloaderReferenceV1{ID:r.Label,Name:r.Name,Kind:r.Type,Enabled:r.Enabled});kinds[r.Label]=r.Type}
		host:=func(_ context.Context,m string,raw json.RawMessage)(json.RawMessage,error){switch m{
			case plugins.DownloaderConfigurationsReadCapability:return json.Marshal(plugins.DownloaderConfigurationsV1{SchemaVersion:1,Downloaders:refs})
			case plugins.DownloaderSourceConnectionCapability:var in plugins.DownloaderConnectionRequestV1;if e:=json.Unmarshal(raw,&in);e!=nil{return nil,e};return json.Marshal(plugins.DownloaderSourceConnectionV1{DownloaderConnectionV1:plugins.DownloaderConnectionV1{SchemaVersion:1,DownloaderID:in.DownloaderID,Kind:kinds[in.DownloaderID]},Exists:true})
			default:return nil,fmt.Errorf("unexpected source configuration dependency %s",m)
		}}
		for name,want:=range c.Services{
			service,e:=(sdkHost{caller:host}).Service(context.Background(),name)
			if e!=nil||service==nil{t.Fatalf("source service %s lost: %+v %v",name,service,e)}
			if service.Type!=want.MetadataKind||service.actualKind()!=strings.ToLower(want.RuntimeClass)||service.Ref!=want.RuntimeMarker{t.Fatalf("source metadata/runtime binding %s changed: got %+v want %+v",name,service,want)}
		}
		value,e:=New().Handle(context.Background(),"get_form",nil,host);if e!=nil{t.Fatal(e)}
		var form any;if e=json.Unmarshal(value,&form);e!=nil{t.Fatal(e)}
		selects:=0
		var visit func(any)
		visit=func(v any){switch x:=v.(type){case []any:for _,child:=range x{visit(child)};case map[string]any:
			if props,ok:=x["props"].(map[string]any);ok&&(props["model"]=="fromdownloader"||props["model"]=="todownloader"){
				got:=[]string{};for _,item:=range props["items"].([]any){object:=item.(map[string]any);if object["title"]!=object["value"]{t.Fatal("source names changed")};got=append(got,object["value"].(string))}
				if !reflect.DeepEqual(got,c.FormOrder){t.Errorf("source first-name-slot form order got%v want%v",got,c.FormOrder)};selects++
			};for _,child:=range x{visit(child)}
		}}
		visit(form);if selects!=2{t.Fatal("source downloader selects missing",selects)}
	})}
}

// The installed source metadata/runtime oracle proves add happens before the
// TR-style tuple.hashString error, even on an ordinary False QB wrapper tuple.
// This checks the finite IPC request and business ordering, not daemon HTTP.
func TestIndependentMixedKindAddBeforeAttributeFailure(t *testing.T) {
	for n:=0;n<=4;n++{for _,accepted:=range []bool{true,false}{t.Run(fmt.Sprintf("labels-%d-accepted-%v",n,accepted),func(t *testing.T){
		labels:=append([]string{},[]string{"a","b","c","d"}[:n]...)
		adds:=0
		host:=func(_ context.Context,m string,raw json.RawMessage)(json.RawMessage,error){switch m{
			case plugins.DownloaderConfigurationsReadCapability:return json.Marshal(plugins.DownloaderConfigurationsV1{SchemaVersion:1,Downloaders:[]plugins.BrushDownloaderReferenceV1{{ID:"source-qb",Name:"Source",Kind:"qbittorrent",Enabled:true}}})
			case plugins.DownloaderSourceConnectionCapability:return json.Marshal(plugins.DownloaderSourceConnectionV1{DownloaderConnectionV1:plugins.DownloaderConnectionV1{SchemaVersion:1,DownloaderID:"source-qb",Kind:"qbittorrent"},Exists:true})
			case plugins.DownloaderSourceAddCapability:
				var in plugins.DownloaderSourceAddRequestV1;if e:=json.Unmarshal(raw,&in);e!=nil{return nil,e};adds++
				if in.DownloaderID!="mixed-qb"||!in.Paused||len(in.Tags)!=0||in.Category!=nil||in.SkipChecking!=nil||in.SkipCheckingWire!=nil||len(in.QBLabels)!=len(labels){t.Fatalf("source TR kwargs changed: %+v",in)}
				for i,label:=range labels{if in.QBLabels[i]!=label{t.Fatal("source repeated labels order changed")}}
				outcome:="confirmed";if !accepted{outcome="rejected"}
				return json.Marshal(plugins.DownloaderSourceMutationResultV1{DownloaderMutationV1:plugins.DownloaderMutationV1{SchemaVersion:1,DownloaderID:"mixed-qb",Accepted:accepted,Outcome:outcome},NativeError:!accepted})
			default:return nil,fmt.Errorf("unexpected request after metadataTR/nativeQB add: %s",m)
		}}
		cfg:=NewConfig();cfg.values["fromdownloader"]="Source";cfg.tags=labels
		core,e:=NewCore(cfg,sdkHost{caller:host});if e!=nil{t.Fatal(e)}
		_,e=core.download(context.Background(),Service{Name:"Mixed",Type:"transmission",RuntimeKind:"qbittorrent",Ref:"mixed-qb"},[]byte("owned material"),"/owned/payload",Torrent{})
		if adds!=1||e==nil||!strings.Contains(e.Error(),"hashString"){t.Fatalf("source add-before-AttributeError changed: adds=%d error=%v",adds,e)}
	})}}
}

func TestIndependentReverseMetadataSignatureBeforeAdd(t *testing.T) {
	for _,skip:=range []any{nil,false,"false",[]any{}}{t.Run(fmt.Sprintf("%T-%v",skip,skip),func(t *testing.T){
		adds:=0
		host:=func(_ context.Context,m string,raw json.RawMessage)(json.RawMessage,error){
			if m!=plugins.DownloaderSourceAddCapability{return nil,fmt.Errorf("unexpected method %s",m)};adds++
			return json.Marshal(plugins.DownloaderSourceMutationResultV1{DownloaderMutationV1:plugins.DownloaderMutationV1{SchemaVersion:1,DownloaderID:"runtime-tr",Outcome:"confirmed",Accepted:true},NativeError:false})
		}
		_,e:=(sdkHost{caller:host}).AddPaused(context.Background(),Service{Name:"Mixed",Type:"qbittorrent",RuntimeKind:"transmission",Ref:"runtime-tr"},AddSpec{Content:[]byte("owned"),SavePath:"/owned/payload",Tags:[]string{"owned","OWNEDTAG10"},SkipChecking:skip})
		if adds!=0||e==nil{t.Fatalf("source signature TypeError must happen before native add: adds=%d error=%v",adds,e)}
	})}
}
