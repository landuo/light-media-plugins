#!/usr/bin/env python3
"""Execute installed synchronous scheduler/API methods with an owned blocker."""
from __future__ import annotations
import ast
import asyncio
import hashlib
import inspect
import json
import multiprocessing
import threading
from pathlib import Path
from types import SimpleNamespace as NS

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/"host-reference"
SCHED=ROOT/"app/scheduler.py"
API=ROOT/"app/api/endpoints/system.py"
observed=[]

class Progress:
    def __init__(self,*a,**kw):pass
    def start(self):observed.append("progress.start")
    def update(self,**kw):pass
    def get(self):return {}
    def end(self,**kw):observed.append("progress.end")

class Quiet:
    def __getattr__(self,name):return lambda *a,**kw:None

names={"__prepare_job","__finish_job","__supports_progress_callback","__get_result_error","start"}
tree=ast.parse(SCHED.read_text())
source=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="Scheduler")
cls=ast.ClassDef(name="Scheduler",bases=[],keywords=[],body=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in names],decorator_list=[])
scope=dict(globals(),ProgressHelper=Progress,logger=Quiet(),global_vars=NS(loop=None))
exec(compile(ast.fix_missing_locations(ast.Module(body=[cls],type_ignores=[])),str(SCHED),"exec",flags=__import__("__future__").annotations.compiler_flag),scope)
s=scope["Scheduler"]()
s._lock=threading.Lock()
s._format_time=lambda:"synthetic-time"
s._get_progress_key=lambda job_id:job_id
entered=threading.Event();release=threading.Event();returned=threading.Event()

def transfer():
    observed.append("transfer.enter")
    entered.set()
    if not release.wait(2):raise RuntimeError("synthetic blocker timed out")
    observed.append("transfer.exit")

job_id="TorrentTransfer_TorrentTransfer"
s._jobs={job_id:{"func":transfer,"name":"转移做种服务","kwargs":{},"running":False}}
api=next(n for n in ast.parse(API.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=="run_scheduler")
api.decorator_list=[] # Router registration is not executed; exact function body.
scope.update(Scheduler=lambda:s,Depends=lambda value:None,get_current_active_superuser=object(),schemas=NS(Response=lambda **kw:kw))
exec(compile(ast.Module(body=[api],type_ignores=[]),str(API),"exec",flags=__import__("__future__").annotations.compiler_flag),scope)
result={}
def run():
    result["api_response"]=scope["run_scheduler"](job_id)
    observed.append("api.return")
    returned.set()

t=threading.Thread(target=run)
t.start()
assert entered.wait(1)
result["while_transfer_blocked"]={"api_returned":returned.is_set(),"running":s._jobs[job_id]["running"]}
release.set();t.join(2)
assert not t.is_alive()
result["after_transfer_completed"]={"api_returned":returned.is_set(),"running":s._jobs[job_id]["running"]}
result["trace"]=observed
assert result["while_transfer_blocked"]=={"api_returned":False,"running":True}
assert result["after_transfer_completed"]=={"api_returned":True,"running":False}
result["kind"]="captured installed Scheduler.start + prepare/finalize + run_scheduler API AST; synthetic synchronous plugin function/progress"
result["source_sha256"]={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (SCHED,API)}
HERE.joinpath("scheduler-completion-oracle.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps(result,ensure_ascii=False,indent=2))
