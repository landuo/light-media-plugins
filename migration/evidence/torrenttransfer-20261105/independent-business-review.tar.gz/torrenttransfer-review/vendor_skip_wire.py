#!/usr/bin/env python3
"""Execute captured vendor/wrapper AST against Requests.prepare; never send HTTP."""
from __future__ import annotations
import ast
import copy
import email.policy
import errno
import hashlib
import json
import os
import math
from collections.abc import Iterable, Mapping
from email.parser import BytesParser
from pathlib import Path
from types import SimpleNamespace as NS
import requests
import urllib3
import requests.models
import urllib3.fields
import urllib3.filepost
from packaging.version import Version

ROOT = Path(__file__).resolve().parent.parent
VENDOR = ROOT / "qbittorrent-vendor"
HOST = ROOT / "host-reference/app/modules/qbittorrent/qbittorrent.py"


def method(path: Path, name: str):
    tree = ast.parse(path.read_text())
    return copy.deepcopy(next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == name))


def make_class(name, methods, env):
    node = ast.ClassDef(name=name, bases=[], keywords=[], body=methods, decorator_list=[])
    unit = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
    # Same postponed-annotation mode as vendor; executable method AST unchanged.
    exec(compile(unit, str(VENDOR), "exec", flags=__import__("__future__").annotations.compiler_flag), env)
    return env[name]


class Quiet:
    def __getattr__(self, name):
        return lambda *a, **kw: None


env = dict(globals(), v=Version, APINames=NS(Torrents="torrents"), logger=Quiet(),
           JSONDecodeError=json.JSONDecodeError, TorrentsAddedMetadata=lambda value: value,
           path=os.path, os_strerror=os.strerror)
Format = make_class("Format", [method(VENDOR/"request.py", "_format_payload")], env)
Vendor = make_class("Vendor", [method(VENDOR/"request.py", "_list2string"),
                              method(VENDOR/"torrents.py", "_normalize_torrent_files"),
                              method(VENDOR/"torrents.py", "torrents_add")], env)
Wrapper = make_class("Qbittorrent", [method(HOST,"add_torrent"),method(HOST,"__parse_add_torrent_response")], env)

rows = []
vectors = [None, False, True, "false", "true", "0", "1", "other", "", 0, 1, 2,
           [], [1], ["false", "true"], {}, {"x": 1},
           1.0, 2.5, -0.0, 1e20, 1e-7, 1e-4, 1.2345678901234568e16,
           2**100, -(2**100), "quote'\"\\\n\r\t中文😀\x1b", ["a'b", 'a"b', "a'b\"c", "\\\n\r\t"],
           [True, False, None, [1.0, 2**100], {"z": 1, "a": 2}],
           {"z": 1, "a": 2, "m": {"b": [], "a": None}, "quote's": "中文😀\\\n"},
           {"a": 2, "z": 1}, json.loads("1e309"), json.loads("-1e309")]
for value in vectors:
    captured = {}
    vendor = Vendor()
    vendor.app_web_api_version = lambda: "2.11.0"

    def post(**kw):
        params, data, files = Format._format_payload("post", data=kw["data"], files=kw["files"])
        prepared = requests.Request("POST", "http://owned.invalid/api/v2/torrents/add",
                                    params=params, data=data, files=files).prepare()
        mime = ("Content-Type: " + prepared.headers["Content-Type"] + "\r\nMIME-Version: 1.0\r\n\r\n").encode() + prepared.body
        message = BytesParser(policy=email.policy.default).parsebytes(mime)
        fields = []
        for part in message.iter_parts():
            if part.get_param("name", header="content-disposition") == "skip_checking":
                fields.append(part.get_payload(decode=True).decode("utf-8"))
        captured["wire_values"] = fields
        captured["multipart"] = True
        response = requests.Response()
        response.status_code = 200
        response._content = b"Ok."
        return response

    vendor._post = post
    wrapper = Wrapper()
    wrapper.qbc = vendor
    wrapper._category = False
    wrapper._sequentail = False
    wrapper._first_last_piece = False
    result = wrapper.add_torrent(content=b"d4:infod6:lengthi1e4:name5:ownedee",
                                 download_dir="/owned/payload", is_paused=True,
                                 tag=["owned"], is_skip_checking=value)
    safe = value if not isinstance(value,float) or math.isfinite(value) else None
    rows.append({"input":safe,"input_repr":repr(value),"input_json":json.dumps(value,ensure_ascii=False) if safe is value else ("1e309" if value>0 else "-1e309"),"input_type":type(value).__name__,"source_wrapper_result":result,
                 "wrapper_tuple_truthy":bool(result),**captured})

comparison=[]
for mod,relative in [(requests.models,"requests/models.py"),(urllib3.filepost,"urllib3/filepost.py"),(urllib3.fields,"urllib3/fields.py")]:
    local=Path(mod.__file__).read_bytes()
    installed=(ROOT/"python-runtime-reference"/relative).read_bytes()
    comparison.append({"module":mod.__name__,"local_sha256":hashlib.sha256(local).hexdigest(),"installed_sha256":hashlib.sha256(installed).hexdigest(),"same_bytes":local==installed})
assert all(row["same_bytes"] for row in comparison)
result = {"kind":"captured-installed-vendor-AST + captured-installed-wrapper-AST + byte-matched Requests.prepare serialization methods",
          "scope":"No host/package import, no network send, no daemon, only synthetic bytes/paths/response",
          "vendor_version":"2026.6.0", "requests_version":requests.__version__, "urllib3_version":urllib3.__version__,
          "source_hashes":{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (HOST,VENDOR/"torrents.py",VENDOR/"request.py")},
          "serializer_comparison":comparison,
          "limitations":["Serialization critical files byte-match installed image; execution interpreter here is local Python3.14, installed interpreter3.12.13", "No assertion about daemon acceptance or skip behavior beyond actual constructed wire field", "Synthetic Ok response proves wrapper parse path only; source tuple remains truthy on ordinary False result too"],
          "cases":rows}
out = Path(__file__).with_name("vendor-skip-wire.json")
out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"evidence":str(out),"cases":[{"input":r["input"],"type":r["input_type"],"wire":r.get("wire_values"),"wrapper":r["source_wrapper_result"]} for r in rows]},ensure_ascii=False,indent=2))
