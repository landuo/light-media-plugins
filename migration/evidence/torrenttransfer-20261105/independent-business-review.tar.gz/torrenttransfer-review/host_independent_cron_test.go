package schedule
import (
 "encoding/json"
 "os"
 "testing"
 "time"
)
func TestIndependentActualCronWhitespace(t *testing.T) {
 raw,err:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/migration-20261105/torrenttransfer-review/cron-whitespace-source-oracle.json")
 if err!=nil {t.Fatal(err)}
 var data struct { Cases []struct { Name string `json:"separator_codepoint"`; Expression string `json:"expression"`; Accepted bool `json:"accepted"` } `json:"cases"` }
 if json.Unmarshal(raw,&data)!=nil || len(data.Cases)!=6 {t.Fatal("source six-case fixture")}
 for _,sample:=range data.Cases {t.Run(sample.Name,func(t *testing.T){
  cron,err:=ParseCrontab(sample.Expression,"UTC")
  if (err==nil)!=sample.Accepted {t.Fatalf("installed accepted=%v, target err=%v",sample.Accepted,err)}
  if err==nil { got:=cron.First(time.Date(2026,1,1,0,0,0,0,time.UTC)); if !got.Equal(time.Date(2026,1,1,0,0,0,0,time.UTC)) {t.Fatal(got)} }
 })}
}
