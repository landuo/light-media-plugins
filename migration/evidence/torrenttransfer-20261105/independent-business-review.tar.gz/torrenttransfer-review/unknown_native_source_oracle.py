#!/usr/bin/env python3
"""Installed add/helper/wrapper AST with dropped replies at an owned HTTP peer."""
from __future__ import annotations
import ast
import copy
import hashlib
import http.server
import json
import socket
import threading
from pathlib import Path
from types import SimpleNamespace as NS
import requests
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
setup_path=HERE/'metadata_runtime_add_oracle.py'
setup_ast=ast.parse(setup_path.read_text());body=[]
for node in setup_ast.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='peer_status' for t in node.targets):break
    body.append(node)
scope={'__file__':str(setup_path)}
exec(compile(ast.Module(body=body,type_ignores=[]),str(setup_path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
env=scope['env'];events=scope['events'];method=scope['method'];make_class=scope['make_class'];QB=scope['QB'];TT=scope['TT'];VENDOR=scope['VENDOR'];Vendor=scope['Vendor'];Plugin=scope['Plugin']
TR=ROOT/'host-reference/app/modules/transmission/transmission.py'
env['time']=NS(sleep=lambda seconds:events.append({'event':'source.tag_lookup.sleep','seconds':seconds}))
env['StringUtils']=NS(generate_random_str=lambda _:"OWNEDTAG10")
Qb=make_class('Qbittorrent',[method(QB,name) for name in ('add_torrent','__parse_add_torrent_response','get_torrent_id_by_tag','__get_last_add_torrentid_by_tag','get_torrents','delete_torrents_tag','recheck_torrents','start_torrents','delete_torrents')],env)
Tr=make_class('Transmission',[method(TR,name) for name in ('add_torrent','start_torrents','delete_torrents')],env)
mode='drop-each';attempts=0
class Peer(http.server.BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def do_POST(self):
        global attempts
        self.rfile.read(int(self.headers['Content-Length']));attempts+=1
        events.append({'event':'peer.received.add.POST','attempt':attempts,'effect_may_have_applied':True})
        if mode=='drop-each' or attempts==1:
            self.close_connection=True
            try:self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:pass
            self.connection.close();return
        data=b'owned duplicate';self.send_response(409);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Peer);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
rows=[]
try:
 for label,metadata,found,peerMode in [('QB-unknown-found','qbittorrent',True,'drop-each'),('QB-unknown-absent','qbittorrent',False,'drop-each'),('QB-first-drop-second-409-found','qbittorrent',True,'drop-then409'),('TR-metadata-QB-runtime-unknown','transmission',False,'drop-each')]:
    events.clear();attempts=0;mode=peerMode
    session=requests.Session();session.trust_env=False
    vendor=Vendor();vendor.app_web_api_version=lambda:'2.11.0';vendor._REQUESTS_ARGS={};vendor._session=session;vendor._api_key=''
    vendor._url=NS(build=lambda *_:'http://127.0.0.1:'+str(server.server_port)+'/api/v2/torrents/add')
    vendor._is_endpoint_supported_for_version=lambda **_:True;vendor._initialize_context=lambda:events.append({'event':'vendor.retry.context.reset'});vendor._verbose_logging=lambda *_:None
    def query(**kwargs):
        events.append({'event':'native.tag.query','kwargs':kwargs})
        return [{'hash':'a'*40,'tags':'OWNEDTAG10'}] if found else []
    vendor.torrents_info=query
    vendor.torrents_remove_tags=lambda **kwargs:events.append({'event':'native.cleanup.task-tag','kwargs':kwargs})
    vendor.torrents_delete_tags=lambda **kwargs:events.append({'event':'native.cleanup.global-tag','kwargs':kwargs})
    wrapper=Qb();wrapper.qbc=vendor;wrapper._category=False;wrapper._sequentail=False;wrapper._first_last_piece=False
    add=wrapper.add_torrent
    def capture(**kwargs):
        result=add(**kwargs);events.append({'event':'source.wrapper.add.return','value':list(result),'truthy':bool(result)});return result
    wrapper.add_torrent=capture
    plugin=Plugin();plugin._fromdownloader='Source';plugin._torrent_tags=['owned'];plugin._remainoldtag=False;plugin._remainoldcat=False;plugin._skipverify=False;plugin.service_info=lambda _:NS(type='qbittorrent',name='Source')
    try:outcome={'returned':plugin._TorrentTransfer__download(NS(name='Dest',type=metadata,instance=wrapper),b'd4:infod6:lengthi1e4:name5:ownedee','/owned/payload',{})}
    except Exception as e:outcome={'raised':type(e).__name__,'message':str(e)}
    session.close()
    rows.append({'case':label,'metadata_kind':metadata,'runtime_kind':'qbittorrent','outcome':outcome,'network_add_POSTs':attempts,'tag_queries':sum(x['event']=='native.tag.query' for x in events),'trace':list(events)})
 # The installed TR wrapper catches its native unknown error and returns None.
 events.clear()
 def tr_add(**kwargs):events.append({'event':'synthetic.TR.native.add','kwargs':sorted(kwargs)});raise ConnectionError('owned response lost after native mutation')
 wrapper=Tr();wrapper.trc=NS(add_torrent=tr_add)
 plugin=Plugin();plugin._fromdownloader='Source';plugin._torrent_tags=[];plugin._remainoldtag=False;plugin.service_info=lambda _:NS(type='qbittorrent',name='Source')
 outcome=plugin._TorrentTransfer__download(NS(name='Dest',type='transmission',instance=wrapper),b'owned','/owned/payload',{})
 rows.append({'case':'TR-native-unknown','outcome':{'returned':outcome},'classification':'actual TR wrapper/TT method AST; native client error is synthetic, no TR vendor/network claim','trace':list(events)})
finally:server.shutdown();server.server_close();thread.join()
paths=[TT,QB,TR,VENDOR/'torrents.py',VENDOR/'request.py',VENDOR/'exceptions.py']
result={'kind':'actual installed TT __download + QB wrapper/vendor request pipeline + exact tag helper AST with dropped HTTP replies at owned loopback peer','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'classification':['Actual source add pipeline invokes local Requests Session/owned HTTP peer; no real downloader or original application import/config','Tag query and cleanup native calls use synthetic client methods; exact installed helper controls nine attempts and both cleanup calls','Original vendor retries a dropped add response: observed two POSTs. Source SDK no-write-retry contract is a separate platform boundary; this source trace does not authorize target retries','FailureCode/scope/cancellation are platform facts outside original Python wrappers; ordinary source exceptions become tupleFalse/None/False','Local Python3.14 interpreter, captured source runtime3.12.13; serialization-critical installed Requests files were independently byte-matched'],'cases':rows}
HERE.joinpath('unknown-native-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':[{k:v for k,v in r.items() if k!='trace'} for r in rows]},indent=2))
