#!/usr/bin/env python3
"""Actual QB metadata → TR runtime method-signature failure before mutation."""
from __future__ import annotations
import ast,copy,hashlib,json
from pathlib import Path
from types import SimpleNamespace as NS
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
TT=ROOT/'source-snapshot/torrenttransfer/__init__.py';TR=ROOT/'host-reference/app/modules/transmission/transmission.py'
trace=[]
def method(path,name):return copy.deepcopy(next(n for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.FunctionDef) and n.name==name))
env={'DownloaderHelper':lambda:NS(is_downloader=lambda kind,service:service.type==kind),'StringUtils':NS(generate_random_str=lambda n:trace.append({'op':'random_marker','length':n}) or 'OWNEDTAG10')}
for path,name,methods in [(TR,'Transmission',['add_torrent']),(TT,'TorrentTransfer',['__download'])]:
 node=ast.ClassDef(name=name,bases=[],keywords=[],body=[method(path,n) for n in methods],decorator_list=[])
 exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),env)
rows=[]
for skip in [None,False,'false',[]]:
 trace.clear();native=env['Transmission']();native.trc=NS(add_torrent=lambda **kwargs:trace.append({'op':'native.TR.add'}))
 obj=env['TorrentTransfer']();obj.service_info=lambda _:NS(type='qbittorrent');obj._fromdownloader='Source';obj._remainoldcat=False;obj._remainoldtag=False;obj._torrent_tags=['owned'];obj._skipverify=skip
 try:result={'returned':obj._TorrentTransfer__download(NS(type='qbittorrent',instance=native),b'owned','/owned/payload',{})}
 except Exception as error:result={'raised':type(error).__name__,'message':str(error)}
 rows.append({'skipverify':skip,'outcome':result,'native_add_calls':sum(r['op']=='native.TR.add' for r in trace),'trace':list(trace)})
result={'kind':'exact installed TT __download and TR add_torrent method AST; synthetic marker/native client, no network','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [TT,TR]},'cases':rows}
HERE.joinpath('reverse-metadata-signature-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
