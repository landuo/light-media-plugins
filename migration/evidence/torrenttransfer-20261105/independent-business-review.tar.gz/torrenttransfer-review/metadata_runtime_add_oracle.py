#!/usr/bin/env python3
"""Actual TT/QB/vendor method AST to an owned loopback HTTP peer.

Metadata kind=Transmission and runtime instance=Qbittorrent is source-derived
from duplicate names. No application imports, old settings, live daemon or auth.
"""
from __future__ import annotations
import ast
import copy
import email.policy
import hashlib
import http.server
import json
import os
import threading
from collections.abc import Iterable, Mapping
from email.parser import BytesParser
from pathlib import Path
from types import SimpleNamespace as NS
import requests
from packaging.version import Version

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
VENDOR=ROOT/'qbittorrent-vendor'
QB=ROOT/'host-reference/app/modules/qbittorrent/qbittorrent.py'
TT=ROOT/'source-snapshot/torrenttransfer/__init__.py'
events=[]
class Quiet:
    def error(self,message,*_):events.append({'event':'wrapper.log.error','message':str(message)})
    def __getattr__(self,_):return lambda *a,**k:None
def method(path,name):return copy.deepcopy(next(n for n in ast.walk(ast.parse(path.read_text())) if isinstance(n,ast.FunctionDef) and n.name==name))
def make_class(name,methods,scope):
    node=ast.ClassDef(name=name,bases=[],keywords=[],body=methods,decorator_list=[])
    exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(VENDOR),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
    return scope[name]
env=dict(globals(),v=Version,Response=requests.Response,APINames=NS(Torrents='torrents',Authorization='auth'),logger=Quiet(),JSONDecodeError=json.JSONDecodeError,TorrentsAddedMetadata=lambda value:value,path=os.path,os_strerror=os.strerror,requests_exceptions=requests.exceptions,RequestException=requests.exceptions.RequestException,RequestsHTTPError=requests.exceptions.HTTPError,sleep=lambda seconds:events.append({'event':'vendor.retry.sleep','seconds':seconds}))
exceptions=ast.parse((VENDOR/'exceptions.py').read_text())
exceptions.body=[n for n in exceptions.body if not isinstance(n,(ast.Import,ast.ImportFrom))]
exec(compile(exceptions,str(VENDOR/'exceptions.py'),'exec',flags=__import__('__future__').annotations.compiler_flag),env)
methods=[method(VENDOR/'request.py',name) for name in ('_list2string','_post','_auth_request','_request_manager','_request','_format_payload','_cast','_handle_error_responses')]
methods.extend(method(VENDOR/'torrents.py',name) for name in ('_normalize_torrent_files','torrents_add'))
Vendor=make_class('Vendor',methods,env)
Wrapper=make_class('Qbittorrent',[method(QB,'add_torrent'),method(QB,'__parse_add_torrent_response')],env)
env['DownloaderHelper']=lambda:NS(is_downloader=lambda kind,service:service.type==kind)
Plugin=make_class('TorrentTransfer',[method(TT,'__download')],env)
peer_status=200;peer_body=b'Ok.'
class Peer(http.server.BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def do_POST(self):
        body=self.rfile.read(int(self.headers['Content-Length']))
        raw=('Content-Type: '+self.headers['Content-Type']+'\r\nMIME-Version: 1.0\r\n\r\n').encode()+body
        message=BytesParser(policy=email.policy.default).parsebytes(raw)
        fields=[]
        for part in message.iter_parts():
            name=part.get_param('name',header='content-disposition')
            if part.get_filename() is None:fields.append({'name':name,'value':part.get_payload(decode=True).decode('utf-8')})
        events.append({'event':'peer.received.POST','path':self.path,'non_file_fields':fields,'torrent_file_parts':sum(p.get_filename() is not None for p in message.iter_parts())})
        self.send_response(peer_status);self.send_header('Content-Length',str(len(peer_body)));self.end_headers();self.wfile.write(peer_body)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Peer)
thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
rows=[]
try:
  for labels,status,body in [(list('abcd')[:n],200,b'Ok.') for n in range(5)]+[(['a','b'],200,b'Fails.'),(['a','b'],409,b'owned conflict'),(['\ud800'],200,b'Ok.')]:
    events=[];peer_status=status;peer_body=body
    session=requests.Session();session.trust_env=False
    original_request=session.request
    def request(*args,**kwargs):
        events.append({'event':'Requests.Session.request.enter','method':kwargs.get('method')})
        return original_request(*args,**kwargs)
    session.request=request
    vendor=Vendor();vendor.app_web_api_version=lambda:'2.11.0';vendor._REQUESTS_ARGS={};vendor._session=session
    vendor._url=NS(build=lambda *_:'http://127.0.0.1:'+str(server.server_port)+'/api/v2/torrents/add')
    vendor._is_endpoint_supported_for_version=lambda **_:True
    vendor._initialize_context=lambda:events.append({'event':'vendor.context.reset'})
    vendor._verbose_logging=lambda *_:None
    wrapper=Wrapper();wrapper.qbc=vendor;wrapper._category=False;wrapper._sequentail=False;wrapper._first_last_piece=False
    original=wrapper.add_torrent
    def add(**kwargs):
        events.append({'event':'wrapper.add.enter','kwargs':sorted(kwargs),'labels':kwargs.get('labels')})
        result=original(**kwargs)
        events.append({'event':'wrapper.add.return','value':list(result),'truthy':bool(result)})
        return result
    wrapper.add_torrent=add
    plugin=Plugin();plugin._fromdownloader='Source';plugin._torrent_tags=labels;plugin._remainoldtag=False
    plugin.service_info=lambda _:NS(type='qbittorrent',name='Source')
    service=NS(type='transmission',name='Mixed',instance=wrapper)
    events.append({'event':'plugin.download.enter','metadata_kind':service.type,'runtime_class':type(wrapper).__name__})
    try:
        value=plugin._TorrentTransfer__download(service,b'd4:infod6:lengthi1e4:name5:ownedee','/owned/payload',{})
        outcome={'returned':value}
    except Exception as e:
        outcome={'raised':type(e).__name__,'message':str(e)}
        events.append({'event':'plugin.download.raise',**outcome})
    session.close()
    rows.append({'labels':labels,'peer_response':{'status':status,'body':body.decode()},'outcome':outcome,'network_POSTs_to_owned_peer':sum(e['event']=='peer.received.POST' for e in events),'trace':events})
finally:
    server.shutdown();server.server_close();thread.join()
paths=[TT,QB,VENDOR/'request.py',VENDOR/'torrents.py',VENDOR/'exceptions.py',ROOT/'python-runtime-reference/requests/models.py']
result={'kind':'actual installed plugin __download + QB add wrapper + vendor request pipeline AST; actual Requests Session to owned loopback peer','scope':'Synthetic configured labels/content/paths/HTTP responses. No live daemon, production module import, config or credentials. Peer acceptance is not daemon acceptance.','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'interpreter':'local Python3.14, original installed source Python3.12.13','cases':rows}
HERE.joinpath('metadata-runtime-add-oracle.json').write_text(json.dumps(result,ensure_ascii=True,indent=2)+'\n')
print(json.dumps({'cases':[{'labels':r['labels'],'posts':r['network_POSTs_to_owned_peer'],'outcome':r['outcome']} for r in rows]},ensure_ascii=True,indent=2))
