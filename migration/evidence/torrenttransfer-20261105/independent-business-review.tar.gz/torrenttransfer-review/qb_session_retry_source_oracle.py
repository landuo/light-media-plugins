#!/usr/bin/env python3
"""Exact installed Session/adapter/request-manager AST; owned read endpoints."""
from __future__ import annotations
import ast,copy,hashlib,http.server,json,socket,threading,time,typing
from pathlib import Path
from types import SimpleNamespace as NS
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry as RealRetry
import urllib3.util.connection as urllib_connection
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
base=HERE/'metadata_runtime_add_oracle.py';nodes=[]
for n in ast.parse(base.read_text()).body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='peer_status' for t in n.targets):break
    nodes.append(n)
scope={'__file__':str(base)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(base),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
env=scope['env'];events=scope['events'];method=scope['method'];make_class=scope['make_class'];VENDOR=scope['VENDOR'];QB=scope['QB']
APP=ROOT/'constructor-vendor-reference/qbittorrentapi/app.py'
class SourceList(list):
    def __init__(self,values,client=None):super().__init__(values)
class ObservedRetry(RealRetry):
    def sleep(self,response=None):
        events.append({'event':'adapter.retry.sleep','backoff_seconds':self.get_backoff_time(),'retry_after_seconds':self.get_retry_after(response) if response is not None else None})
        return super().sleep(response)
env.update(cast=typing.cast,ResponseT=typing.TypeVar('ResponseT'),Dictionary=dict,List=SourceList,TorrentInfoList=SourceList,Session=requests.Session,HTTPAdapter=HTTPAdapter,Retry=ObservedRetry,APINames=NS(Torrents='torrents',Application='app',Authorization='auth'))
session_node=copy.deepcopy(next(n for n in ast.parse((VENDOR/'request.py').read_text()).body if isinstance(n,ast.ClassDef) and n.name=='QbittorrentSession'))
exec(compile(ast.Module(body=[session_node],type_ignores=[]),str(VENDOR/'request.py'),'exec',flags=__import__('__future__').annotations.compiler_flag),env)
sessions=[]
def isolated_init(self):requests.Session.__init__(self);self.trust_env=False;sessions.append(self)
env['QbittorrentSession'].__init__=isolated_init
class OwnedURL:
    def __init__(self,client):self.client=client
    def build(self,namespace,method,*_):return self.client.host+'/api/v2/'+namespace+'/'+method
env['QbittorrentURL']=OwnedURL
def manager_sleep(seconds):events.append({'event':'manager.sleep','seconds':seconds});time.sleep(seconds)
env['sleep']=manager_sleep
names=['_list2string','_get_cast','_post_cast','_auth_request','_request_manager','_request','_format_payload','_cast','_handle_error_responses','_session','_initialize_context','_trigger_session_initialization']
methods=[method(VENDOR/'request.py',name) for name in names]
methods.extend([method(VENDOR/'auth.py','auth_log_in'),method(VENDOR/'torrents.py','torrents_info'),method(APP,'app_version')])
Vendor=make_class('Vendor',methods,env);Wrapper=make_class('Qbittorrent',[method(QB,'get_torrents')],env)
sequence=[];seen=0;retry_after=None
class Peer(http.server.BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def serve(self,post):
        global seen
        if post:self.rfile.read(int(self.headers.get('Content-Length','0')))
        seen+=1;status=sequence[min(seen-1,len(sequence)-1)]
        events.append({'event':'peer.request','method':'POST' if post else 'GET','path':self.path,'attempt':seen,'response':status})
        if status=='DROP':
            self.close_connection=True
            try:self.connection.shutdown(socket.SHUT_RDWR)
            except OSError:pass
            self.connection.close();return
        body=(json.dumps([{'hash':'a'*40,'tags':'owned'}]).encode() if post else b'v5.2.0') if status<400 else b'owned failure'
        self.send_response(status)
        if retry_after is not None:self.send_header('Retry-After',str(retry_after))
        self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def do_GET(self):self.serve(False)
    def do_POST(self):self.serve(True)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Peer);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
closed=socket.socket();closed.bind(('127.0.0.1',0)) # Reserved, not listening.
real_connect=urllib_connection.create_connection
connects=0
def observed_connect(*args,**kwargs):
    global connects
    connects+=1;events.append({'event':'tcp.connect','attempt':connects})
    return real_connect(*args,**kwargs)
urllib_connection.create_connection=observed_connect
rows=[]
try:
 for verb in ['POST-info','GET-app-version']:
  for label,replies,header in [('500-then200',[500,200],None),('two500-then200',[500,500,200],None),('three500-then200',[500,500,500,200],None),('all500',[500],None),('all503-no-header',[503],None),('drop-then200',['DROP',200],None),('all-drop',['DROP'],None),('all500-retry-after1',[500],1),('connect-refused',[],None)]:
    events.clear();seen=0;connects=0;sequence=replies;retry_after=header
    vendor=Vendor();vendor.host='http://127.0.0.1:'+str(closed.getsockname()[1] if label=='connect-refused' else server.server_port)
    vendor._http_session=None;vendor._EXTRA_HEADERS={};vendor._api_key='';vendor._VERIFY_WEBUI_CERTIFICATE=True;vendor._HTTPADAPTER_ARGS={};vendor._REQUESTS_ARGS={'timeout':(1,1)};vendor._SIMPLE_RESPONSES=False;vendor._RAISE_UNSUPPORTEDVERSIONERROR=False;vendor.username='OWNED_USER';vendor._password='OWNED_PASSWORD'
    vendor._is_endpoint_supported_for_version=lambda **_:True;vendor._verbose_logging=lambda *_:None
    vendor._initialize_context()
    original_reset=vendor._initialize_context
    def reset():events.append({'event':'manager.context.reset'});original_reset()
    vendor._initialize_context=reset
    started=time.monotonic()
    if verb=='POST-info':
        wrapper=Wrapper();wrapper.qbc=vendor;tasks,error=wrapper.get_torrents(ids=['a'*40]);outcome={'task_count':len(tasks),'error_flag':error}
    else:
        try:outcome={'returned':vendor.app_version()}
        except Exception as error:outcome={'raises':type(error).__name__}
    elapsed=time.monotonic()-started
    retries=vendor._session.adapters['http://'].max_retries
    rows.append({'method':verb,'case':label,'reply_sequence':replies,'retry_after':header,'outcome':outcome,'peer_requests':seen,'tcp_connect_attempts':connects,'elapsed_seconds':round(elapsed,4),'adapter_defaults':{'total':retries.total,'connect':retries.connect,'read':retries.read,'allowed_methods':sorted(retries.allowed_methods),'status_forcelist':sorted(retries.status_forcelist),'backoff_factor':retries.backoff_factor,'raise_on_status':retries.raise_on_status},'trace':list(events)})
finally:
 urllib_connection.create_connection=real_connect
 for session in sessions:session.close()
 closed.close();server.shutdown();server.server_close();thread.join()
library=[]
import requests.adapters,urllib3.util.retry,urllib3.connectionpool
for module,relative in [(requests.adapters,'requests/adapters.py'),(urllib3.util.retry,'urllib3/util/retry.py'),(urllib3.connectionpool,'urllib3/connectionpool.py')]:
 local=Path(module.__file__).read_bytes();captured=ROOT/'python-runtime-reference'/relative
 library.append({'module':module.__name__,'local_sha256':hashlib.sha256(local).hexdigest(),'actual_sha256':hashlib.sha256(captured.read_bytes()).hexdigest() if captured.exists() else None,'same_bytes':local==captured.read_bytes() if captured.exists() else None})
paths=[QB,VENDOR/'request.py',VENDOR/'auth.py',VENDOR/'torrents.py',APP]
result={'kind':'actual installed QbittorrentSession and Request._session/_request_manager plus wrapper/vendor AST with real HTTPAdapter/Retry to owned read endpoints','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'library_comparison':library,'limitations':['Owned URL builder replaces scheme-detection/HEAD behavior; no claim about original URL autodetection. Proxy environment disabled only in isolated test Session init','Retry.sleep instrumentation delegates to real Retry.sleep, including actual Retry-After1 waits. Manager sleep also delegates to real time.sleep','Read operations only, including POST torrents/info. No selected torrent mutation replay is tested or authorized','Inert valid list model and controlled network peers; no live daemon/application/config or real credentials','Local interpreter3.14; actual installed source interpreter3.12.13; adapter dependency byte comparison recorded explicitly'],'cases':rows}
HERE.joinpath('qb-session-retry-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'library':library,'cases':[{k:v for k,v in row.items() if k not in ['trace','adapter_defaults']} for row in rows]},indent=2))
