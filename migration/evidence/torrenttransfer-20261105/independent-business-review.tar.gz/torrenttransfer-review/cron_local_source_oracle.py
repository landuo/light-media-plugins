#!/usr/bin/env python3
"""Actual captured APScheduler classes with synthetic TZif/default-zone inputs.

No source package import, live config, sockets or old application execution.
Inner imports resolve only the temporary in-process AST module namespaces.
"""
from __future__ import annotations
import abc
import ast
import calendar
import copy
import datetime as dt
import hashlib
import json
import os
import random
import re
import shutil
import sys
import tempfile
import types
import zoneinfo
from pathlib import Path
from types import SimpleNamespace as NS

HERE=Path(__file__).resolve().parent
REF=HERE.parent/'python-timezone-reference'
INPUTS=[REF/'apscheduler/util.py',REF/'apscheduler/triggers/base.py',REF/'apscheduler/triggers/cron/expressions.py',REF/'apscheduler/triggers/cron/fields.py',REF/'apscheduler/triggers/cron/__init__.py',REF/'tzlocal/utils.py',REF/'tzlocal/unix.py']
fixture=HERE/'fixtures/new-york.tzif';fixture.parent.mkdir(exist_ok=True)
shutil.copyfile('/usr/share/zoneinfo/America/New_York',fixture)
common=dict(datetime=dt.datetime,date=dt.date,time=dt.time,timedelta=dt.timedelta,timezone=dt.timezone,tzinfo=dt.tzinfo,UTC=dt.timezone.utc,ZoneInfo=zoneinfo.ZoneInfo,zoneinfo=zoneinfo,re=re,monthrange=calendar.monthrange,random=random,ABCMeta=abc.ABCMeta,abstractmethod=abc.abstractmethod,os=os)
saved={}
def module(name):
    saved.setdefault(name,sys.modules.get(name))
    m=types.ModuleType(name);m.__dict__.update(common);sys.modules[name]=m
    return m
def execute(path,namespace,selected=None):
    tree=ast.parse(path.read_text())
    nodes=[]
    for n in tree.body:
        if isinstance(n,(ast.Import,ast.ImportFrom)):continue
        if selected is not None:
            names={n.name} if isinstance(n,(ast.FunctionDef,ast.ClassDef)) else {x.id for x in n.targets if isinstance(x,ast.Name)} if isinstance(n,ast.Assign) else set()
            if not names.intersection(selected):continue
        nodes.append(copy.deepcopy(n))
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec',flags=__import__('__future__').annotations.compiler_flag),namespace)
old_tz=os.environ.get('TZ');had_tz='TZ' in os.environ
try:
    for name in ['apscheduler','apscheduler.triggers','apscheduler.triggers.cron']:
        m=module(name);m.__path__=[]
    util=module('apscheduler.util')
    execute(INPUTS[0],util.__dict__,{'asint','astimezone','convert_to_datetime','datetime_ceil','datetime_repr','datetime_utc_add','_DATE_REGEX','localize','normalize'})
    base=module('apscheduler.triggers.base');execute(INPUTS[1],base.__dict__)
    expr=module('apscheduler.triggers.cron.expressions');expr.asint=util.asint;execute(INPUTS[2],expr.__dict__)
    fields=module('apscheduler.triggers.cron.fields');fields.__dict__.update(expr.__dict__);execute(INPUTS[3],fields.__dict__)
    cron=sys.modules['apscheduler.triggers.cron'];cron.__dict__.update(fields.__dict__);cron.__dict__.update(util.__dict__);cron.BaseTrigger=base.BaseTrigger
    tzscope=dict(common,windows_tz=NS(tz_win={name:name for name in ('UTC','Etc/UTC','America/New_York')}))
    execute(INPUTS[5],tzscope,{'_tz_name_from_env','_tz_from_env'})
    class Log:
        def debug(self,*_):pass
        def warning(self,*_):pass
    tzscope.update(utils=NS(_tz_name_from_env=tzscope['_tz_name_from_env'],_tz_from_env=tzscope['_tz_from_env']),log=Log())
    execute(INPUTS[6],tzscope,{'_get_localzone_name','_get_unique_tzs','_get_localzone'})
    execute(INPUTS[4],cron.__dict__)
    rows=[]
    with tempfile.TemporaryDirectory(prefix='source-local-cron-',dir=HERE) as tmp:
        root=Path(tmp);(root/'etc').mkdir();shutil.copyfile(fixture,root/'etc/localtime')
        explicit=root/'owned-dst-zone';shutil.copyfile(fixture,explicit)
        for branch in ['explicit-TZ-file','anonymous-localtime-file']:
            if branch=='explicit-TZ-file':os.environ['TZ']=str(explicit)
            else:os.environ.pop('TZ',None)
            cron.get_localzone=lambda:tzscope['_get_localzone'](str(root))
            for label,expression,start in [('NY-gap','30 2 * * *','2026-03-08T05:00:00+00:00'),('NY-fold','30 1 * * *','2026-11-01T04:00:00+00:00')]:
                trigger=cron.CronTrigger.from_crontab(expression)
                now=dt.datetime.fromisoformat(start);previous=None;fires=[]
                for _ in range(3):
                    fire=trigger.get_next_fire_time(previous,now)
                    fires.append({'wall':fire.isoformat(),'utc':fire.astimezone(dt.timezone.utc).isoformat().replace('+00:00','Z'),'fold':fire.fold,'offset_seconds':int(fire.utcoffset().total_seconds())})
                    previous=fire;now=fire.astimezone(dt.timezone.utc)
                rows.append({'branch':branch,'case':label,'cron':expression,'start':start,'zone_key':getattr(trigger.timezone,'key',str(trigger.timezone)),'fires':fires})
    result={'kind':'actual installed APScheduler3.11.3 CronTrigger/base/field/expression + tzlocal5.4.4 AST with owned copies of local-system New_York TZif','source_sha256':{str(p.relative_to(REF)):hashlib.sha256(p.read_bytes()).hexdigest() for p in INPUTS},'fixture':{'path':str(fixture.relative_to(HERE)),'sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'copied_from':'local system /usr/share/zoneinfo/America/New_York','bytes':fixture.stat().st_size},'limitations':['Python interpreter is local 3.14; original installed source runtime is 3.12.13','TZif is local system copied data, not installed host tzdata','Pure source-class execution with standard datetime/zoneinfo, no application import, live config, network or scheduling execution'],'cases':rows}
    HERE.joinpath('cron-local-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
finally:
    if had_tz:os.environ['TZ']=old_tz
    else:os.environ.pop('TZ',None)
    for name,old in saved.items():
        if old is None:sys.modules.pop(name,None)
        else:sys.modules[name]=old
