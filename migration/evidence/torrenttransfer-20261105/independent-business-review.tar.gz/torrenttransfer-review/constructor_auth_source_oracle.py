#!/usr/bin/env python3
"""Captured source auth/constructor methods against an owned HTTP peer.

No original application/package imports, production credentials or preference
writes. QB Request options are injected, and TR model/exception/constants
dependencies are finite doubles explicitly identified in the output.
"""
from __future__ import annotations
import ast
import copy
import hashlib
import http.server
import json
import logging
import string
import threading
import time
import traceback
import typing
from pathlib import Path
from types import SimpleNamespace as NS
from urllib.parse import quote
import requests
HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
setup_path=HERE/'metadata_runtime_add_oracle.py';tree=ast.parse(setup_path.read_text());nodes=[]
for n in tree.body:
    if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='peer_status' for t in n.targets):break
    nodes.append(n)
scope={'__file__':str(setup_path)};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(setup_path),'exec',flags=__import__('__future__').annotations.compiler_flag),scope)
env=scope['env'];events=scope['events'];method=scope['method'];make_class=scope['make_class'];QB=scope['QB'];VENDOR=scope['VENDOR']
REF=ROOT/'constructor-vendor-reference';APP=REF/'qbittorrentapi/app.py';TR=ROOT/'host-reference/app/modules/transmission/transmission.py';TRC=REF/'transmission_rpc/client.py';TRU=REF/'transmission_rpc/utils.py'
env.update(cast=typing.cast,ResponseT=typing.TypeVar('ResponseT'),traceback=traceback,APINames=NS(Application='app',Authorization='auth',Torrents='torrents'))
qbmethods=[method(VENDOR/'request.py',name) for name in ('_get_cast','_post_cast','_auth_request','_request_manager','_request','_format_payload','_cast','_handle_error_responses')]
qbmethods.extend(method(APP,name) for name in ('app_version',))
qbmethods.append(method(VENDOR/'auth.py','auth_log_in'))
QbVendor=make_class('QbVendor',qbmethods,env)
QbWrapper=make_class('Qbittorrent',[method(QB,name) for name in ('__login_qbittorrent','__use_api_key_auth','__sync_incomplete_file_suffix','is_inactive')],env)
scenario={};rpc_seen=0
class Peer(http.server.BaseHTTPRequestHandler):
    def log_message(self,*_):pass
    def reply(self,status,body,headers=None):
        self.send_response(status)
        for k,v in (headers or {}).items():self.send_header(k,v)
        self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    def do_GET(self):
        events.append({'event':'peer.GET','path':self.path,'authorization_present':bool(self.headers.get('Authorization'))})
        self.reply(scenario['status'],scenario['body'].encode())
    def do_POST(self):
        global rpc_seen
        raw=self.rfile.read(int(self.headers['Content-Length']))
        if self.path=='/api/v2/auth/login':
            events.append({'event':'peer.POST.login','form_keys':sorted(kv.split('=',1)[0] for kv in raw.decode().split('&')),'authorization_present':bool(self.headers.get('Authorization'))})
            headers={'Set-Cookie':'SID=OWNED_SYNTHETIC; Path=/'} if scenario.get('sid') else {}
            self.reply(scenario.get('login_status',scenario['status']),scenario.get('login_body',scenario['body']).encode(),headers);return
        query=json.loads(raw);rpc_seen+=1;events.append({'event':'peer.POST.rpc','query':query,'session_header':self.headers.get('X-Transmission-Session-Id')})
        if scenario.get('conflict') and rpc_seen==1:self.reply(409,b'',{'X-Transmission-Session-Id':'OWNED_SYNTHETIC'});return
        response=scenario['body'];self.reply(scenario['status'],response.encode())
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),Peer);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
sessions=[];qbrows=[];trrows=[]
try:
 for name,apiKey,status,body,sid in [('login-empty-noSID',False,200,'',False),('login-Ok-noSID',False,200,'Ok.',False),('login-Ok-SID',False,200,'Ok.',True),('login-Fails-SID',False,200,'Fails.',True),('login-401',False,401,'',False),('login-403',False,403,'denied',False),('login-Ok-newline',False,200,'Ok.\n',False),('login-space',False,200,' ',False),('login-204-empty',False,204,'',False),('key-app-version',True,200,'v5.2.0',False),('key-empty-version',True,200,'',False),('key-Fails-text-status200',True,200,'Fails.',False),('key-204-empty',True,204,'',False),('key-401',True,401,'denied',False)]:
    events.clear();scenario=dict(status=status,body=body,sid=sid)
    def factory(**kwargs):
        session=requests.Session();session.trust_env=False;session.headers.update(kwargs.get('EXTRA_HEADERS') or {});sessions.append(session)
        vendor=QbVendor();vendor._session=session;vendor.username='OWNED_USER';vendor._password='OWNED_PASSWORD';vendor._api_key='';vendor._REQUESTS_ARGS={};vendor._RAISE_UNSUPPORTEDVERSIONERROR=False
        vendor._url=NS(build=lambda namespace,method,*_:'http://127.0.0.1:'+str(server.server_port)+'/api/v2/'+namespace+'/'+method)
        vendor._initialize_context=lambda:events.append({'event':'source.vendor.initialize_context'})
        vendor._is_endpoint_supported_for_version=lambda **_:True;vendor._verbose_logging=lambda *_:None
        vendor.app_preferences=lambda:(_ for _ in ()).throw(ConnectionError('owned preferences read rejected'))
        return vendor
    env['qbittorrentapi']=NS(Client=factory)
    wrapper=QbWrapper();wrapper._host='127.0.0.1';wrapper._port=server.server_port;wrapper._username='OWNED_USER';wrapper._password='OWNED_PASSWORD';wrapper._apikey='OWNED_SYNTHETIC_KEY' if apiKey else '';wrapper._incomplete_files_ext=True
    client=wrapper._Qbittorrent__login_qbittorrent();wrapper.qbc=client
    qbrows.append({'case':name,'api_key':apiKey,'status':status,'body':body,'set_sid':sid,'client_present':client is not None,'inactive':wrapper.is_inactive(),'trace':list(events)})
 # Actual TR Client.__init__, HTTP and response/version methods. The fields
 # model is inert; constructor does not inspect the returned Session object.
 class RpcMethod:
    SessionGet='session-get';TorrentGet='torrent-get';TorrentAdd='torrent-add';SessionStats='session-stats';PortTest='port-test';BlocklistUpdate='blocklist-update';FreeSpace='free-space';TorrentRenamePath='torrent-rename-path'
 class TrError(Exception):
    def __init__(self,*a,**kw):super().__init__(*a)
 log=logging.Logger('owned-source-tr');log.disabled=True
 trenv=dict(requests=requests,quote=quote,json=json,time=time,logging=logging,LOGGER=log,DEFAULT_TIMEOUT=30,_header_session_id='x-transmission-session-id',_hex_chars=frozenset(string.hexdigits.lower()),RpcMethod=RpcMethod,TransmissionError=TrError,TransmissionTimeoutError=TrError,TransmissionConnectError=TrError,TransmissionAuthError=TrError,Session=lambda **kwargs:NS(**kwargs),constants=NS(TORRENT_GET_ARGS={'owned':NS(added_version=1,removed_version=None)}))
 helpernames={'_parse_torrent_id','_parse_torrent_ids'}
 helpers=[copy.deepcopy(n) for n in ast.parse(TRC.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in helpernames]
 helpers.append(copy.deepcopy(next(n for n in ast.parse(TRU.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='get_torrent_arguments')))
 exec(compile(ast.Module(body=helpers,type_ignores=[]),str(TRC),'exec',flags=__import__('__future__').annotations.compiler_flag),trenv)
 TrClient=make_class('Client',[method(TRC,name) for name in ('__init__','get_session','_update_server_version','_http_query','_request','_http_header','timeout')],trenv)
 TrWrapper=make_class('Transmission',[method(TR,name) for name in ('__login_transmission','is_inactive')],env)
 # Required user boundary: do not perform source's daemon preference writes.
 # The constructor's own session-get remains the exact live vendor method.
 TrWrapper._Transmission__sync_incomplete_file_suffix=staticmethod(lambda *a,**k:events.append({'event':'source.preference_sync.excluded_by_user_scope'}))
 env['transmission_rpc']=NS(Client=TrClient)
 valid={'result':'success','arguments':{'version':'4.0.6','rpc-version':17}}
 cases=[('valid-no-session-header',200,valid,False),('valid-409-session',200,valid,True),('missing-version',200,{'result':'success','arguments':{'rpc-version':17}},False),('missing-rpc-version',200,{'result':'success','arguments':{'version':'4.0.6'}},False),('string-rpc-version',200,{'result':'success','arguments':{'version':'4.0.6','rpc-version':'17'}},False),('result-failure',200,{'result':'denied','arguments':{}},False),('http401',401,valid,False),('http500-valid-success-body',500,valid,False),('invalid-json',200,None,False)]
 for name,status,response,conflict in cases:
    events.clear();rpc_seen=0;scenario=dict(status=status,body='not-json' if response is None else json.dumps(response),conflict=conflict)
    wrapper=TrWrapper();wrapper._protocol='http';wrapper._host='127.0.0.1';wrapper._port=server.server_port;wrapper._username=None;wrapper._password=None;wrapper._rename_partial_files=True
    client=wrapper._Transmission__login_transmission();wrapper.trc=client
    if client is not None:client._http_session.close()
    trrows.append({'case':name,'status':status,'response':response,'client_present':client is not None,'inactive':wrapper.is_inactive(),'trace':list(events)})
finally:
 for session in sessions:session.close()
 server.shutdown();server.server_close();thread.join()
paths=[QB,TR,VENDOR/'auth.py',VENDOR/'request.py',APP,TRC,TRU]
result={'kind':'actual installed QB private login/auth/vendor request AST and TR wrapper/Client constructor/HTTP/version AST to owned loopback peer','source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'limitations':['No real daemon, credentials, original application/package import or production IO','QB general Client constructor/options/context reset are synthetic; the actual wrapper/auth/request methods and Requests transport execute. No SID requirement is added','TR RpcMethod constant strings/exception constructors/Session model are finite doubles. get_torrent_arguments uses one synthetic constants entry solely to retain numeric version comparison; no full torrent-fields completeness claim','Original daemon preference writes are excluded by explicit user scope; QB actual preference-sync helper is given a synthetic read failure, showing it does not invalidate the client','Local interpreter3.14 and Requests; original installed interpreter3.12.13, serialization-critical files independently byte-matched'],'qbittorrent':qbrows,'transmission':trrows}
HERE.joinpath('constructor-auth-source-oracle.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'qb':[{k:r[k] for k in ('case','client_present','inactive')} for r in qbrows],'tr':[{k:r[k] for k in ('case','client_present','inactive')} for r in trrows]},indent=2))
