import subprocess,os,json,sys,datetime
from pathlib import Path
root=Path(__file__).resolve().parents[3];p=Path(__file__).resolve().parent
phase=sys.argv[1];cmds={'normal':['go','test','-count=1','./tests/integration','-run','^$'],'race':['go','test','-race','-count=1','./tests/integration','-run','^$'],'vet':['go','vet','./tests/integration'],'linux':['go','test','-c','-o',str(p/'mpserverstatus-main-tests-linux-amd64'),'./tests/integration']}
env=dict(os.environ);env['GOFLAGS']='';override={'GOFLAGS':''}
if phase=='linux':override.update({'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'});env.update(override)
name='main-driver-run3-'+phase;start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (p/(name+'.log')).open('wb')as out,(p/(name+'.stderr')).open('wb')as err:r=subprocess.run(cmds[phase],cwd=root,env=env,stdout=out,stderr=err)
x={'command':cmds[phase],'env':override,'at_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':str(p/(name+'.log')),'stderr':str(p/(name+'.stderr'))};(p/(name+'-result.json')).write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x));sys.exit(r.returncode)
