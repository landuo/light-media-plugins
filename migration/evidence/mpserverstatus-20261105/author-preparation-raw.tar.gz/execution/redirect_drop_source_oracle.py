# Actual image Requests default retry path; isolated loopback only.
import http.server,threading,socket,requests,json,sys
trace=[]
class Server(http.server.ThreadingHTTPServer):daemon_threads=True
class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,*args):pass
 def do_GET(self):
  trace.append(self.path)
  if self.path=='/redirect':self.send_response(302);self.send_header('Location','/drop');self.send_header('Content-Length','0');self.end_headers();return
  if trace.count('/drop')==1:self.close_connection=True;self.connection.shutdown(socket.SHUT_RDWR);self.connection.close();return
  body=b'eventual';self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
s=Server(('127.0.0.1',0),Handler);thread=threading.Thread(target=s.serve_forever,daemon=True);thread.start()
try:
 session=requests.Session();session.trust_env=False
 try:response=session.get('http://127.0.0.1:'+str(s.server_port)+'/redirect',timeout=1);outcome={'status':response.status_code}
 except requests.exceptions.RequestException as e:outcome={'source_RequestUtils_result':None,'error_kind':type(e).__name__}
 print(json.dumps({'python':sys.version,'trace':trace,'outcome':outcome,'max_retries_total':session.get_adapter('http://').max_retries.total,'classification':'actual image333 Requests default transport, no retries after redirected reused-socket close; container loopback only, no app or credentials'},indent=2))
finally:s.shutdown();s.server_close();thread.join()
