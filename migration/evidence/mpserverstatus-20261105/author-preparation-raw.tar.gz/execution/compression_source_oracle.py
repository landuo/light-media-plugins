# Exact image dependency-only oracle. No app imports or socket operations.
import urllib3.response,io,gzip,zlib,brotli,json,sys
body=b'Active connections: 12\nserver accepts handled requests\n1000 995 12345\nReading: 2 Writing: 3 Waiting: 7\n'
g=gzip.compress(body,mtime=0);b=brotli.compress(body);z=zlib.compress(body)
inputs=[('gzip','gzip',g),('gzip-cut-header','gzip',g[:3]),('gzip-cut-trailer','gzip',g[:-4]),('gzip-garbage','gzip',g+b'garbage'),('gzip-two','gzip',g+g),('br','br',b),('br-cut','br',b[:-2]),('br-garbage','br',b+b'garbage'),('deflate-cut','deflate',z[:-2]),('br-chain','gzip,br',brotli.compress(g)),('unknown','zstd',b'opaque')]
cases=[]
for name,encoding,data in inputs:
 c={'name':name,'encoding':encoding,'input_hex':data.hex()}
 try:c['output_hex']=urllib3.response.HTTPResponse(body=io.BytesIO(data),headers={'Content-Encoding':encoding},preload_content=True).data.hex()
 except Exception as e:c['error_kind']=type(e).__name__
 cases.append(c)
print(json.dumps({'classification':'exact image333 Python3.12.13 installed urllib3 HTTPResponse body decoding, dependency-only no app/network','python':sys.version,'has_zstd':urllib3.response.HAS_ZSTD,'cases':cases},indent=2))
