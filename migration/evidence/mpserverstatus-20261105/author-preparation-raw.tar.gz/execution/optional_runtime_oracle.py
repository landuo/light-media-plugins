# Isolated image vendor imports only; no app imports or network calls.
import sys,json,hashlib,pathlib,importlib.metadata
import requests,urllib3,urllib3.response,urllib3.util.request
from requests import Request,Session
from urllib3.util.request import ACCEPT_ENCODING
out={'python':sys.version,'accept_encoding':ACCEPT_ENCODING,'has_zstd':urllib3.response.HAS_ZSTD,'has_brotli':urllib3.response.brotli is not None,'distributions':{},'files':[]}
for name in ['requests','urllib3','brotli','zstandard','backports.zstd']:
 try:out['distributions'][name]=importlib.metadata.version(name)
 except importlib.metadata.PackageNotFoundError:out['distributions'][name]=None
for mod in [requests,urllib3,urllib3.response,urllib3.util.request]:
 p=pathlib.Path(mod.__file__);out['files'].append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
# Original RequestUtils uses these overrides; prepare only, never send.
s=Session();prepared=s.prepare_request(Request('GET','https://movie-pilot.org/status',headers={'User-Agent':None,'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','Accept':None,'referer':None}))
out['prepared_headers']=dict(prepared.headers)
print(json.dumps(out,ensure_ascii=False,indent=2))
