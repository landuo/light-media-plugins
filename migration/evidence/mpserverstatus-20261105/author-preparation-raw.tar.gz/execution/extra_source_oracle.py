"""Additional actual plugin/stdlib AST probes. No app import/network/Go oracle."""
import ast,datetime,hashlib,json,math,pathlib,types,typing,re,time
from urllib.parse import urlparse
ROOT=pathlib.Path(__file__).resolve().parent
# Reuse only the bootstrap, not the historical generator's case loop/output.
bootstrap=(ROOT/'generate_oracle.py').read_text().split('cases=[]',1)[0]
ns={'__file__':str(ROOT/'generate_oracle.py'),'__name__':'isolated_source_bootstrap'}
exec(compile(bootstrap,str(ROOT/'generate_oracle.py'),'exec'),ns)
Plugin=ns['Plugin'];clock=ns['clock']
# Actual captured Python3.12 email parser, with pure local time/calendar helpers.
stdlib=ROOT.parent/'runtime-reference/email'
date_ns={'__name__':'isolated_actual312_parseaddr'}
exec(compile((stdlib/'_parseaddr.py').read_text(),str(stdlib/'_parseaddr.py'),'exec'),date_ns)
fn=next(n for n in ast.parse((stdlib/'utils.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='parsedate_to_datetime')
utils_ns={'_parsedate_tz':date_ns['_parsedate_tz'],'datetime':datetime}
exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(stdlib/'utils.py'),'exec'),utils_ns)
ns['namespace']['parsedate_to_datetime']=utils_ns['parsedate_to_datetime']
cases=[]
def normalize(v):
 if isinstance(v,float) and not math.isfinite(v):return {'source_float':str(v)}
 if isinstance(v,dict):return {k:normalize(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [normalize(x) for x in v]
 return v
def save(name,kind,value,call):
 c={'name':name,'kind':kind,'input':value}
 try:c['expected']=normalize(call())
 except Exception as e:c['error_kind']=type(e).__name__;c['error']=str(e)
 cases.append(c)
for value in ['Fri, 16 Oct 2026 12:30:00 -0000','Fri, 16 Oct 2026 12:30:00 +0000','Fri, 16 Oct 2026 12:30:00 XYZ','Fri, 16 Oct 2026 12:30 GMT','16-Oct-26 12:30:00 EST','Fri Oct 16 12:30:00 2026','Fri, 16 Oct 26 12.30.00 GMT','Fri, 16 Oct 2026 12:30:00 +0530','Fri, 16 Oct 2026 12:30:00 GMT (comment)','Fri, 16 Oct 2026 12:30:60 GMT','Fri, 16 Oct 0042 12:30:00 GMT','Fri, 16 Oct 2026 12:30:00 -00:30']:
 save('date-'+str(len(cases)),'date',value,lambda v=value:Plugin._format_response_date(v))
base='Active connections: 12\nserver accepts handled requests\n1000 995 12345\nReading: 2 Writing: 3 Waiting: 7\n'
for n in [4300,4301]:
 text=base.replace('12345','1'*n)
 save('int-limit-'+str(n),'parse',text,lambda v=text:Plugin._parse_status_text(v))
for exponent in [307,309]:
 status={'active_connections':1,'accepts':1,'handled':1,'requests':1,'reading':10**exponent,'writing':0,'waiting':0}
 def call(status=status):
  p=Plugin();p.init_plugin({});clock.now=1000.0;return p._build_metrics(status,0.1)
 save('metric-percent-'+str(exponent),'metrics',{'at':1000,'status':status,'seconds':0.1},call)
status={'active_connections':1,'accepts':10**310,'handled':10**310,'requests':10**310,'reading':0,'writing':0,'waiting':1}
last={'timestamp':1000.0,'accepts':10**310,'handled':10**310,'requests':0}
def call_delta():
 p=Plugin();p.init_plugin({});p._last_sample=last;clock.now=1010.0;return p._build_metrics(status,0.1)
save('metric-delta-overflow','metrics',{'at':1010,'status':status,'seconds':0.1,'last':last},call_delta)
for v in [float('inf'),float('-inf'),float('nan')]:
 for method in ['_format_float','_format_percent','_format_seconds','_format_integer']:
  save(method+'-'+str(v),'nonfinite-format',{'method':method,'value':normalize(v)},lambda m=method,v=v:getattr(Plugin,m)(v))
out={'classification':'actual installed class and captured actual3.12 email parser AST with synthetic data; source before corrective Go edits','python':__import__('sys').version,'source_sha256':ns['reference']['source_sha256'],'cases':cases,'limitations':['Local interpreter3.14; actual3.12 parsedate algorithm and live int_max_str_digits4300 used; no actual app/network/services','Nonfinite internal metrics are encoded with explicit source_float tags only for fixture JSON; source public render turns them into text.']}
print(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
