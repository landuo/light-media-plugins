import pathlib,subprocess,json,shlex,hashlib,base64
root=pathlib.Path(__file__).resolve().parent
original=(root/'generate_oracle.py').read_text();start=original.index("(ROOT.parent/'server-status-original-oracle.json').write_text")
generator=original[:start]+"print(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False))\n"
extra_original=(root/'extra_source_oracle.py').read_text();a=extra_original.index('# Actual captured Python3.12');b=extra_original.index('cases=[]',a)
extra=extra_original[:a]+"# Exact image Python3.12 stdlib is already imported by the source bootstrap.\n"+extra_original[b:]
extra=extra.replace("'Local interpreter3.14; actual3.12 parsedate algorithm and live int_max_str_digits4300 used; no actual app/network/services'","'Exact image333 Python3.12.13, actual stdlib and max_str_digits4300; no app/network/services'")
(root/'generate_core_actual312.py').write_text(generator);(root/'extra_core_actual312.py').write_text(extra)
remote='/home/admin/light-media-plugins-mps-oracle-20261105/core-r1';marker='light-media-plugins/MPServerStatus/source-core-oracle/20261105/r1'
files={'generate_oracle.py':generator,'extra_source_oracle.py':extra,'installed-source.json':(root/'installed-source.json').read_text(),'.task-owned':marker}
create="import sys,json,pathlib,base64; x=json.load(sys.stdin); p=pathlib.Path(x['root']); assert not p.exists(); p.mkdir(parents=True,mode=0o755); [(p/n).write_bytes(base64.b64decode(v)) for n,v in x['files'].items()]"
subprocess.run(['ssh','admin@192.168.8.129','python3','-c',shlex.quote(create)],input=json.dumps({'root':remote,'files':{n:base64.b64encode(v.encode()).decode() for n,v in files.items()}}),text=True,check=True)
subprocess.run(['ssh','admin@192.168.8.129','chmod','755',str(pathlib.PurePosixPath(remote).parent)],check=True)
commands=[]
try:
 for script,output in [('generate_oracle.py','source-core-actual312.json'),('extra_source_oracle.py','source-extra-actual312.json')]:
  cmd=['ssh','admin@192.168.8.129','docker','run','--rm','--network','none','--read-only','--tmpfs','/tmp','--cap-drop','ALL','--security-opt','no-new-privileges','--user','1000:1000','--label','task=lm-plugin-mps-oracle-20261105','--mount','type=bind,src='+remote+',dst=/oracle,readonly','--entrypoint','python3','sha256:33354456e8e19c65193b9ca471e45450a620c541759cc42e76cf00a03b025881','-I','-B','/oracle/'+script]
  with (root/output).open('w') as out,(root/(output+'.stderr')).open('w') as err:result=subprocess.run(cmd,stdout=out,stderr=err)
  commands.append({'command':cmd,'exit':result.returncode});assert result.returncode==0
finally:
 cleanup="import pathlib,shutil; p=pathlib.Path("+repr(remote)+"); assert (p/'.task-owned').read_text()=="+repr(marker)+"; shutil.rmtree(p); p.parent.rmdir()"
 subprocess.run(['ssh','admin@192.168.8.129','python3','-c',shlex.quote(cleanup)],check=True)
(root/'core-actual312-command.json').write_text(json.dumps({'commands':commands,'inputs':[{'path':key,'sha256':hashlib.sha256(value.encode()).hexdigest()}for key,value in files.items()],'adaptations':['main174 prints JSON instead of readonly outside output file','extra29 uses image exact stdlib rather than local actual312 extracted email AST, otherwise identical functions and cases']},indent=2)+'\n')
old=json.load(open(root.parent/'server-status-original-oracle.json'));new=json.load(open(root/'source-core-actual312.json'));assert old['cases']==new['cases']
oldextra=json.load(open(root/'extra-source-oracle.json'));newextra=json.load(open(root/'source-extra-actual312.json'));assert oldextra['cases']==newextra['cases']
print(json.dumps({'actual312_core_cases':len(new['cases']),'actual312_extra_cases':len(newextra['cases']),'previous_local_observations_match':True,'remote_owned_directory_removed':True}))
