# Exact isolated image requests/chardet/codec source; no app or network.
import json,sys,requests,requests.utils
base='Active connections: 12\nserver accepts handled requests\n1000 995 12345\nReading: 2 Writing: 3 Waiting: 7\n'
texts=[('ascii',base),('zh',base+'标签测试 中文服务'),('ja',base+'状態テスト 日本語'),('ru',base+'Русский текст сервера'),('unicode-digits',base.replace('12','١٢'))]
cases=[]
for label,text in texts:
 for codec in ['utf-8','utf-8-sig','utf-16','utf-16-le','utf-16-be','utf-32','utf-32-le','utf-32-be','gb18030','big5','shift_jis','cp1251','iso8859-1']:
  try:data=text.encode(codec)
  except UnicodeError:continue
  for declared in [False,True]:
   content_type=('text/plain; charset='+codec) if declared else ''
   r=requests.Response();r._content=data;r.headers=requests.structures.CaseInsensitiveDict({'Content-Type':content_type})
   r.encoding=requests.utils.get_encoding_from_headers(r.headers)
   cases.append({'name':label+'-'+codec+('-declared' if declared else '-apparent'),'input_hex':data.hex(),'declared_encoding':r.encoding,'apparent_encoding':r.apparent_encoding,'text':r.text})
for data in [b'\xff\xff\xe2\x82',b'\x80\x81\x82\x83',b'\x00\x01\x02\x03',b'\x81',b'\xfe\xff\x00',bytes(range(256))]:
 r=requests.Response();r._content=data;r.encoding=None
 cases.append({'name':'opaque-'+str(len(cases)),'input_hex':data.hex(),'declared_encoding':None,'apparent_encoding':r.apparent_encoding,'text':r.text})
print(json.dumps({'classification':'exact image333 actual Requests.Response.text + installed chardet7.4.3 and Python3.12 codecs; no app/network','python':sys.version,'cases':cases},ensure_ascii=True,indent=2))
