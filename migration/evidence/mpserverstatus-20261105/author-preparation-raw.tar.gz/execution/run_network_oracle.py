import pathlib,subprocess,json,shlex,hashlib,base64
root=pathlib.Path(__file__).resolve().parent
original=pathlib.Path('/Users/accidia/projects/light-media/testdata/plugins/server-status-reference/generate_network_reference.py').read_text()
script=original.replace("raw=json.dumps(output,ensure_ascii=False,indent=2)+'\\n';(ROOT.parent/'server-status-http-original-reference.json').write_text(raw)\n        print(json.dumps({'cases':len(cases),'tls_strategy_difference_proved':True,'sha256':hashlib.sha256(raw.encode()).hexdigest()}))","print(json.dumps(output,ensure_ascii=False,indent=2))")
assert script!=original
(root/'generate_network_reference_actual312.py').write_text(script)
remote='/home/admin/light-media-plugins-mps-oracle-20261105/net-r1'
marker='light-media-plugins/MPServerStatus/source-network-oracle/20261105/r1'
files={'generate_network_reference.py':script,'installed-source.json':(root/'installed-source.json').read_text(),'.task-owned':marker}
create="import sys,json,pathlib,base64; x=json.load(sys.stdin); p=pathlib.Path(x['root']); assert not p.exists(), 'owned oracle root already exists'; p.mkdir(parents=True,mode=0o700); [(p/n).write_bytes(base64.b64decode(v)) for n,v in x['files'].items()]"
subprocess.run(['ssh','admin@192.168.8.129','python3','-c',shlex.quote(create)],input=json.dumps({'root':remote,'files':{n:base64.b64encode(v.encode()).decode() for n,v in files.items()}}),text=True,check=True)
cmd=['ssh','admin@192.168.8.129','docker','run','--rm','--network','none','--read-only','--tmpfs','/tmp','--cap-drop','ALL','--security-opt','no-new-privileges','--user','1000:1000','--label','task=lm-plugin-mps-oracle-20261105','--mount','type=bind,src='+remote+',dst=/oracle,readonly','--entrypoint','python3','sha256:33354456e8e19c65193b9ca471e45450a620c541759cc42e76cf00a03b025881','-I','-B','/oracle/generate_network_reference.py']
# Bind path must be traversable by this isolated uid; only these source inputs
# are public-safe, not host data or credentials.
subprocess.run(['ssh','admin@192.168.8.129','chmod','755',str(pathlib.PurePosixPath(remote).parent),remote],check=True)
try:
 with (root/'network-source-actual312.json').open('w') as stdout,(root/'network-source-actual312.stderr').open('w') as stderr:
  result=subprocess.run(cmd,stdout=stdout,stderr=stderr)
 (root/'network-source-actual312-command.json').write_text(json.dumps({'command':cmd,'exit':result.returncode,'generator_original_sha256':hashlib.sha256(original.encode()).hexdigest(),'generator_adapted_sha256':hashlib.sha256(script.encode()).hexdigest(),'adaptation':'output JSON on stdout instead of readonly outside-mounted-path output; original source function AST unchanged'},indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
finally:
 cleanup="import pathlib,shutil; p=pathlib.Path("+repr(remote)+"); assert (p/'.task-owned').read_text()=="+repr(marker)+"; shutil.rmtree(p); p.parent.rmdir()"
 subprocess.run(['ssh','admin@192.168.8.129','python3','-c',shlex.quote(cleanup)],check=True)
print('Owned actual312 network oracle complete; remote marker directory removed.')
