package mpserverstatus

import (
	"fmt"
	"strconv"
	"strings"
	"time"
)

// ResponseDate follows Python3.12 email._parseaddr._parsedate_tz and
// email.utils.parsedate_to_datetime. Unknown zones and -0000 are naive.
// Source malformed dates are returned unchanged by the plugin's catch.
func ResponseDate(value string) string {
	if value == "" {
		return "-"
	}
	fields := strings.FieldsFunc(value, pythonSpace)
	if len(fields) == 0 {
		return value
	}
	days := []string{"mon", "tue", "wed", "thu", "fri", "sat", "sun"}
	dayname := false
	for _, d := range days {
		if strings.ToLower(fields[0]) == d {
			dayname = true
		}
	}
	if strings.HasSuffix(fields[0], ",") || dayname {
		fields = fields[1:]
	} else if i := strings.LastIndex(fields[0], ","); i >= 0 {
		fields[0] = fields[0][i+1:]
	}
	if len(fields) == 3 {
		if parts := strings.Split(fields[0], "-"); len(parts) == 3 {
			fields = append(parts, fields[1:]...)
		}
	}
	if len(fields) == 4 {
		s := fields[3]
		i := strings.Index(s, "+")
		if i < 0 {
			i = strings.Index(s, "-")
		}
		if i > 0 {
			fields = append(fields[:3], s[:i], s[i:])
		} else {
			fields = append(fields, "")
		}
	}
	if len(fields) < 5 {
		return value
	}
	fields = fields[:5]
	dd, mm, yy, tm, tz := fields[0], strings.ToLower(fields[1]), fields[2], fields[3], fields[4]
	if dd == "" || mm == "" || yy == "" {
		return value
	}
	months := []string{"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec", "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"}
	monthIndex := func(s string) int {
		for i, m := range months {
			if s == m {
				return i%12 + 1
			}
		}
		return 0
	}
	month := monthIndex(mm)
	if month == 0 {
		dd, mm = mm, strings.ToLower(dd)
		month = monthIndex(mm)
		if month == 0 {
			return value
		}
	}
	dd = strings.TrimSuffix(dd, ",")
	if i := strings.Index(yy, ":"); i > 0 {
		yy, tm = tm, yy
	}
	yy = strings.TrimSuffix(yy, ",")
	if yy == "" {
		return value
	}
	if yy[0] < '0' || yy[0] > '9' {
		yy, tz = tz, yy
	}
	tm = strings.TrimSuffix(tm, ",")
	parts := strings.Split(tm, ":")
	if len(parts) == 1 && strings.Contains(tm, ".") {
		parts = strings.Split(tm, ".")
	}
	if len(parts) == 2 {
		parts = append(parts, "0")
	}
	if len(parts) != 3 {
		return value
	}
	parse := func(s string) (int, error) {
		var b strings.Builder
		for _, r := range strings.TrimFunc(s, pythonSpace) {
			if r == '_' || r == '+' || r == '-' {
				b.WriteRune(r)
				continue
			}
			found := false
			for _, zero := range pythonDecimalZeroes {
				if r >= zero && r <= zero+9 {
					b.WriteByte(byte('0' + r - zero))
					found = true
					break
				}
			}
			if !found {
				return 0, fmt.Errorf("invalid integer")
			}
		}
		return strconv.Atoi(strings.ReplaceAll(b.String(), "_", ""))
	}
	year, e := parse(yy)
	if e != nil {
		return value
	}
	day, e := parse(dd)
	if e != nil {
		return value
	}
	hour, e := parse(parts[0])
	if e != nil {
		return value
	}
	minute, e := parse(parts[1])
	if e != nil {
		return value
	}
	second, e := parse(parts[2])
	if e != nil {
		return value
	}
	if year < 100 {
		if year > 68 {
			year += 1900
		} else {
			year += 2000
		}
	}
	if year < 1 || year > 9999 || day < 1 || day > 31 || hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59 {
		return value
	}
	d := time.Date(year, time.Month(month), day, hour, minute, second, 0, time.UTC)
	if d.Month() != time.Month(month) || d.Day() != day {
		return value
	}
	zones := map[string]int{"UT": 0, "UTC": 0, "GMT": 0, "Z": 0, "AST": -400, "ADT": -300, "EST": -500, "EDT": -400, "CST": -600, "CDT": -500, "MST": -700, "MDT": -600, "PST": -800, "PDT": -700}
	upper := strings.ToUpper(tz)
	offset, known := zones[upper]
	if !known {
		offset, e = parse(upper)
		known = e == nil
		if known && offset == 0 && strings.HasPrefix(upper, "-") {
			known = false
		}
	}
	zone := ""
	if known {
		zone = "UTC"
		if offset != 0 {
			sign := "+"
			if offset < 0 {
				sign = "-"
				offset = -offset
			}
			seconds := (offset/100)*3600 + (offset%100)*60
			if seconds >= 86400 {
				return value
			}
			zone = fmt.Sprintf("UTC%s%02d:%02d", sign, seconds/3600, seconds%3600/60)
		}
	}
	return d.Format("2006-01-02 15:04:05 ") + zone
}
