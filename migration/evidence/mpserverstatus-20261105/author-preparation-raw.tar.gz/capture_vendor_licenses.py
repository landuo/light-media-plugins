from pathlib import Path
import sys,hashlib,json,base64
site=Path(sys.executable).parent.parent/'lib'/('python%d.%d'%sys.version_info[:2])/'site-packages'
files=[]
for dist in ['requests-2.34.2.dist-info','chardet-7.4.3.dist-info']:
 root=site/dist
 for p in root.rglob('*'):
  if p.is_file() and p.name in ['LICENSE','NOTICE','COPYING']:
   b=p.read_bytes();files.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'base64':base64.b64encode(b).decode()})
print(json.dumps({'python':sys.version,'classification':'read-only vendor license/notice bytes, no app imports/functions/config/DB/network','files':files}))
