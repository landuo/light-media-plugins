from pathlib import Path
import json,hashlib,datetime,sys
root=Path(__file__).resolve().parents[3]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def files_in(base):return sorted(p for p in (root/base).rglob('*') if p.is_file())
owned=files_in('plugins/mpserverstatus')+files_in('cmd/mp-server-status')
sdk=files_in('internal/sdk')
# Driver binary compiles the whole integration package. Bind it conservatively,
# including other drivers read only, without claiming ownership of them.
driver=files_in('tests/integration')
extra=[root/x for x in ['go.mod','go.sum','SDK_ORIGIN.json','third_party/Go-LICENSE','third_party/brotli-LICENSE','third_party/brotli-flate-LICENSE','third_party/x-net-LICENSE','third_party/x-net-PATENTS','third_party/x-text-LICENSE','third_party/x-text-PATENTS']]
def bind(paths):return {str(p.relative_to(root)):sha(p) for p in sorted(paths)}
x={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'classification':'current complete business/SDK/module/driver-package input checkpoint; no Go overlay','owned':bind(owned),'sdk':bind(sdk),'driver_package_read_inputs':bind(driver),'module_and_license':bind(extra)}
(root/sys.argv[1]).write_text(json.dumps(x,indent=2)+'\n')
print({k:len(v) for k,v in x.items() if isinstance(v,dict)})
