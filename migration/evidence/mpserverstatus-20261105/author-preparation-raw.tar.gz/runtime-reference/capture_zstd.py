from pathlib import Path
import sys,json,hashlib,base64
site=Path(sys.executable).parent.parent/'lib'/('python%d.%d'%sys.version_info[:2])/'site-packages'
paths=list((site/'backports/zstd').glob('*.py'))+list((site/'backports/zstd').glob('*.so'))
paths+=list(site.glob('backports_zstd-*.dist-info/METADATA'))
items=[]
for p in paths:
 b=p.read_bytes();x={'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 if p.suffix=='.py' or p.name=='METADATA':x['base64']=base64.b64encode(b).decode()
 items.append(x)
print(json.dumps({'python':sys.version,'files':items}))
