# Read-only production-static capture. No app/vendor import or function execution.
from pathlib import Path
import sys,json,hashlib,base64
root=Path(sys.base_prefix)/'lib'/('python%d.%d'%sys.version_info[:2])
site=Path(sys.executable).parent.parent/'lib'/('python%d.%d'%sys.version_info[:2])/'site-packages'
paths=[root/'email/utils.py',root/'email/_parseaddr.py',site/'requests/models.py',site/'requests/utils.py',site/'requests/sessions.py',site/'requests/adapters.py',site/'urllib3/response.py',site/'urllib3/util/request.py',site/'brotli.py',site/'zstandard/__init__.py']
for p in site.iterdir():
 if p.name.lower().endswith('.dist-info') and any(p.name.lower().startswith(x+'-') for x in ['requests','urllib3','certifi','idna','charset_normalizer','chardet','brotli','zstandard']):paths.append(p/'METADATA')
paths+=list(site.glob('_brotli*.so'))+list((site/'zstandard').glob('backend_c*.so'))
out=[]
for p in paths:
 if not p.is_file():continue
 b=p.read_bytes();r={'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 if p.suffix!='.so':r['base64']=base64.b64encode(b).decode()
 out.append(r)
print(json.dumps({'python':sys.version,'int_max_str_digits':sys.get_int_max_str_digits(),'files':out}))
