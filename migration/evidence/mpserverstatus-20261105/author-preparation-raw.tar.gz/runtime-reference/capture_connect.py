from pathlib import Path
import sys,json,hashlib,base64
root=Path(sys.base_prefix)/'lib'/('python%d.%d'%sys.version_info[:2]);site=Path(sys.executable).parent.parent/'lib'/('python%d.%d'%sys.version_info[:2])/'site-packages'
items=[]
for p in [root/'socket.py',site/'urllib3/util/connection.py']:
 b=p.read_bytes();items.append({'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'base64':base64.b64encode(b).decode()})
print(json.dumps({'python':sys.version,'files':items}))
