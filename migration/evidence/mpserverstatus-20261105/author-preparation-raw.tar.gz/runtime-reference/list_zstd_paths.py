from pathlib import Path
import sys,json
site=Path(sys.executable).parent.parent/'lib'/('python%d.%d'%sys.version_info[:2])/'site-packages'
root=Path(sys.base_prefix)/'lib'/('python%d.%d'%sys.version_info[:2])
out=[]
for base in [site,site/'backports',root,root/'backports']:
 if base.is_dir():out.append({'base':str(base),'selected_names':[x.name for x in base.iterdir() if base.name=='backports' or 'zstd' in x.name.lower() or x.name=='backports']})
print(json.dumps(out))
