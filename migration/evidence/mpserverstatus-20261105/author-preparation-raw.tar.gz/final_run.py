import subprocess,os,json,sys,datetime
from pathlib import Path
root=Path(__file__).resolve().parents[3];p=Path(__file__).resolve().parent
phase=sys.argv[1];g=['go'];pk=['./plugins/mpserverstatus/...','./cmd/mp-server-status']
commands={
 'normal':(g+['test','-count=1','-json']+pk,'current-full-normal.jsonl',{}),
 'race':(g+['test','-race','-count=1','-json']+pk,'current-full-race.jsonl',{}),
 'vet':(g+['vet']+pk,'current-vet.log',{}),
 'linux':(g+['build','-trimpath','-buildvcs=false','-o',str(p/'mp-server-status-linux-amd64'),'./cmd/mp-server-status'],'current-linux-build.log',{'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'}),
 'update':(g+['build','-overlay='+str(p/'manifest-update-overlay.json'),'-trimpath','-buildvcs=false','-o',str(p/'mp-server-status-update-linux-amd64'),'./cmd/mp-server-status'],'current-update-linux-build.log',{'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'}),
 'driver-normal':(g+['test','-count=1','./tests/integration','-run','^$'],'main-driver-current-normal-compile.log',{}),
 'driver-race':(g+['test','-race','-count=1','./tests/integration','-run','^$'],'main-driver-current-race-compile.log',{}),
 'driver-vet':(g+['vet','./tests/integration'],'main-driver-current-vet.log',{}),
 'driver-linux':(g+['test','-c','-o',str(p/'mpserverstatus-main-tests-linux-amd64'),'./tests/integration'],'main-driver-current-linux-build.log',{'CGO_ENABLED':'0','GOOS':'linux','GOARCH':'amd64'})}
cmd,name,updates=commands[phase];env=dict(os.environ);env['GOFLAGS']='';env.update(updates)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (p/name).open('wb')as out,(p/(name+'.stderr')).open('wb')as err:r=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=err)
x={'phase':phase,'command':cmd,'env_overrides':{'GOFLAGS':'',**updates},'at_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'stdout':str((p/name).relative_to(root)),'stderr':str((p/(name+'.stderr')).relative_to(root))}
(p/('current-'+phase+'-result.json')).write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x));sys.exit(r.returncode)
