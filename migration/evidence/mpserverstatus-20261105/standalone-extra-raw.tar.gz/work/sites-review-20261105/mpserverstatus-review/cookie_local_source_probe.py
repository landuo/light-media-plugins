import requests,requests.cookies,email.message,json,sys,pathlib,base64,hashlib
from types import SimpleNamespace
out=[]
cases=[('https://localhost/status',x) for x in ['local','.local','localhost','.localhost','']] + [('https://a.local/status',x) for x in ['local','.local','a.local']] + [('https://machine/status','local'),('https://movie-pilot.org/status','local'),('https://localhost.local/status','local')]
for origin,domain in cases:
 target=origin.replace('/status','/after');header='owned=test; Path=/' + ('; Domain='+domain if domain else '')
 jar=requests.cookies.RequestsCookieJar();m=email.message.Message();m.add_header('Set-Cookie',header);request=requests.Request('GET',origin).prepare();response=SimpleNamespace(_original_response=SimpleNamespace(msg=m));requests.cookies.extract_cookies_to_jar(jar,request,response);sent=requests.cookies.get_cookie_header(jar,requests.Request('GET',target).prepare());out.append({'origin':origin,'target':target,'domain':domain,'set_cookie':header,'cookie_header':sent,'stored_domains':[c.domain for c in jar]})
p=pathlib.Path('/usr/local/lib/python3.12/http/cookiejar.py');b=p.read_bytes()
print(json.dumps({'classification':'actual333/Python3.12 Requests default cookiejar .local extraction+redirect generation; stdlib static bytes read; no HTTP/app/config/network','runtime':sys.version,'cases':out,'static_cookiejar':{'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'base64':base64.b64encode(b).decode()}},indent=2))
