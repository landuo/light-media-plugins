import requests,requests.cookies,email.message,json,sys
from types import SimpleNamespace
origin='https://movie-pilot.org/status';target='https://movie-pilot.org/after';out=[]
for attr in ['Max-Age=garbage','Max-Age=0_0','Max-Age=00','Max-Age=+0','Max-Age=1; Max-Age=0','Max-Age=0; Max-Age=1','Max-Age=0','Max-Age=1']:
 header='owned=test; Path=/; '+attr;jar=requests.cookies.RequestsCookieJar();m=email.message.Message();m.add_header('Set-Cookie',header);req=requests.Request('GET',origin).prepare();requests.cookies.extract_cookies_to_jar(jar,req,SimpleNamespace(_original_response=SimpleNamespace(msg=m)));sent=requests.cookies.get_cookie_header(jar,requests.Request('GET',target).prepare());out.append({'domain':attr,'set_cookie':header,'cookie_header':sent})
print(json.dumps({'classification':'actual333/Python3.12 Requests default CookieJar Max-Age normalization and first-attribute handling; no HTTP/app/config/network','runtime':sys.version,'origin':origin,'target':target,'cases':out},indent=2))
