package requestsproxy
import("testing";"encoding/json";"os";"net/url";"net/http")
func TestIndependentActualRequestsNoProxySuffix(t *testing.T){
 b,e:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/mpserverstatus-review/no-proxy-source-delta.json");if e!=nil{t.Fatal(e)};var v struct{URL string;Cases []struct{No string `json:"no_proxy"`;Selected *string}};if e=json.Unmarshal(b,&v);e!=nil{t.Fatal(e)};u,_:=url.Parse(v.URL)
 for _,x:=range v.Cases{t.Run(x.No,func(t *testing.T){env:=[]string{"HTTPS_PROXY=http://127.0.0.1:3128","NO_PROXY="+x.No};a,e:=RequestsEnvironmentProxy(env,u);if e!=nil{t.Fatal(e)};tr,e:=NewRequestsProxyTransport(&http.Transport{},env,nil,u);if e!=nil{t.Fatal(e)};c,e:=tr.requestProxy(u);if e!=nil{t.Fatal(e)};for _,got:=range []*url.URL{a,c}{if x.Selected==nil{if got!=nil{t.Fatalf("source selected None Go proxy=%v",got)}}else if got==nil||got.String()!=*x.Selected{t.Fatalf("source proxy %q Go %v",*x.Selected,got)}}})}
}
