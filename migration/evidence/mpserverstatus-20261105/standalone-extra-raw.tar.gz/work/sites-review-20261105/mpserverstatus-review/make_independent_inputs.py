import ast,json,pathlib,math
R=pathlib.Path(__file__).resolve().parent;src=R.parent/'mpserverstatus-source-only';original=json.loads((src/'oracle.json').read_text());script=ast.parse((src/'oracle.py').read_text());raw_good='Active connections: 7\nserver accepts handled requests\n 10 9 20\nReading: 1 Writing: 2 Waiting: 4'
parse={}
for n in script.body:
 if isinstance(n,ast.For) and isinstance(n.target,ast.Tuple) and [getattr(x,'id','') for x in n.target.elts]==['name','s']:
  parse=dict(eval(compile(ast.Expression(n.iter),'own-source-inputs','eval'),{'raw_good':raw_good,'str':str}))
def literal(s):
 if s in ['inf','-inf','nan']:return {'source_float':s}
 return ast.literal_eval(s)
out=[]
for old in original['cases']:
 name=old['name'];row=dict(old);parts=name.split('-',1);op=parts[0];suffix=parts[1] if len(parts)>1 else'';args=None
 if name.startswith('config-enable-'):op='config';args=literal(name[len('config-enable-'):])
 elif name.startswith('format-'):
  method,suffix=name[len('format-'):].rsplit('-',1)
  # Negative suffix must retain its sign, which rsplit would consume.
  for m in ['_format_integer','_format_float','_format_percent','_format_seconds','_format_sample_caption']:
   if name.startswith('format-'+m+'-'):method=m;suffix=name[len('format-'+m+'-'):];break
  op=method;args=literal(suffix)
 elif op=='parse':args=parse[suffix]
 elif op in ['size','protocol','date','rate']:args=literal(suffix)
 elif name.startswith('certificate-name-'):op='certificate';args=literal(name[len('certificate-name-'):])
 elif op=='ips':args=literal(suffix)
 elif op=='latency':args=literal(suffix)
 elif op=='severity':direction,value=suffix.split('-',1);args=[float(value),1,10 if direction=='asc' else 0]
 elif name.startswith('tls-display-'):op='tls-display';args=literal(name[len('tls-display-'):])
 elif name=='card-sm-zero-and-empty-subtitle':op='card';args=[]
 elif name=='info-table-empty':op='table';args=[]
 else:continue
 row.update(op=op,args=args);out.append(row)
(R/'independent-simple-inputs.json').write_text(json.dumps({'classification':'149 selected cases/inputs derived only from independently frozen original188case source3.14 oracle, prior to target; not a target expected-value producer','cases':out},ensure_ascii=False,indent=2)+'\n');print(len(out))
