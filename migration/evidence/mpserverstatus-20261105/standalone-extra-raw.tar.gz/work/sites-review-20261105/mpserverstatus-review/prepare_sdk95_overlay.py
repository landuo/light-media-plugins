import pathlib,json,hashlib,subprocess
R=pathlib.Path('/Users/accidia/projects/light-media-plugins');H=pathlib.Path('/Users/accidia/projects/light-media');O=R/'work/sites-review-20261105/mpserverstatus-review';F=R/'work/migration-20261105/mpserverstatus-preparation/SDK_ORIGIN-95.json';d=json.loads(F.read_text());rows=d['files'];refs=[d['source_commit']+':'+x['source_path'] for x in rows];b=subprocess.run(['git','-C',str(H),'cat-file','--batch'],input=('\n'.join(refs)+'\n').encode(),capture_output=True,check=True).stdout;off=0;mapping={};summary=[]
for x in rows:
 end=b.index(b'\n',off);head=b[off:end].decode().split();assert head[1]=='blob';n=int(head[2]);source=b[end+1:end+1+n];off=end+2+n;assert hashlib.sha256(source).hexdigest()==x['source_sha256'];target=source
 for c in d['allowed_changes']:target=target.replace(c['from'].encode(),c['to'].encode())
 assert hashlib.sha256(target).hexdigest()==x['sha256'];p=R/x['path'];current=p.read_bytes() if p.exists() else b''
 if current!=target:
  save=O/'sdk95-changed-only'/x['path'];save.parent.mkdir(parents=True,exist_ok=True);save.write_bytes(target);mapping[str(p)]=str(save)
 summary.append({'path':x['path'],'source_git_blob':head[0],'frozen_target_sha256':x['sha256'],'current_matches':current==target})
assert off==len(b)
extra=[]
for p in (R/'internal/sdk').rglob('*'):
 if p.is_file() and p.suffix=='.go' and str(p.relative_to(R)) not in {x['path'] for x in rows}:mapping[str(p)]='';extra.append(str(p.relative_to(R)))
if (R/'SDK_ORIGIN.json').read_bytes()!=F.read_bytes():mapping[str(R/'SDK_ORIGIN.json')]=str(F)
(O/'sdk95-overlay.json').write_text(json.dumps({'Replace':mapping},indent=2)+'\n');(O/'sdk95-overlay-inputs.json').write_text(json.dumps({'classification':'restore only changed SDK95 files from actual a16Git blobs + declared imports; remove later addedSDKGo via overlay; no project/framework copy','snapshot_origin_sha256':hashlib.sha256(F.read_bytes()).hexdigest(),'source_commit':d['source_commit'],'files':summary,'extra_current_sdk_go_removed':extra,'overlay':mapping,'inner_worker_build_rule':'set absolute GOFLAGS=-overlay=... for outertest AND inherited go build subprocess, not outer -overlay flag only'},indent=2)+'\n');print(json.dumps({'replaced_sdk_files':len([x for x in summary if not x['current_matches']]),'removed_extra_sdk':extra,'overlay_total_entries':len(mapping)}))
