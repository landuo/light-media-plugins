import requests,requests.cookies,email.message,json,sys
from types import SimpleNamespace
origin='https://movie-pilot.org/status';target='https://movie-pilot.org/after';out=[]
for domain in ['org','.org','movie-pilot.org','.movie-pilot.org','pilot.org','', 'ORG']:
 header='owned=test; Path=/' + ('; Domain='+domain if domain else '')
 jar=requests.cookies.RequestsCookieJar();m=email.message.Message();m.add_header('Set-Cookie',header);request=requests.Request('GET',origin).prepare();response=SimpleNamespace(_original_response=SimpleNamespace(msg=m));requests.cookies.extract_cookies_to_jar(jar,request,response);sent=requests.cookies.get_cookie_header(jar,requests.Request('GET',target).prepare());out.append({'domain':domain,'set_cookie':header,'cookie_header':sent})
print(json.dumps({'classification':'actual333/Python3.12 Requests default cookiejar extraction+redirect Cookie header generation; no HTTP/app/config or network','runtime':sys.version,'requests':requests.__version__,'origin':origin,'target':target,'cases':out},indent=2))
