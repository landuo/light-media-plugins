import pathlib,hashlib,json,base64
names=['/usr/local/lib/python3.12/http/client.py','/opt/venv/lib/python3.12/site-packages/urllib3/connection.py','/opt/venv/lib/python3.12/site-packages/urllib3/connectionpool.py']
rows=[]
for name in names:
 try:
  b=pathlib.Path(name).read_bytes();rows.append({'path':name,'sha256':hashlib.sha256(b).hexdigest(),'base64':base64.b64encode(b).decode()})
 except Exception as e:rows.append({'path':name,'error':str(e)})
print(json.dumps({'classification':'live static stdlib/vendor read only -B-S/no app imports/config/db','files':rows}))
