package mpserverstatus
import("testing";"encoding/json";"os")
func TestIndependentSourceDateUnderscore(t *testing.T){
 b,e:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/mpserverstatus-review/date-source-delta.json");if e!=nil{t.Fatal(e)};var v struct{Cases []struct{Input string;Return string}};if e=json.Unmarshal(b,&v);e!=nil{t.Fatal(e)};for _,x:=range v.Cases{t.Run(x.Input,func(t *testing.T){if got:=ResponseDate(x.Input);got!=x.Return{t.Fatalf("source return %q Go return %q",x.Return,got)}})}
}
