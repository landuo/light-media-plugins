package mpserverstatus
import("testing";"encoding/json";"os";"net";"fmt";"context";"time";"bufio";"strings")
func TestIndependentSourceNativeHeaderCount(t *testing.T){
 b,e:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/mpserverstatus-review/header-count-source-delta.json");if e!=nil{t.Fatal(e)}
 var v struct{Cases []struct{Count int `json:"header_lines_excluding_blank"`;None bool `json:"response_is_None"`}}
 if e=json.Unmarshal(b,&v);e!=nil{t.Fatal(e)}
 for _,x:=range v.Cases{t.Run(fmt.Sprint(x.Count),func(t *testing.T){
  l,e:=net.Listen("tcp","127.0.0.1:0");if e!=nil{t.Fatal(e)};defer l.Close();done:=make(chan struct{});go func(){defer close(done);c,e:=l.Accept();if e!=nil{return};defer c.Close();reader:=bufio.NewReader(c);for{line,e:=reader.ReadString('\n');if e!=nil{return};if strings.TrimSpace(line)==""{break}}
  content:="Active connections: 7\nserver accepts handled requests\n10 9 20\nReading:1 Writing:2 Waiting:4";fmt.Fprintf(c,"HTTP/1.1 200 OK\r\nContent-Length: %d\r\n",len(content));for i:=0;i<x.Count-1;i++{fmt.Fprintf(c,"X-owned-%d: value\r\n",i)};fmt.Fprintf(c,"\r\n%s",content)
  }();n:=&NativeNetwork{};got,e:=n.status(context.Background(),"http://"+l.Addr().String()+"/",2*time.Second,nil);<-done;if e!=nil{t.Fatal(e)};if (got==nil)!=x.None{t.Fatalf("actual source None=%v Go None=%v",x.None,got==nil)}
 })}
}
