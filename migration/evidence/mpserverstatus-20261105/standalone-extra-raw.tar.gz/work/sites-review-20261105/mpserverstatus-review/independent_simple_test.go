package mpserverstatus
import("testing";"encoding/json";"os";"bytes";"fmt";"reflect";"strconv";"math")
type independentCase struct{Name,Op,Raises,Message string;Args,Return any}
func independentNormalize(x any) any {b,e:=json.Marshal(x);if e!=nil{panic(e)};d:=json.NewDecoder(bytes.NewReader(b));d.UseNumber();var y any;if e=d.Decode(&y);e!=nil{panic(e)};return y}
func independentFloat(x any)float64{if x==nil{return 0};switch v:=x.(type){case json.Number:f,e:=v.Float64();if e!=nil{panic(e)};return f;case map[string]any:s:=v["source_float"].(string);if s=="inf"{return math.Inf(1)};if s=="-inf"{return math.Inf(-1)};return math.NaN()};panic(fmt.Sprint("bad numeric ",x))}
func independentValue(x any)any{if v,ok:=x.(map[string]any);ok&&v["source_float"]!=nil{return independentFloat(x)};return x}
func independentInvoke(c independentCase)(out any,err error){defer func(){if p:=recover();p!=nil{err=fmt.Errorf("%v",p)}}();v:=independentValue(c.Args);switch c.Op{
case "config":m:=New(nil,nil);b,_:=json.Marshal(map[string]any{"enable":v});err=m.Init(b);f:=Form(m.State());return []any{m.State(),[]any{f["conf"],f["model"]},[]any{},[]any{}},err
case "parse":return Parse(v.(string))
case "_format_integer":return FormatInteger(v),nil
case "_format_float":return FormatFloat(v,2),nil
case "_format_percent":return FormatPercent(v),nil
case "_format_seconds":return FormatSeconds(v),nil
case "_format_sample_caption":return FormatSample(v),nil
case "size":return FormatSize(v),nil
case "rate":return FormatRate(v,"x/s"),nil
case "date":if v==nil{return ResponseDate(""),nil};return ResponseDate(v.(string)),nil
case "protocol":n,ok:=v.(json.Number);if !ok{return "-",nil};i,e:=strconv.Atoi(string(n));if e!=nil{return "-",nil};return HTTPVersion(i),nil
case "severity":a:=v.([]any);return Severity(independentFloat(a[0]),independentFloat(a[1]),independentFloat(a[2])),nil
case "latency":a:=v.([]any);return Latency(a[0],a[1].(bool)),nil
case "ips":a:=v.([]any);return FormatIPs(a[0],a[1]),nil
case "certificate":var result [][][2]string;if v!=nil{for _,g:=range v.([]any){group:=[][2]string{};for _,p:=range g.([]any){a:=p.([]any);group=append(group,[2]string{a[0].(string),a[1].(string)})};result=append(result,group)}};return CertificateName(result),nil
case "tls-display":a:=v.(map[string]any);return []any{FormatTLSDays(a),TLSColor(a)},nil
case "card":return card("label","value","icon","color","",6,0,3),nil
case "table":return table("title",[][2]string{},12),nil
};return nil,fmt.Errorf("unsupported independent op%s",c.Op)}
func TestIndependentOriginalSimpleCases(t *testing.T){b,e:=os.ReadFile("/Users/accidia/projects/light-media-plugins/work/sites-review-20261105/mpserverstatus-review/independent-simple-inputs.json");if e!=nil{t.Fatal(e)};var v struct{Cases []independentCase};d:=json.NewDecoder(bytes.NewReader(b));d.UseNumber();if e=d.Decode(&v);e!=nil{t.Fatal(e)};for _,c:=range v.Cases{t.Run(c.Name,func(t *testing.T){got,e:=independentInvoke(c);if c.Raises!=""{if e==nil||e.Error()!=c.Message{t.Fatalf("source %s %q Go %v",c.Raises,c.Message,e)};return};if e!=nil{t.Fatal(e)};if !reflect.DeepEqual(independentNormalize(got),c.Return){a,_:=json.Marshal(got);want,_:=json.Marshal(c.Return);t.Fatalf("source %s Go %s",want,a)}})}}
